extends Control

const MAIN_SCENE_PATH := "res://scenes/Main.tscn"
const MENU_BG_PATH := "res://assets/backgrounds/menu_lr_global.png"

@onready var status_label: Label = $LoadingOverlay/Center/Box/Status
@onready var overlay: ColorRect = $LoadingOverlay

var main_instance: Node = null
var loading_tick := 0
var loading_timer: Timer
var watchdog: Timer
var main_request_active := false
var fallback_root: Control = null
var game_ready := false

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _install_boot_background()
    _start_loading_animation()
    _start_watchdog()

    var audio := get_node_or_null("/root/AudioManager")
    if audio != null and audio.has_method("set_context"):
        audio.set_context("menu")

    print("[BOOT] Iniciando carregamento assíncrono da Main")
    var err := ResourceLoader.load_threaded_request(MAIN_SCENE_PATH)
    if err != OK:
        push_error("[BOOT] Não foi possível iniciar o carregamento da Main: %s" % err)
        _show_fallback_menu("A interface principal não iniciou. Menu de segurança ativado.")
        return

    main_request_active = true
    set_process(true)

func _process(_delta: float) -> void:
    if not main_request_active:
        return

    var progress: Array = []
    var load_status := ResourceLoader.load_threaded_get_status(MAIN_SCENE_PATH, progress)

    if load_status == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
        if progress.size() > 0:
            var percent := int(float(progress[0]) * 100.0)
            status_label.text = "Carregando... %d%%" % percent
        return

    if load_status == ResourceLoader.THREAD_LOAD_LOADED:
        main_request_active = false
        var packed := ResourceLoader.load_threaded_get(MAIN_SCENE_PATH) as PackedScene
        if packed == null:
            _show_fallback_menu("A interface principal não pôde ser carregada.")
            return

        main_instance = packed.instantiate()
        if main_instance == null:
            _show_fallback_menu("A interface principal não pôde ser iniciada.")
            return

        add_child(main_instance)
        print("[BOOT] Main adicionada à árvore")
        return

    if load_status == ResourceLoader.THREAD_LOAD_FAILED or load_status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
        main_request_active = false
        push_error("[BOOT] Falha ao carregar Main.tscn. Status: %s" % load_status)
        _show_fallback_menu("Falha ao carregar a interface. Menu de segurança ativado.")

func mark_game_ready() -> void:
    game_ready = true
    print("[BOOT] Main sinalizou pronta")
    if fallback_root != null and is_instance_valid(fallback_root):
        fallback_root.queue_free()
        fallback_root = null
    _hide_loading_overlay()

func _hide_loading_overlay() -> void:
    if loading_timer != null:
        loading_timer.stop()
    if watchdog != null:
        watchdog.stop()
    if overlay != null and is_instance_valid(overlay):
        overlay.visible = false

func _start_watchdog() -> void:
    watchdog = Timer.new()
    watchdog.process_mode = Node.PROCESS_MODE_ALWAYS
    watchdog.one_shot = true
    watchdog.wait_time = 7.0
    add_child(watchdog)
    watchdog.timeout.connect(_on_watchdog_timeout)
    watchdog.start()

func _on_watchdog_timeout() -> void:
    if game_ready:
        return

    push_warning("[BOOT] Timeout de inicialização; ativando menu de segurança")

    if main_instance != null and is_instance_valid(main_instance) and main_instance.has_method("force_open_menu"):
        main_instance.call_deferred("force_open_menu")
        await get_tree().create_timer(0.35, true, false, true).timeout
        if not game_ready:
            _show_fallback_menu("Inicialização demorou mais que o esperado. Menu de segurança ativado.")
        return

    _show_fallback_menu("Inicialização demorou mais que o esperado. Menu de segurança ativado.")

func _start_loading_animation() -> void:
    loading_timer = Timer.new()
    loading_timer.process_mode = Node.PROCESS_MODE_ALWAYS
    loading_timer.wait_time = 0.45
    loading_timer.one_shot = false
    add_child(loading_timer)
    loading_timer.timeout.connect(_animate_loading)
    loading_timer.start()

func _animate_loading() -> void:
    if main_request_active:
        return
    loading_tick = (loading_tick + 1) % 4
    status_label.text = "Carregando" + ".".repeat(loading_tick)

func _show_fallback_menu(message: String) -> void:
    _hide_loading_overlay()

    if fallback_root != null and is_instance_valid(fallback_root):
        return

    fallback_root = Control.new()
    fallback_root.name = "FallbackMainMenu"
    fallback_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(fallback_root)

    var tex := load(MENU_BG_PATH) as Texture2D
    var fill := TextureRect.new()
    fill.texture = tex
    fill.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    fill.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    fill.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    fill.modulate = Color(0.62, 0.62, 0.68, 1.0)
    fallback_root.add_child(fill)

    var bg := TextureRect.new()
    bg.texture = tex
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    fallback_root.add_child(bg)

    var shade := ColorRect.new()
    shade.color = Color(0.01, 0.02, 0.04, 0.32)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    fallback_root.add_child(shade)

    var panel := ColorRect.new()
    panel.color = Color(0.012, 0.027, 0.052, 0.88)
    panel.position = Vector2(38, 26)
    panel.size = Vector2(500, 668)
    fallback_root.add_child(panel)

    var box := VBoxContainer.new()
    box.position = Vector2(28, 24)
    box.size = Vector2(444, 610)
    box.add_theme_constant_override("separation", 10)
    panel.add_child(box)

    box.add_child(_make_label("LVSR GAMES", 18))
    box.add_child(_make_label("O MUNDO CLT", 44))
    box.add_child(_make_label("Sobrevivendo ao Expediente", 19))

    var spacer := Control.new()
    spacer.custom_minimum_size = Vector2(1, 18)
    box.add_child(spacer)

    var continue_button := _make_button("CONTINUAR")
    continue_button.disabled = true
    box.add_child(continue_button)

    var new_game := _make_button("NOVO JOGO")
    box.add_child(new_game)
    new_game.pressed.connect(_try_open_main_menu)

    var retry := _make_button("TENTAR CARREGAR NOVAMENTE")
    box.add_child(retry)
    retry.pressed.connect(_retry_main_load)

    var quit := _make_button("SAIR")
    box.add_child(quit)
    quit.pressed.connect(func(): get_tree().quit())

    var info := _make_label(message, 13)
    info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    info.modulate = Color(1, 1, 1, 0.72)
    box.add_child(info)

    box.add_child(_make_label("Alpha v0.29.19 • inicialização protegida", 12))

func _retry_main_load() -> void:
    if main_request_active:
        return
    if main_instance != null and is_instance_valid(main_instance):
        _try_open_main_menu()
        return

    status_label.text = "Tentando novamente..."
    overlay.visible = true
    if fallback_root != null and is_instance_valid(fallback_root):
        fallback_root.queue_free()
        fallback_root = null

    var err := ResourceLoader.load_threaded_request(MAIN_SCENE_PATH)
    if err != OK:
        _show_fallback_menu("A nova tentativa falhou ao iniciar.")
        return
    main_request_active = true
    _start_watchdog()

func _try_open_main_menu() -> void:
    if main_instance != null and is_instance_valid(main_instance):
        if main_instance.has_method("force_open_menu"):
            main_instance.call_deferred("force_open_menu")
        if fallback_root != null and is_instance_valid(fallback_root):
            fallback_root.queue_free()
            fallback_root = null
        return
    _retry_main_load()

func _make_label(text_value: String, font_size: int) -> Label:
    var out := Label.new()
    out.text = text_value
    out.add_theme_font_size_override("font_size", font_size)
    return out

func _make_button(text_value: String) -> Button:
    var out := Button.new()
    out.text = text_value
    out.custom_minimum_size = Vector2(430, 54)
    out.add_theme_font_size_override("font_size", 17)
    return out

func _install_boot_background() -> void:
    var tex := load("res://assets/backgrounds/intro_lr_global.png") as Texture2D
    if tex == null:
        return

    var fill := TextureRect.new()
    fill.name = "BootBackgroundFill"
    fill.texture = tex
    fill.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    fill.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    fill.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    fill.modulate = Color(0.42, 0.42, 0.48, 1.0)
    add_child(fill)

    var bg := TextureRect.new()
    bg.name = "BootBackground"
    bg.texture = tex
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bg.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    add_child(bg)

    move_child(fill, 0)
    move_child(bg, 1)
