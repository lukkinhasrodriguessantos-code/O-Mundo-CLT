# Build Info — O MUNDO CLT v0.29.20

## v0.29.20 — Fluxo de entrada reorganizado

- `Boot.tscn` ficou leve e cuida somente da abertura cinematográfica.
- A abertura usa `intro_lr_global.png`; o menu usa uma arte separada em `menu_final.png`.
- O menu principal não depende mais de `Main.tscn` para aparecer.
- Menu restaurado no layout planejado: CONTINUAR, NOVO JOGO, LOJA, RESGATAR RECOMPENSA, EM BREVE e CONFIGURAÇÕES.
- Mensagens técnicas de “menu de segurança” e “inicialização protegida” foram removidas da interface do jogador.
- `NOVO JOGO` abre uma cena própria de criação do personagem, seguida pela contratação.
- A `Main.tscn` pesada é pré-carregada silenciosamente e só entra quando a campanha precisa começar/continuar.
- `RuntimeLoader.tscn` mostra somente o progresso normal e possui Voltar ao Menu em vez de deixar o jogador preso.
- Nenhum aviso de “menu de segurança”, “inicialização demorou” ou “carregamento demorando” é exibido ao jogador.
- `Main.gd` aceita os modos de entrada `new_game` e `continue` e pula a abertura duplicada ao iniciar a campanha.
- Splash interna do Godot continua desativada (`boot_splash/show_image=false`).
- Workflow Android ganhou preflight e smoke test das cenas principais antes de gerar o APK.
- O APK aprovado é publicado como artefato e recebe commit/push automático na branch `main`.

Fluxo esperado:

`APK → abertura + música → menu final → Novo Jogo → criação do personagem → contratação → carregamento do expediente → gameplay`
