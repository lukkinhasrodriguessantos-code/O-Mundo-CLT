# Requisitos para compilar o Alpha Android

Base alvo: Godot 4.7.2 stable, projeto GDScript e preset `Android Alpha`.

Antes da v0.30, executar nesta ordem:

1. Instalar/usar Godot 4.7.2 e os export templates da mesma versão.
2. Configurar Android SDK/JDK conforme a documentação do Godot.
3. Rodar `tools/validate_with_godot.sh` para importar o projeto e detectar erros reais de parser/scene.
4. Rodar `tools/build_android_alpha.sh` para gerar o APK debug ARM64.
5. Instalar no Android e executar o checklist de `ANDROID_ALPHA_EXPORT.md`.
6. Só renomear o marco para v0.30 quando o APK real for gerado e abrir no aparelho.

Os scripts falham de propósito se Godot/templates/SDK não estiverem disponíveis; eles não criam APK falso.
