extends Control

const MENU_SCENE := "res://scenes/MainMenu.tscn"
const LOADER_SCENE := "res://scenes/RuntimeLoader.tscn"
const BG_PATH := "res://assets/backgrounds/intro_lr_global.png"

func _ready() -> void:
    get_tree().paused = false
    _build_ui()

func _build_ui() -> void:
    var tex = load(BG_PATH) as Texture2D
    var image = TextureRect.new()
    image.texture = tex
    image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    image.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(image)

    var shade = ColorRect.new()
    shade.color = Color(0.005, 0.012, 0.03, 0.38)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(shade)

    var dialogue = PanelContainer.new()
    dialogue.anchor_left = 0.045
    dialogue.anchor_right = 0.955
    dialogue.anchor_top = 0.69
    dialogue.anchor_bottom = 0.955
    var style = StyleBoxFlat.new()
    style.bg_color = Color(0.008, 0.02, 0.045, 0.94)
    style.corner_radius_top_left = 12
    style.corner_radius_top_right = 12
    style.corner_radius_bottom_left = 12
    style.corner_radius_bottom_right = 12
    dialogue.add_theme_stylebox_override("panel", style)
    add_child(dialogue)

    var margin = MarginContainer.new()
    margin.add_theme_constant_override("margin_left", 24)
    margin.add_theme_constant_override("margin_right", 24)
    margin.add_theme_constant_override("margin_top", 18)
    margin.add_theme_constant_override("margin_bottom", 18)
    dialogue.add_child(margin)

    var box = VBoxContainer.new()
    box.add_theme_constant_override("separation", 8)
    margin.add_child(box)

    var name = str(get_tree().root.get_meta("mundo_clt_player_name", "Funcionário"))
    var area = str(get_tree().root.get_meta("mundo_clt_area", "Gestão de Frotas"))

    var speaker = Label.new()
    speaker.text = "DIRETOR LUCAS"
    speaker.add_theme_font_size_override("font_size", 17)
    speaker.modulate = Color(0.48, 0.76, 1.0, 1.0)
    box.add_child(speaker)

    var line = Label.new()
    line.text = "Bom dia, %s. Seja bem-vindo à LR Global.\nVocê está sendo contratado como Assistente de %s." % [name, area]
    line.add_theme_font_size_override("font_size", 22)
    line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(line)

    var actions = HBoxContainer.new()
    actions.add_theme_constant_override("separation", 12)
    box.add_child(actions)

    var back = Button.new()
    back.text = "VOLTAR"
    back.custom_minimum_size = Vector2(180, 48)
    back.pressed.connect(func(): get_tree().change_scene_to_file(MENU_SCENE))
    actions.add_child(back)

    var start = Button.new()
    start.text = "RECEBER CRACHÁ E COMEÇAR"
    start.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    start.custom_minimum_size = Vector2(0, 52)
    start.add_theme_font_size_override("font_size", 16)
    start.pressed.connect(_start_game)
    actions.add_child(start)

func _start_game() -> void:
    get_tree().root.set_meta("mundo_clt_entry_mode", "new_game")
    get_tree().change_scene_to_file(LOADER_SCENE)

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        get_tree().change_scene_to_file(MENU_SCENE)
