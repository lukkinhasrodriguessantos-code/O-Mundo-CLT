extends Node

const SETTINGS_PATH := "user://audio_settings.json"
const MENU_TRACK_PATH := "res://assets/audio/menu_theme.wav"

# O menu é o contexto inicial porque este manager é carregado como Autoload,
# antes mesmo da cena de boot. Isso garante música já na abertura do APK.
var current_context := "menu"
var volumes := {"master":100.0,"music":72.0,"sfx":80.0,"voice":85.0,"ambient":65.0}
var music_player: AudioStreamPlayer
var ambient_player: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var voice_player: AudioStreamPlayer
var startup_retry_done := false

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _ensure_players()
    _load_settings()
    _apply_volumes()
    # Android pode inicializar o dispositivo de áudio alguns frames depois da árvore.
    # Iniciamos imediatamente e fazemos uma segunda tentativa curta se necessário.
    call_deferred("_start_initial_audio")

func _ensure_players() -> void:
    music_player = get_node_or_null("Music") as AudioStreamPlayer
    if music_player == null:
        music_player = AudioStreamPlayer.new()
        music_player.name = "Music"
        music_player.process_mode = Node.PROCESS_MODE_ALWAYS
        add_child(music_player)

    ambient_player = get_node_or_null("Ambient") as AudioStreamPlayer
    if ambient_player == null:
        ambient_player = AudioStreamPlayer.new()
        ambient_player.name = "Ambient"
        ambient_player.process_mode = Node.PROCESS_MODE_ALWAYS
        add_child(ambient_player)

    sfx_player = get_node_or_null("SFX") as AudioStreamPlayer
    if sfx_player == null:
        sfx_player = AudioStreamPlayer.new()
        sfx_player.name = "SFX"
        sfx_player.process_mode = Node.PROCESS_MODE_ALWAYS
        add_child(sfx_player)

    voice_player = get_node_or_null("Voice") as AudioStreamPlayer
    if voice_player == null:
        voice_player = AudioStreamPlayer.new()
        voice_player.name = "Voice"
        voice_player.process_mode = Node.PROCESS_MODE_ALWAYS
        add_child(voice_player)

    if not music_player.finished.is_connected(_on_music_finished):
        music_player.finished.connect(_on_music_finished)

func _start_initial_audio() -> void:
    await get_tree().process_frame
    if current_context == "menu":
        _play_menu_music()
    await get_tree().create_timer(0.45, true).timeout
    if current_context == "menu" and music_player != null and not music_player.playing:
        startup_retry_done = true
        print("[AUDIO] Segunda tentativa de início da trilha")
        _play_menu_music()

func set_context(context:String) -> void:
    current_context = context
    if not is_inside_tree():
        return
    _ensure_players()
    if context == "menu":
        if not music_player.playing:
            _play_menu_music()
    elif music_player.playing:
        music_player.stop()
    print("[AUDIO] Contexto: ", context, " | trilha: ", track_name(context))

func _play_menu_music() -> void:
    _ensure_players()
    if music_player == null:
        return
    if music_player.playing:
        return
    var stream := load(MENU_TRACK_PATH) as AudioStream
    if stream == null:
        push_warning("Trilha de menu ausente: " + MENU_TRACK_PATH)
        return
    music_player.stream = stream
    _apply_volumes()
    music_player.play(0.0)
    print("[AUDIO] Tema do menu iniciado | volume música: ", volumes.get("music", 72.0))

func _on_music_finished() -> void:
    if current_context == "menu" and music_player != null:
        music_player.play(0.0)

func track_name(context:String) -> String:
    return {"menu":"Tema O Mundo CLT","work":"Expediente LR Global","home":"Fim de Expediente","city":"Cidade Depois das 18"}.get(context,"Ambiente LR Global")

func play_stinger(kind:String) -> void:
    print("[AUDIO] Vinheta: ", kind)

func get_volume(channel:String) -> float:
    return float(volumes.get(channel,70.0))

func set_volume(channel:String,value:float) -> void:
    volumes[channel] = clamp(value,0.0,100.0)
    _apply_volumes()
    _save_settings()
    if channel in ["master", "music"] and current_context == "menu" and music_player != null and not music_player.playing and float(volumes.get("master",100.0)) > 0.0 and float(volumes.get("music",72.0)) > 0.0:
        _play_menu_music()

func _db(value:float) -> float:
    return -80.0 if value <= 0.0 else linear_to_db(value/100.0)

func _apply_volumes() -> void:
    var master := float(volumes.get("master",100.0)) / 100.0
    if music_player: music_player.volume_db = _db(float(volumes.get("music",72.0)) * master)
    if sfx_player: sfx_player.volume_db = _db(float(volumes.get("sfx",80.0)) * master)
    if voice_player: voice_player.volume_db = _db(float(volumes.get("voice",85.0)) * master)
    if ambient_player: ambient_player.volume_db = _db(float(volumes.get("ambient",65.0)) * master)

func reset_defaults() -> void:
    volumes = {"master":100.0,"music":72.0,"sfx":80.0,"voice":85.0,"ambient":65.0}
    _apply_volumes()
    _save_settings()
    if current_context == "menu" and music_player != null and not music_player.playing:
        _play_menu_music()

func _save_settings() -> void:
    var f = FileAccess.open(SETTINGS_PATH,FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(volumes))

func _load_settings() -> void:
    if not FileAccess.file_exists(SETTINGS_PATH):
        return
    var f = FileAccess.open(SETTINGS_PATH,FileAccess.READ)
    if not f:
        return
    var data = JSON.parse_string(f.get_as_text())
    if typeof(data) == TYPE_DICTIONARY:
        for k in volumes.keys():
            volumes[k] = float(data.get(k,volumes[k]))
