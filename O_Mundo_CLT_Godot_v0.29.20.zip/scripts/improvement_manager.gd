extends Node
class_name ImprovementManager

var active_project_id := ""
var completed_projects := {}
var project_progress := {}
var permanent_effects := {}
var discovered_projects:Array = []

var catalog := {
    "frotas_preventiva": {"title":"Controle de Manutenção Preventiva","area":"Gestão de Frotas","category":"Operacional","steps":["Identificar falhas recorrentes","Levantar veículos e prazos","Implantar controle preventivo","Acompanhar resultado"],"xp":35,"rep":5,"effect":"reduz_falha_evitavel"},
    "programacao_romaneio": {"title":"Fluxo de Carga e Romaneio","area":"Programação","category":"Qualidade","steps":["Mapear erros recorrentes","Revisar informações obrigatórias","Implantar conferência","Acompanhar resultado"],"xp":35,"rep":5,"effect":"reduz_erro_romaneio"},
    "atendimento_retorno": {"title":"Controle de Retorno ao Motorista","area":"Atendimento","category":"Qualidade","steps":["Mapear retornos pendentes","Definir prioridade","Implantar acompanhamento","Acompanhar resultado"],"xp":35,"rep":5,"effect":"antecipa_retorno"},
    "conteiner_operacao": {"title":"Acompanhamento Operacional de Contêineres","area":"Operação de Contêineres Vazios","category":"Tecnologia","steps":["Identificar gargalos","Conferir movimentações","Implantar painel de acompanhamento","Acompanhar resultado"],"xp":40,"rep":6,"effect":"painel_operacional"}
}

func get_project_for_area(area_name:String) -> String:
    for id in catalog:
        if str(catalog[id].get("area","")) == area_name:
            return id
    return "frotas_preventiva"

func discover_project(project_id:String) -> bool:
    if not catalog.has(project_id) or discovered_projects.has(project_id): return false
    discovered_projects.append(project_id)
    return true

func start_project(project_id:String) -> bool:
    if not catalog.has(project_id) or completed_projects.has(project_id): return false
    if not discovered_projects.is_empty() and not discovered_projects.has(project_id): return false
    active_project_id=project_id
    if not project_progress.has(project_id): project_progress[project_id]=0
    return true

func advance_active_project() -> Dictionary:
    if active_project_id=="" or not catalog.has(active_project_id): return {}
    var id=active_project_id
    var data:Dictionary=catalog[id]
    var step=int(project_progress.get(id,0))+1
    project_progress[id]=step
    var finished=step>=data.get("steps",[]).size()
    if finished:
        completed_projects[id]=true
        permanent_effects[str(data.get("effect",""))]=true
        active_project_id=""
    return {"id":id,"title":data.get("title","Projeto"),"step":step,"total":data.get("steps",[]).size(),"finished":finished,"xp":int(data.get("xp",0)) if finished else 8,"rep":int(data.get("rep",0)) if finished else 1,"effect":data.get("effect","") if finished else ""}

func active_status() -> String:
    if active_project_id=="": return "Nenhum projeto de melhoria ativo."
    var data:Dictionary=catalog[active_project_id]
    var step=int(project_progress.get(active_project_id,0))
    var steps:Array=data.get("steps",[])
    if step>=steps.size(): return "Projeto concluído."
    return "%s\n%s • Etapa %d/%d\nPróximo: %s" % [data.get("title","Projeto"),data.get("category","Melhoria"),step+1,steps.size(),steps[step]]

func export_state() -> Dictionary:
    return {"active_project_id":active_project_id,"completed_projects":completed_projects,"project_progress":project_progress,"permanent_effects":permanent_effects,"discovered_projects":discovered_projects}

func import_state(data:Dictionary) -> void:
    active_project_id=str(data.get("active_project_id",""))
    completed_projects=data.get("completed_projects",{})
    project_progress=data.get("project_progress",{})
    permanent_effects=data.get("permanent_effects",{})
    discovered_projects=data.get("discovered_projects",[])
