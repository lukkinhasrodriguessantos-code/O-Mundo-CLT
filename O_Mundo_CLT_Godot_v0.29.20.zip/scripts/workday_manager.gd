extends Node
class_name WorkdayManager

const WEEKDAYS := ["SEGUNDA-FEIRA", "TERÇA-FEIRA", "QUARTA-FEIRA", "QUINTA-FEIRA", "SEXTA-FEIRA"]

var current_day := 1
var current_week := 1
var total_completed_days := 0
var current_area := "Gestão de Frotas"
var active_tasks:Array = []
var history:Array = []
var daily_history:Array = []
var rapidinho_seen := false
var interruption_seen := false
var recurrence_counts := {}
var recurrence_last_seen := {}
var unlocked_improvements:Array = []
var permanent_effects := {}

var area_tasks := {
    "Gestão de Frotas": [
        {"id":"frotas_checklist","title":"Conferir checklist dos veículos","priority":"normal","xp":8,"rep":1,"tag":"checklist"},
        {"id":"frotas_roda","title":"Veículo com roda aquecendo","priority":"critica","xp":18,"rep":3,"tag":"manutencao"},
        {"id":"frotas_gerot","title":"Atualizar manutenção no GEROT","priority":"importante","xp":12,"rep":2,"tag":"manutencao"}
    ],
    "Programação": [
        {"id":"prog_vinculo","title":"Conferir vínculo motorista/veículo","priority":"normal","xp":8,"rep":1,"tag":"vinculo"},
        {"id":"prog_romaneio","title":"Romaneio com informação divergente","priority":"critica","xp":18,"rep":3,"tag":"romaneio"},
        {"id":"prog_carga","title":"Reprogramar carga pendente","priority":"importante","xp":12,"rep":2,"tag":"carga"}
    ],
    "Atendimento": [
        {"id":"atend_motorista","title":"Retornar motorista pendente","priority":"normal","xp":8,"rep":1,"tag":"retorno"},
        {"id":"atend_cliente","title":"Cliente aguardando posição urgente","priority":"critica","xp":18,"rep":3,"tag":"retorno"},
        {"id":"atend_fila","title":"Organizar fila de retornos","priority":"importante","xp":12,"rep":2,"tag":"retorno"}
    ],
    "Operação de Contêineres Vazios": [
        {"id":"cont_mov","title":"Conferir movimentações do pátio","priority":"normal","xp":8,"rep":1,"tag":"operacao"},
        {"id":"cont_div","title":"Divergência operacional de contêiner","priority":"critica","xp":18,"rep":3,"tag":"operacao"},
        {"id":"cont_acomp","title":"Atualizar acompanhamento operacional","priority":"importante","xp":12,"rep":2,"tag":"operacao"}
    ]
}


var first_week_story_tasks := {
    "Gestão de Frotas": {
        2:{"id":"w1_frotas_tue","title":"Acompanhar retorno de veículo da manutenção","priority":"importante","xp":12,"rep":2,"tag":"manutencao"},
        3:{"id":"w1_frotas_wed","title":"Tratar veículo sem força em subida antes da próxima viagem","priority":"critica","xp":18,"rep":3,"tag":"manutencao"},
        4:{"id":"w1_frotas_thu","title":"Organizar prioridades da oficina e atualizar previsão de liberação","priority":"importante","xp":14,"rep":2,"tag":"manutencao"},
        5:{"id":"w1_frotas_fri","title":"Fechar pendências da frota e registrar o que fica para segunda","priority":"importante","xp":15,"rep":2,"tag":"fechamento"}
    },
    "Programação": {
        2:{"id":"w1_prog_tue","title":"Validar motorista e veículo antes de vincular a carga","priority":"importante","xp":12,"rep":2,"tag":"vinculo"},
        3:{"id":"w1_prog_wed","title":"Corrigir divergência de romaneio sem atrasar a operação","priority":"critica","xp":18,"rep":3,"tag":"romaneio"},
        4:{"id":"w1_prog_thu","title":"Reorganizar sequência de cargas após alteração operacional","priority":"importante","xp":14,"rep":2,"tag":"carga"},
        5:{"id":"w1_prog_fri","title":"Fechar programação da semana e registrar cargas pendentes","priority":"importante","xp":15,"rep":2,"tag":"fechamento"}
    },
    "Atendimento": {
        2:{"id":"w1_atend_tue","title":"Atualizar motorista que aguarda retorno da operação","priority":"importante","xp":12,"rep":2,"tag":"retorno"},
        3:{"id":"w1_atend_wed","title":"Responder cliente urgente sem inventar previsão","priority":"critica","xp":18,"rep":3,"tag":"retorno"},
        4:{"id":"w1_atend_thu","title":"Organizar fila de retornos e priorizar casos críticos","priority":"importante","xp":14,"rep":2,"tag":"retorno"},
        5:{"id":"w1_atend_fri","title":"Fechar retornos da semana e registrar acompanhamentos de segunda","priority":"importante","xp":15,"rep":2,"tag":"fechamento"}
    },
    "Operação de Contêineres Vazios": {
        2:{"id":"w1_cont_tue","title":"Conferir sequência de movimentações do pátio","priority":"importante","xp":12,"rep":2,"tag":"operacao"},
        3:{"id":"w1_cont_wed","title":"Resolver divergência de posição antes da movimentação","priority":"critica","xp":18,"rep":3,"tag":"operacao"},
        4:{"id":"w1_cont_thu","title":"Reorganizar fluxo do pátio após mudança de prioridade","priority":"importante","xp":14,"rep":2,"tag":"operacao"},
        5:{"id":"w1_cont_fri","title":"Fechar movimentações da semana e registrar pendências","priority":"importante","xp":15,"rep":2,"tag":"fechamento"}
    }
}

func get_day_briefing() -> Dictionary:
    if current_week == 1:
        match current_day:
            1:
                return {"title":"PRIMEIRO DIA","description":"Conheça o setor, registre o ponto e conclua sua primeira demanda.","tip":"Observe o ambiente antes de tentar resolver tudo de uma vez."}
            2:
                return {"title":"PEGANDO O RITMO","description":"Hoje você começa a assumir a rotina real do setor.","tip":"Prioridade importante não deve ficar esquecida no fim do dia."}
            3:
                return {"title":"PRIMEIRO IMPREVISTO","description":"A operação apertou. Uma ocorrência crítica exige decisão e comunicação.","tip":"Crítica sem tratamento pesa bastante na reputação."}
            4:
                return {"title":"ORGANIZAÇÃO","description":"Nem tudo cabe no mesmo dia. Resolva, priorize e encaminhe corretamente.","tip":"Comunicar uma pendência é melhor do que simplesmente abandoná-la."}
            5:
                return {"title":"FECHAMENTO DA SEMANA","description":"Feche o que for crítico e deixe a segunda-feira organizada.","tip":"O fechamento considera a semana inteira, não apenas a sexta-feira."}
    var titles := ["PRIORIDADES DA SEMANA","ROTINA OPERACIONAL","IMPREVISTOS DO DIA","ORGANIZAÇÃO E PRAZOS","FECHAMENTO SEMANAL"]
    return {
        "title":titles[clampi(current_day - 1, 0, titles.size() - 1)],
        "description":"As demandas variam conforme sua área, cargo e melhorias já implantadas.",
        "tip":"Use o histórico e os projetos de melhoria para reduzir problemas recorrentes."
    }

func _base_task_indexes(task_count:int) -> Array:
    if task_count <= 2:
        var indexes:Array = []
        for i in range(task_count):
            indexes.append(i)
        return indexes
    if current_week == 1:
        match current_day:
            2: return [0,1]
            3: return [1,2]
            4: return [0,2]
            5: return [0,1,2]
    var start := (current_day + current_week) % task_count
    return [start, (start + 1) % task_count]

func _first_week_story_task(area_name:String) -> Dictionary:
    if current_week != 1 or current_day < 2:
        return {}
    var area_story:Dictionary = first_week_story_tasks.get(area_name, first_week_story_tasks["Gestão de Frotas"])
    return area_story.get(current_day, {}).duplicate(true)

var weekday_interruptions := [
    {"id":"int_reuniao","title":"Reunião rápida para alinhar prioridades","priority":"normal","xp":5,"rep":1,"tag":"rotina"},
    {"id":"int_colega","title":"Colega pede ajuda em uma conferência","priority":"normal","xp":6,"rep":1,"tag":"ajuda"},
    {"id":"int_sistema","title":"Sistema ficou lento no meio da operação","priority":"importante","xp":9,"rep":1,"tag":"sistema"},
    {"id":"int_prazo","title":"Gestão cobra posição de uma pendência","priority":"importante","xp":10,"rep":2,"tag":"prazo"},
    {"id":"int_fechamento","title":"Conferir pendências antes do fechamento semanal","priority":"importante","xp":12,"rep":2,"tag":"fechamento"}
]


func register_tutorial_day(area_name:String) -> bool:
    if total_completed_days > 0 or not daily_history.is_empty():
        return false
    current_area = area_name
    var summary := {
        "week":1,
        "day":1,
        "day_label":"SEGUNDA-FEIRA",
        "total":1,
        "resolved":1,
        "communicated":0,
        "pending":0,
        "critical_pending":0,
        "rep":3,
        "xp_bonus":0,
        "weekly_close":false,
        "tutorial_day":true
    }
    history.append({"week":1,"day":1,"result":"primeiro_dia","summary":summary.duplicate(true)})
    daily_history.push_front(summary.duplicate(true))
    total_completed_days = 1
    current_day = 2
    current_week = 1
    active_tasks = []
    rapidinho_seen = false
    interruption_seen = false
    return true

func set_permanent_effects(effects:Dictionary) -> void:
    permanent_effects = effects.duplicate(true)

func get_day_label() -> String:
    var index = clampi(current_day - 1, 0, WEEKDAYS.size() - 1)
    return WEEKDAYS[index]

func ensure_day(area_name:String, career_role:String="Assistente") -> void:
    if not active_tasks.is_empty():
        return
    current_area = area_name
    var source:Array = area_tasks.get(area_name, area_tasks["Gestão de Frotas"])
    for source_index in _base_task_indexes(source.size()):
        var task:Dictionary = source[int(source_index)].duplicate(true)
        _apply_improvement_effect(task)
        task["status"] = "pendente"
        task["source"] = "area"
        active_tasks.append(task)

    var story_task := _first_week_story_task(area_name)
    if not story_task.is_empty():
        _apply_improvement_effect(story_task)
        story_task["status"] = "pendente"
        story_task["source"] = "historia_semana1"
        active_tasks.append(story_task)

    var interruption:Dictionary = weekday_interruptions[clampi(current_day - 1, 0, weekday_interruptions.size() - 1)].duplicate(true)
    interruption["status"] = "pendente"
    interruption["source"] = "interrupcao"
    active_tasks.append(interruption)
    interruption_seen = true

    if career_role != "Assistente":
        var autonomy := _get_autonomy_task(area_name)
        autonomy["status"] = "pendente"
        autonomy["source"] = "autonomia"
        active_tasks.append(autonomy)

func _get_autonomy_task(area_name:String) -> Dictionary:
    match area_name:
        "Programação":
            return {"id":"jr_prog_analise","title":"Analisar impacto de uma reprogramação e propor alternativa","priority":"importante","xp":15,"rep":2,"tag":"carga"}
        "Atendimento":
            return {"id":"jr_atend_prioridade","title":"Organizar retornos críticos e definir sequência de comunicação","priority":"importante","xp":15,"rep":2,"tag":"retorno"}
        "Operação de Contêineres Vazios":
            return {"id":"jr_cont_fluxo","title":"Analisar gargalo do pátio e ajustar sequência operacional","priority":"importante","xp":16,"rep":2,"tag":"operacao"}
        _:
            return {"id":"jr_frotas_custo","title":"Analisar custo, prazo e prioridade de veículos em manutenção","priority":"importante","xp":15,"rep":2,"tag":"manutencao"}

func _apply_improvement_effect(task:Dictionary) -> void:
    var id := str(task.get("id", ""))
    if permanent_effects.get("reduz_falha_evitavel", false) and id == "frotas_roda":
        task["title"] = "Alerta preventivo: conferir aquecimento de roda antes da saída"
        task["priority"] = "importante"
        task["xp"] = 12
        task["rep"] = 2
        task["improvement_effect"] = "Controle Preventivo evitou uma ocorrência crítica."
    elif permanent_effects.get("reduz_erro_romaneio", false) and id == "prog_romaneio":
        task["title"] = "Conferência preventiva do romaneio antes da liberação"
        task["priority"] = "importante"
        task["xp"] = 12
        task["rep"] = 2
        task["improvement_effect"] = "Fluxo revisado detectou a divergência antes da operação."
    elif permanent_effects.get("antecipa_retorno", false) and id == "atend_cliente":
        task["title"] = "Retorno antecipado ao cliente sinalizado pelo acompanhamento"
        task["priority"] = "importante"
        task["xp"] = 12
        task["rep"] = 2
        task["improvement_effect"] = "Controle de retornos antecipou a cobrança urgente."
    elif permanent_effects.get("painel_operacional", false) and id == "cont_div":
        task["title"] = "Painel sinalizou divergência de contêiner antes da movimentação"
        task["priority"] = "importante"
        task["xp"] = 13
        task["rep"] = 2
        task["improvement_effect"] = "Painel operacional reduziu o impacto da divergência."

func add_rapidinho() -> bool:
    if rapidinho_seen:
        return false
    rapidinho_seen = true
    active_tasks.append({
        "id":"rapidinho_1729",
        "title":"17:29 • Só uma coisinha rapidinho",
        "priority":"importante",
        "xp":10,
        "rep":2,
        "status":"pendente",
        "source":"evento"
    })
    return true

func resolve_task(index:int) -> Dictionary:
    if index < 0 or index >= active_tasks.size():
        return {}
    var task:Dictionary = active_tasks[index]
    if task.get("status", "") != "pendente":
        return {}
    task["status"] = "resolvida"
    active_tasks[index] = task
    history.append({"week":current_week,"day":current_day,"title":task.get("title","Demanda"),"result":"resolvida"})
    var unlocked := _record_recurrence(str(task.get("title", "Demanda")), str(task.get("tag", "")))
    return {
        "xp":int(task.get("xp",0)),
        "rep":int(task.get("rep",0)),
        "message":"Demanda resolvida.",
        "improvement_unlocked":unlocked,
        "improvement_effect":str(task.get("improvement_effect", ""))
    }

func communicate_task(index:int) -> Dictionary:
    if index < 0 or index >= active_tasks.size():
        return {}
    var task:Dictionary = active_tasks[index]
    if task.get("status", "") != "pendente":
        return {}
    task["status"] = "comunicada"
    active_tasks[index] = task
    history.append({"week":current_week,"day":current_day,"title":task.get("title","Demanda"),"result":"comunicada"})
    return {"xp":3,"rep":1,"message":"Pendência comunicada e encaminhada."}

func get_day_stats() -> Dictionary:
    var resolved := 0
    var communicated := 0
    var pending := 0
    var critical_pending := 0
    var important_pending := 0
    for task in active_tasks:
        match str(task.get("status", "pendente")):
            "resolvida": resolved += 1
            "comunicada": communicated += 1
            _:
                pending += 1
                match str(task.get("priority", "normal")):
                    "critica": critical_pending += 1
                    "importante": important_pending += 1
    return {
        "total":active_tasks.size(),
        "resolved":resolved,
        "communicated":communicated,
        "pending":pending,
        "critical_pending":critical_pending,
        "important_pending":important_pending
    }

func end_day() -> Dictionary:
    var stats := get_day_stats()
    var rep_delta := 0
    for task in active_tasks:
        if task.get("status", "") == "pendente":
            match task.get("priority", "normal"):
                "critica": rep_delta -= 3
                "importante": rep_delta -= 2
                _: rep_delta -= 1

    var xp_bonus := 0
    var rep_bonus := 0
    if int(stats.get("critical_pending", 0)) == 0:
        rep_bonus += 1
    if int(stats.get("pending", 0)) == 0 and int(stats.get("total", 0)) > 0:
        xp_bonus += 8
        rep_bonus += 1
    elif int(stats.get("communicated", 0)) > 0 and int(stats.get("critical_pending", 0)) == 0:
        xp_bonus += 4

    rep_delta += rep_bonus
    var finished_day_label := get_day_label()
    var finished_week := current_week
    var weekly_close := current_day == 5

    var summary := {
        "week":finished_week,
        "day":current_day,
        "day_label":finished_day_label,
        "total":stats.get("total",0),
        "resolved":stats.get("resolved",0),
        "communicated":stats.get("communicated",0),
        "pending":stats.get("pending",0),
        "critical_pending":stats.get("critical_pending",0),
        "rep":rep_delta,
        "xp_bonus":xp_bonus,
        "weekly_close":weekly_close,
        "focus":str(get_day_briefing().get("title", "EXPEDIENTE"))
    }
    total_completed_days += 1
    daily_history.push_front(summary.duplicate(true))
    if daily_history.size() > 15:
        daily_history.resize(15)
    if weekly_close:
        summary["week_summary"] = get_week_summary(finished_week)
    history.append({"week":finished_week,"day":current_day,"result":"fechamento","summary":summary.duplicate(true)})

    if weekly_close:
        current_day = 1
        current_week += 1
    else:
        current_day += 1

    summary["next_day"] = get_day_label()
    summary["next_week"] = current_week
    active_tasks = []
    rapidinho_seen = false
    interruption_seen = false
    return summary

func get_week_summary(week_number:int) -> Dictionary:
    var days := 0
    var resolved := 0
    var communicated := 0
    var pending := 0
    var critical_pending := 0
    var xp_bonus := 0
    var rep_delta := 0
    for day in daily_history:
        if int(day.get("week", 0)) != week_number:
            continue
        days += 1
        resolved += int(day.get("resolved", 0))
        communicated += int(day.get("communicated", 0))
        pending += int(day.get("pending", 0))
        critical_pending += int(day.get("critical_pending", 0))
        xp_bonus += int(day.get("xp_bonus", 0))
        rep_delta += int(day.get("rep", 0))
    var performance := "SEMANA EM DESENVOLVIMENTO"
    if days >= 5 and critical_pending == 0 and pending <= 2:
        performance = "SEMANA SÓLIDA"
    if days >= 5 and pending == 0:
        performance = "SEMANA ORGANIZADA"
    if critical_pending > 0:
        performance = "ATENÇÃO ÀS PENDÊNCIAS CRÍTICAS"
    return {
        "week":week_number,
        "days":days,
        "resolved":resolved,
        "communicated":communicated,
        "pending":pending,
        "critical_pending":critical_pending,
        "xp_bonus":xp_bonus,
        "rep_delta":rep_delta,
        "performance":performance
    }

func _record_recurrence(title:String, tag:String="") -> String:
    var project_id := _improvement_for_task(title, tag)
    if project_id == "":
        return ""
    var day_key := "%d-%d" % [current_week, current_day]
    if str(recurrence_last_seen.get(project_id, "")) == day_key:
        return ""
    recurrence_last_seen[project_id] = day_key
    recurrence_counts[project_id] = int(recurrence_counts.get(project_id, 0)) + 1
    if int(recurrence_counts[project_id]) >= 2 and not unlocked_improvements.has(project_id):
        unlocked_improvements.append(project_id)
        return project_id
    return ""

func _improvement_for_task(title:String, tag:String="") -> String:
    var t := title.to_lower()
    if tag in ["checklist", "manutencao"] or "checklist" in t or "roda" in t or "manutenção" in t:
        return "frotas_preventiva"
    if tag in ["romaneio", "vinculo", "carga"] or "romaneio" in t or "vínculo" in t or "carga" in t:
        return "programacao_romaneio"
    if tag == "retorno" or "motorista" in t or "cliente" in t or "retorno" in t:
        return "atendimento_retorno"
    if tag == "operacao" or "contêiner" in t or "pátio" in t or "operacional" in t:
        return "conteiner_operacao"
    return ""

func consume_unlocked_improvements() -> Array:
    var result := unlocked_improvements.duplicate()
    unlocked_improvements.clear()
    return result

func priority_icon(priority:String) -> String:
    match priority:
        "critica": return "🔴"
        "importante": return "🟠"
        _: return "⚪"

func export_state() -> Dictionary:
    return {
        "current_day":current_day,
        "current_week":current_week,
        "total_completed_days":total_completed_days,
        "current_area":current_area,
        "active_tasks":active_tasks,
        "history":history,
        "daily_history":daily_history,
        "rapidinho_seen":rapidinho_seen,
        "interruption_seen":interruption_seen,
        "recurrence_counts":recurrence_counts,
        "recurrence_last_seen":recurrence_last_seen,
        "unlocked_improvements":unlocked_improvements
    }

func import_state(data:Dictionary) -> void:
    current_day = clampi(int(data.get("current_day",1)), 1, 5)
    current_week = maxi(int(data.get("current_week",1)), 1)
    total_completed_days = maxi(int(data.get("total_completed_days", data.get("daily_history", []).size())), 0)
    current_area = str(data.get("current_area","Gestão de Frotas"))
    active_tasks = data.get("active_tasks",[])
    history = data.get("history",[])
    daily_history = data.get("daily_history",[])
    rapidinho_seen = bool(data.get("rapidinho_seen",false))
    interruption_seen = bool(data.get("interruption_seen",false))
    recurrence_counts = data.get("recurrence_counts",{})
    recurrence_last_seen = data.get("recurrence_last_seen",{})
    unlocked_improvements = data.get("unlocked_improvements",[])
