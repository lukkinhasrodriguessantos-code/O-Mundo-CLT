extends Control

const MENU_SCENE := "res://scenes/MainMenu.tscn"
const HIRING_SCENE := "res://scenes/Hiring.tscn"
const BG_PATH := "res://assets/backgrounds/menu_lr_global.png"

var name_input: LineEdit
var area_select: OptionButton

func _ready() -> void:
    get_tree().paused = false
    _build_ui()

func _background() -> Control:
    var root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var tex = load(BG_PATH) as Texture2D
    var image = TextureRect.new()
    image.texture = tex
    image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    image.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(image)
    var shade = ColorRect.new()
    shade.color = Color(0.005, 0.015, 0.035, 0.58)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(shade)
    return root

func _build_ui() -> void:
    var bg = _background()
    add_child(bg)

    var panel = PanelContainer.new()
    panel.anchor_left = 0.055
    panel.anchor_right = 0.47
    panel.anchor_top = 0.07
    panel.anchor_bottom = 0.93
    var style = StyleBoxFlat.new()
    style.bg_color = Color(0.01, 0.025, 0.052, 0.94)
    style.corner_radius_top_left = 14
    style.corner_radius_top_right = 14
    style.corner_radius_bottom_left = 14
    style.corner_radius_bottom_right = 14
    panel.add_theme_stylebox_override("panel", style)
    bg.add_child(panel)

    var margin = MarginContainer.new()
    for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
        margin.add_theme_constant_override(side, 28)
    panel.add_child(margin)

    var box = VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    margin.add_child(box)

    var title = Label.new()
    title.text = "NOVO JOGO"
    title.add_theme_font_size_override("font_size", 38)
    box.add_child(title)
    var sub = Label.new()
    sub.text = "Crie seu personagem"
    sub.add_theme_font_size_override("font_size", 18)
    sub.modulate = Color(1, 1, 1, 0.78)
    box.add_child(sub)

    name_input = LineEdit.new()
    name_input.placeholder_text = "Nome do personagem"
    name_input.custom_minimum_size = Vector2(0, 52)
    box.add_child(name_input)

    var sex = OptionButton.new()
    sex.add_item("Masculino")
    sex.add_item("Feminino")
    sex.custom_minimum_size = Vector2(0, 50)
    box.add_child(sex)

    var clothes = OptionButton.new()
    for item in ["Polo + Calça", "Camiseta + Jeans", "Camisa Social", "Casual"]:
        clothes.add_item(item)
    clothes.custom_minimum_size = Vector2(0, 50)
    box.add_child(clothes)

    area_select = OptionButton.new()
    for item in ["Gestão de Frotas", "Atendimento", "Programação", "Operação de Contêineres Vazios"]:
        area_select.add_item(item)
    area_select.select(0)
    area_select.custom_minimum_size = Vector2(0, 50)
    box.add_child(area_select)

    var role = Label.new()
    role.text = "Cargo inicial: ASSISTENTE\nUnidade: LR Global — Transportes"
    role.add_theme_font_size_override("font_size", 16)
    role.modulate = Color(1, 1, 1, 0.82)
    box.add_child(role)

    var spacer = Control.new()
    spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
    box.add_child(spacer)

    var start = Button.new()
    start.text = "CONTINUAR PARA CONTRATAÇÃO"
    start.custom_minimum_size = Vector2(0, 56)
    start.add_theme_font_size_override("font_size", 17)
    start.pressed.connect(_continue)
    box.add_child(start)

    var back = Button.new()
    back.text = "VOLTAR AO MENU"
    back.custom_minimum_size = Vector2(0, 48)
    back.pressed.connect(func(): get_tree().change_scene_to_file(MENU_SCENE))
    box.add_child(back)

func _continue() -> void:
    var player_name = name_input.text.strip_edges()
    if player_name == "":
        player_name = "Funcionário"
    get_tree().root.set_meta("mundo_clt_player_name", player_name)
    get_tree().root.set_meta("mundo_clt_area", area_select.get_item_text(area_select.selected))
    get_tree().change_scene_to_file(HIRING_SCENE)

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        get_tree().change_scene_to_file(MENU_SCENE)
