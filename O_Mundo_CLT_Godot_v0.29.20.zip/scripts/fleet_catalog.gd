extends RefCounted
class_name FleetCatalog

# Códigos de frota 100% fictícios para a LR Global.
# Não representam placas oficiais brasileiras nem veículos reais.
const CHECKLIST_RETURN := "LVS-001"
const CHECKLIST_PREVENTIVE := "VSR-101"
const CHECKLIST_EXIT := "LRG-201"
const URGENT_BRAKE := "LSR-301"

const CODES := [
    "LVS-001", "LVS-002", "LVS-003", "LVS-004",
    "VSR-101", "VSR-102", "VSR-103", "VSR-104",
    "LRG-201", "LRG-202", "LRG-203", "LRG-204",
    "LSR-301", "LSR-302", "LSR-303", "LSR-304",
    "RGL-401", "RGL-402", "RGL-403", "RGL-404"
]

static func display(code: String) -> String:
    return "FROTA %s" % code

static func is_valid(code: String) -> bool:
    return code in CODES
