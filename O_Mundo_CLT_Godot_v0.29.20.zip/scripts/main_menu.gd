extends Control

const BG_PATH := "res://assets/backgrounds/menu_final.png"
const RUNTIME_SCENE := "res://scenes/Main.tscn"
const NEW_GAME_SCENE := "res://scenes/NewGame.tscn"
const LOADER_SCENE := "res://scenes/RuntimeLoader.tscn"
const SAVE_PATH := "user://mundo_clt_save.json"

var toast_label: Label
var modal_layer: Control

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    get_tree().paused = false
    var audio = get_node_or_null("/root/AudioManager")
    if audio != null and audio.has_method("set_context"):
        audio.set_context("menu")
    _build_background()
    _build_hitboxes()
    _build_toast()
    _preload_runtime_silently()

func _build_background() -> void:
    var tex = load(BG_PATH) as Texture2D
    var fill = TextureRect.new()
    fill.texture = tex
    fill.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    fill.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    fill.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    fill.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(fill)

    modal_layer = Control.new()
    modal_layer.name = "ModalLayer"
    modal_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    modal_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(modal_layer)

func _button_style(alpha: float) -> StyleBoxFlat:
    var style = StyleBoxFlat.new()
    style.bg_color = Color(1, 1, 1, alpha)
    style.corner_radius_top_left = 8
    style.corner_radius_top_right = 8
    style.corner_radius_bottom_left = 8
    style.corner_radius_bottom_right = 8
    return style

func _add_hotspot(label_text: String, left: float, top: float, right: float, bottom: float, callback: Callable, disabled := false) -> Button:
    var b = Button.new()
    b.text = ""
    b.tooltip_text = label_text
    b.disabled = disabled
    b.anchor_left = left
    b.anchor_right = right
    b.anchor_top = top
    b.anchor_bottom = bottom
    b.offset_left = 0
    b.offset_right = 0
    b.offset_top = 0
    b.offset_bottom = 0
    b.focus_mode = Control.FOCUS_ALL
    b.add_theme_stylebox_override("normal", _button_style(0.0))
    b.add_theme_stylebox_override("hover", _button_style(0.065))
    b.add_theme_stylebox_override("pressed", _button_style(0.12))
    b.add_theme_stylebox_override("focus", _button_style(0.08))
    add_child(b)
    if not disabled:
        b.pressed.connect(callback)
    return b

func _build_hitboxes() -> void:
    # As áreas acompanham a arte final em qualquer resolução 16:9.
    var has_save = FileAccess.file_exists(SAVE_PATH)
    var continue_btn = _add_hotspot("Continuar", 0.033, 0.338, 0.296, 0.425, _continue_game, false)
    if not has_save:
        continue_btn.modulate = Color(0.72, 0.72, 0.72, 1.0)
    _add_hotspot("Novo Jogo", 0.033, 0.437, 0.296, 0.520, _new_game)
    _add_hotspot("Loja", 0.033, 0.535, 0.296, 0.615, _open_shop)
    _add_hotspot("Resgatar Recompensa", 0.033, 0.628, 0.296, 0.714, _open_redeem)
    _add_hotspot("Em breve", 0.033, 0.724, 0.296, 0.806, _show_coming_soon)
    _add_hotspot("Configurações", 0.033, 0.820, 0.296, 0.908, _open_settings)

func _build_toast() -> void:
    toast_label = Label.new()
    toast_label.anchor_left = 0.33
    toast_label.anchor_right = 0.78
    toast_label.anchor_top = 0.90
    toast_label.anchor_bottom = 0.965
    toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    toast_label.add_theme_font_size_override("font_size", 15)
    toast_label.visible = false
    toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var panel = StyleBoxFlat.new()
    panel.bg_color = Color(0.01, 0.02, 0.04, 0.86)
    panel.corner_radius_top_left = 10
    panel.corner_radius_top_right = 10
    panel.corner_radius_bottom_left = 10
    panel.corner_radius_bottom_right = 10
    toast_label.add_theme_stylebox_override("normal", panel)
    add_child(toast_label)

func _show_toast(text_value: String) -> void:
    toast_label.text = text_value
    toast_label.visible = true
    var timer = get_tree().create_timer(2.2, true, false, true)
    timer.timeout.connect(func():
        if is_instance_valid(toast_label):
            toast_label.visible = false
    )

func _preload_runtime_silently() -> void:
    var status = ResourceLoader.load_threaded_get_status(RUNTIME_SCENE)
    if status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
        ResourceLoader.load_threaded_request(RUNTIME_SCENE)

func _continue_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        _show_toast("Nenhum save encontrado. Comece em NOVO JOGO.")
        return
    get_tree().root.set_meta("mundo_clt_entry_mode", "continue")
    get_tree().change_scene_to_file(LOADER_SCENE)

func _new_game() -> void:
    get_tree().change_scene_to_file(NEW_GAME_SCENE)

func _clear_modal() -> void:
    for child in modal_layer.get_children():
        child.queue_free()

func _modal(title: String, width := 650.0, height := 420.0) -> VBoxContainer:
    _clear_modal()
    modal_layer.mouse_filter = Control.MOUSE_FILTER_STOP
    var shade = ColorRect.new()
    shade.color = Color(0, 0, 0, 0.68)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    modal_layer.add_child(shade)

    var panel = PanelContainer.new()
    panel.anchor_left = 0.5
    panel.anchor_right = 0.5
    panel.anchor_top = 0.5
    panel.anchor_bottom = 0.5
    panel.offset_left = -width / 2.0
    panel.offset_right = width / 2.0
    panel.offset_top = -height / 2.0
    panel.offset_bottom = height / 2.0
    var style = StyleBoxFlat.new()
    style.bg_color = Color(0.012, 0.025, 0.05, 0.97)
    style.border_width_left = 1
    style.border_width_top = 1
    style.border_width_right = 1
    style.border_width_bottom = 1
    style.border_color = Color(0.2, 0.48, 0.82, 0.7)
    style.corner_radius_top_left = 14
    style.corner_radius_top_right = 14
    style.corner_radius_bottom_left = 14
    style.corner_radius_bottom_right = 14
    panel.add_theme_stylebox_override("panel", style)
    modal_layer.add_child(panel)

    var margin = MarginContainer.new()
    margin.add_theme_constant_override("margin_left", 28)
    margin.add_theme_constant_override("margin_right", 28)
    margin.add_theme_constant_override("margin_top", 24)
    margin.add_theme_constant_override("margin_bottom", 24)
    panel.add_child(margin)

    var box = VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    margin.add_child(box)

    var h = Label.new()
    h.text = title
    h.add_theme_font_size_override("font_size", 30)
    box.add_child(h)
    return box

func _close_modal() -> void:
    _clear_modal()
    modal_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE

func _open_shop() -> void:
    var box = _modal("LOJA CLT", 650, 420)
    var t = Label.new()
    t.text = "Itens, veículos e personalizações chegarão nas próximas versões.\nNesta Alpha não há compras com dinheiro real."
    t.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    t.add_theme_font_size_override("font_size", 17)
    box.add_child(t)
    var close = Button.new()
    close.text = "VOLTAR"
    close.custom_minimum_size = Vector2(0, 52)
    close.pressed.connect(_close_modal)
    box.add_child(close)

func _open_redeem() -> void:
    var box = _modal("RESGATAR RECOMPENSA", 650, 440)
    var info = Label.new()
    info.text = "Digite um código promocional da campanha."
    info.add_theme_font_size_override("font_size", 16)
    box.add_child(info)
    var input = LineEdit.new()
    input.placeholder_text = "EX.: MUNDOCLT2026"
    input.custom_minimum_size = Vector2(0, 52)
    box.add_child(input)
    var status = Label.new()
    status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    status.add_theme_font_size_override("font_size", 14)
    box.add_child(status)
    var redeem = Button.new()
    redeem.text = "RESGATAR"
    redeem.custom_minimum_size = Vector2(0, 52)
    redeem.pressed.connect(func():
        var code = input.text.strip_edges().to_upper()
        if code in ["MUNDOCLT2026", "FERIAS30", "SEXTOU", "GAUCHO01"]:
            status.text = "Código reconhecido. A recompensa será aplicada dentro da campanha."
        else:
            status.text = "Código inválido ou ainda não disponível nesta Alpha."
    )
    box.add_child(redeem)
    var close = Button.new()
    close.text = "VOLTAR"
    close.custom_minimum_size = Vector2(0, 48)
    close.pressed.connect(_close_modal)
    box.add_child(close)

func _open_settings() -> void:
    var box = _modal("CONFIGURAÇÕES", 680, 520)
    var audio = get_node_or_null("/root/AudioManager")
    for channel in ["master", "music", "sfx"]:
        var row = HBoxContainer.new()
        row.add_theme_constant_override("separation", 14)
        var name_label = Label.new()
        name_label.text = {"master":"Volume geral", "music":"Música", "sfx":"Efeitos"}[channel]
        name_label.custom_minimum_size = Vector2(180, 44)
        name_label.add_theme_font_size_override("font_size", 16)
        row.add_child(name_label)
        var slider = HSlider.new()
        slider.min_value = 0
        slider.max_value = 100
        slider.step = 1
        slider.custom_minimum_size = Vector2(360, 44)
        slider.value = audio.get_volume(channel) if audio != null and audio.has_method("get_volume") else 75
        slider.value_changed.connect(func(value):
            if audio != null and audio.has_method("set_volume"):
                audio.set_volume(channel, value)
        )
        row.add_child(slider)
        box.add_child(row)
    var close = Button.new()
    close.text = "SALVAR E VOLTAR"
    close.custom_minimum_size = Vector2(0, 54)
    close.pressed.connect(_close_modal)
    box.add_child(close)

func _show_coming_soon() -> void:
    _show_toast("Novos conteúdos estão em desenvolvimento.")

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        if modal_layer != null and modal_layer.get_child_count() > 0:
            _close_modal()
        else:
            get_tree().quit()
