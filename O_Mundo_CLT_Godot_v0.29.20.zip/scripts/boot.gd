extends Control

const MENU_SCENE := "res://scenes/MainMenu.tscn"
const INTRO_BG := "res://assets/backgrounds/intro_lr_global.png"
const APP_VERSION := "0.29.20"

var stage := 0
var title_label: Label
var subtitle_label: Label
var intro_timer: Timer

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    get_tree().paused = false
    var audio = get_node_or_null("/root/AudioManager")
    if audio != null and audio.has_method("set_context"):
        audio.set_context("menu")
    _build_intro()

func _build_intro() -> void:
    var tex = load(INTRO_BG) as Texture2D

    var fill = TextureRect.new()
    fill.texture = tex
    fill.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    fill.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    fill.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    fill.modulate = Color(0.38, 0.40, 0.46, 1.0)
    fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(fill)

    var image = TextureRect.new()
    image.texture = tex
    image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    image.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    image.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(image)

    var shade = ColorRect.new()
    shade.color = Color(0.005, 0.012, 0.03, 0.52)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(shade)

    var center = CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(center)

    var box = VBoxContainer.new()
    box.alignment = BoxContainer.ALIGNMENT_CENTER
    box.custom_minimum_size = Vector2(760, 230)
    box.add_theme_constant_override("separation", 8)
    center.add_child(box)

    title_label = Label.new()
    title_label.text = "LVSR GAMES"
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title_label.add_theme_font_size_override("font_size", 50)
    box.add_child(title_label)

    subtitle_label = Label.new()
    subtitle_label.text = "apresenta"
    subtitle_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle_label.add_theme_font_size_override("font_size", 20)
    subtitle_label.modulate = Color(1, 1, 1, 0.82)
    box.add_child(subtitle_label)

    var skip = Button.new()
    skip.text = "PULAR"
    skip.anchor_left = 0.865
    skip.anchor_right = 0.975
    skip.anchor_top = 0.035
    skip.anchor_bottom = 0.100
    skip.offset_left = 0
    skip.offset_right = 0
    skip.offset_top = 0
    skip.offset_bottom = 0
    skip.add_theme_font_size_override("font_size", 15)
    add_child(skip)
    skip.pressed.connect(_open_menu)

    var version = Label.new()
    version.text = "ALPHA v%s" % APP_VERSION
    version.anchor_left = 0.02
    version.anchor_right = 0.30
    version.anchor_top = 0.94
    version.anchor_bottom = 0.985
    version.modulate = Color(1, 1, 1, 0.58)
    version.add_theme_font_size_override("font_size", 12)
    add_child(version)

    intro_timer = Timer.new()
    intro_timer.process_mode = Node.PROCESS_MODE_ALWAYS
    intro_timer.one_shot = true
    intro_timer.wait_time = 1.15
    add_child(intro_timer)
    intro_timer.timeout.connect(_advance_intro)
    intro_timer.start()

func _advance_intro() -> void:
    stage += 1
    match stage:
        1:
            title_label.text = "O MUNDO CLT"
            subtitle_label.text = "Sobrevivendo ao Expediente"
        2:
            title_label.text = "UMA CRIAÇÃO DE LUCAS RODRIGUES"
            subtitle_label.text = "LVSR Games"
        _:
            _open_menu()
            return
    intro_timer.start()

func _open_menu() -> void:
    if intro_timer != null:
        intro_timer.stop()
    get_tree().change_scene_to_file(MENU_SCENE)
