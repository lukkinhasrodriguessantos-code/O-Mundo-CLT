extends Node

# Constantes locais de boot. Nenhum manager é preloaded aqui de propósito:
# se um script secundário estiver com problema, a Main ainda carrega e o menu
# continua aparecendo. Os managers são carregados individualmente em runtime.
const SAVE_SCHEMA := 28
const PHASE_WORK := "work"
const PHASE_HOME := "home"
const PHASE_MORNING := "morning"
const STAGE_CLOCK_IN := "clock_in"
const STAGE_MEET_MENTOR := "meet_mentor"
const STAGE_USE_COMPUTER := "use_computer"
const STAGE_RETURN_MENTOR := "return_mentor"
const STAGE_CLOCK_OUT := "clock_out"
const STAGE_COMPLETE := "complete"
const FLEET_CHECKLIST_RETURN := "LVS-001"
const FLEET_CHECKLIST_PREVENTIVE := "VSR-101"
const FLEET_CHECKLIST_EXIT := "LRG-201"
const FLEET_URGENT_BRAKE := "LSR-301"

var audio_manager = null
var improvement_manager = null
var workday_manager = null
var career_manager = null
var tutorial_manager = null
var life_cycle_manager = null
var personal_life_manager = null
var campaign_manager = null
var mobile_ui_manager = null
var settings_manager = null
var alpha_health_manager = null
var alpha_session_manager = null
var alpha_self_test_manager = null

var player_name := "Funcionário"
var area := "Gestão de Frotas"
var mission_finished := false
var specialist_followup := false
var work_clock := "07:45"
var clt_coins := 250
var player_cash := 1250
var monthly_salary := 2650
var benefits_balance := 420
var bills_due := 780
var home_comfort := 10
var owned_furniture := {}
var city_unlocked := false
var weekend_unlocked := false
var energy := 70
var social_affinity := 0
var city_time := "18:10"
var city_day := "SEXTA-FEIRA"
var relationship_stage := "Conhecido(a)"
var alex_affinity := 0
var easter_eggs := {}
var easter_total := 13
var unlocked_skins := {}
var unlocked_vehicles := {}
var active_vehicle := "A pé"
var garage_unlocked := false
var vehicle_fuel := {}
var vehicle_condition := {}
var vehicle_km := {}
var lucas_help_count := 0
var lucas_mastery_rewarded := false
var lucas_innovation_rewarded := false
var internal_requests_resolved := 0
var internal_request_pressure := 0
var internal_requests_history := []
var tower_mission_complete := false
var tower_visits := 0
var lucas_wife_calls_seen := 0
var last_paid_week := 0
var redeemed_codes := {}
var career_role := "Assistente"
var career_xp := 20
var reputation := 50
var current_day := "SEGUNDA-FEIRA"
var save_path := "user://mundo_clt_save.json"
var save_temp_path := "user://mundo_clt_save.tmp"
var save_backup_path := "user://mundo_clt_save.bak.json"
var current_screen := "boot"
var startup_entry_mode := "standalone"
var last_autosave_msec := 0
var pause_open := false
const APP_VERSION := "0.29.20"
const INTRO_BG_PATH := "res://assets/backgrounds/intro_lr_global.png"
const MENU_BG_PATH := "res://assets/backgrounds/menu_lr_global.png"

var boot_intro_stage := 0
var boot_intro_timer: Timer
var startup_guard_timer: Timer
var boot_intro_title: Label
var boot_intro_subtitle: Label

func _ready() -> void:
    Engine.max_fps = 60
    get_tree().paused = false
    startup_entry_mode = str(get_tree().root.get_meta("mundo_clt_entry_mode", "standalone"))
    print("[STARTUP] Main carregada | entrada: ", startup_entry_mode)

    audio_manager = get_node_or_null("/root/AudioManager")
    _start_startup_guard()

    # A abertura e o menu principal agora vivem em cenas leves separadas.
    # Quando a Main é chamada pelo jogo, ela entra direto no fluxo solicitado.
    if startup_entry_mode in ["new_game", "continue"]:
        _show_startup_loading()
    else:
        _show_boot_intro_visual_only()
        if get_parent() != null and get_parent().has_method("mark_game_ready"):
            get_parent().call_deferred("mark_game_ready")

    call_deferred("_initialize_runtime_after_first_frame")

func _initialize_runtime_after_first_frame() -> void:
    print("[STARTUP] Criando sistemas essenciais em runtime")
    _create_game_managers()
    if settings_manager != null and settings_manager.has_method("apply_runtime_settings"):
        settings_manager.apply_runtime_settings()
    call_deferred("_finish_startup_state")


func _start_startup_guard() -> void:
    # Última proteção: a abertura nunca pode prender o jogador.
    # Se a sequência visual não chegar ao menu por qualquer motivo,
    # o menu é aberto automaticamente após 5,5 segundos.
    if startup_guard_timer != null and is_instance_valid(startup_guard_timer):
        startup_guard_timer.queue_free()
    startup_guard_timer = Timer.new()
    startup_guard_timer.process_mode = Node.PROCESS_MODE_ALWAYS
    startup_guard_timer.one_shot = true
    startup_guard_timer.wait_time = 5.5
    add_child(startup_guard_timer)
    startup_guard_timer.timeout.connect(_on_startup_guard_timeout)
    startup_guard_timer.start()

func _on_startup_guard_timeout() -> void:
    if current_screen == "intro" or current_screen == "boot":
        push_warning("[STARTUP] Guard acionado; abrindo menu principal")
        show_menu()

func _spawn_manager(path: String) -> Node:
    var script_resource := load(path) as Script
    if script_resource == null:
        push_error("[STARTUP] Falha ao carregar manager: " + path)
        return null
    var instance := script_resource.new() as Node
    if instance == null:
        push_error("[STARTUP] Falha ao instanciar manager: " + path)
        return null
    add_child(instance)
    return instance

func _create_game_managers() -> void:
    # AudioManager é Autoload para a música começar antes da primeira cena.
    if audio_manager == null:
        audio_manager = get_node_or_null("/root/AudioManager")
    if audio_manager == null:
        var audio_script = load("res://scripts/audio_manager.gd")
        if audio_script != null:
            var fallback_audio = audio_script.new()
            if fallback_audio is Node:
                audio_manager = fallback_audio
                add_child(audio_manager)

    improvement_manager = _spawn_manager("res://scripts/improvement_manager.gd")
    workday_manager = _spawn_manager("res://scripts/workday_manager.gd")
    career_manager = _spawn_manager("res://scripts/career_manager.gd")
    tutorial_manager = _spawn_manager("res://scripts/tutorial_manager.gd")
    life_cycle_manager = _spawn_manager("res://scripts/life_cycle_manager.gd")
    personal_life_manager = _spawn_manager("res://scripts/personal_life_manager.gd")
    campaign_manager = _spawn_manager("res://scripts/campaign_manager.gd")
    mobile_ui_manager = _spawn_manager("res://scripts/mobile_ui_manager.gd")
    settings_manager = _spawn_manager("res://scripts/settings_manager.gd")
    alpha_health_manager = _spawn_manager("res://scripts/alpha_health_manager.gd")
    alpha_session_manager = _spawn_manager("res://scripts/alpha_session_manager.gd")
    alpha_self_test_manager = _spawn_manager("res://scripts/alpha_self_test_manager.gd")
    print("[STARTUP] Managers carregados em runtime")

func _finish_startup_state() -> void:
    print("[STARTUP] Finalizando estado persistente")
    if alpha_session_manager != null and alpha_session_manager.has_method("begin_session"):
        alpha_session_manager.begin_session(APP_VERSION)
    if mobile_ui_manager != null and settings_manager != null and mobile_ui_manager.has_method("set_touch_scale"):
        mobile_ui_manager.set_touch_scale(settings_manager.touch_scale)

    var essential_ready := improvement_manager != null and workday_manager != null and career_manager != null and tutorial_manager != null and life_cycle_manager != null and personal_life_manager != null and campaign_manager != null

    if startup_entry_mode == "new_game":
        if not essential_ready:
            push_error("[STARTUP] Managers essenciais não carregaram no Novo Jogo")
            get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
            return
        reset_save()
        player_name = str(get_tree().root.get_meta("mundo_clt_player_name", "Funcionário"))
        area = str(get_tree().root.get_meta("mundo_clt_area", "Gestão de Frotas"))
        get_tree().root.remove_meta("mundo_clt_entry_mode")
        get_tree().root.remove_meta("mundo_clt_player_name")
        get_tree().root.remove_meta("mundo_clt_area")
        save_game()
        print("[STARTUP] Novo jogo pronto para ", player_name, " / ", area)
        show_gameplay()
        return

    var loaded := false
    if essential_ready:
        loaded = load_game()
        print("[STARTUP] Save carregado: ", loaded)
    else:
        push_warning("[STARTUP] Save adiado: um ou mais managers essenciais não carregaram")

    if startup_entry_mode == "continue":
        get_tree().root.remove_meta("mundo_clt_entry_mode")
        if loaded:
            resume_campaign()
        else:
            get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func force_open_menu() -> void:
    # Fallback do watchdog do boot. Não exibe diagnóstico ao jogador.
    if current_screen == "menu":
        return
    print("[STARTUP] Fallback: abrindo menu principal")
    show_menu()

func save_game() -> bool:
    var data={
        "save_schema":SAVE_SCHEMA,
        "player_name":player_name,"area":area,"clt_coins":clt_coins,"player_cash":player_cash,"monthly_salary":monthly_salary,"benefits_balance":benefits_balance,"bills_due":bills_due,
        "easter_eggs":easter_eggs,"unlocked_skins":unlocked_skins,"unlocked_vehicles":unlocked_vehicles,"active_vehicle":active_vehicle,"garage_unlocked":garage_unlocked,"vehicle_fuel":vehicle_fuel,"vehicle_condition":vehicle_condition,"vehicle_km":vehicle_km,
        "career_role":career_role,"career_xp":career_xp,"reputation":reputation,
        "current_day":current_day,"work_clock":work_clock,"home_comfort":home_comfort,"owned_furniture":owned_furniture,"city_unlocked":city_unlocked,"weekend_unlocked":weekend_unlocked,
        "energy":energy,"social_affinity":social_affinity,"city_time":city_time,"city_day":city_day,"relationship_stage":relationship_stage,"alex_affinity":alex_affinity,"lucas_help_count":lucas_help_count,"lucas_mastery_rewarded":lucas_mastery_rewarded,"lucas_innovation_rewarded":lucas_innovation_rewarded,"internal_requests_resolved":internal_requests_resolved,"internal_request_pressure":internal_request_pressure,"internal_requests_history":internal_requests_history,"tower_mission_complete":tower_mission_complete,"tower_visits":tower_visits,"lucas_wife_calls_seen":lucas_wife_calls_seen,"last_paid_week":last_paid_week,"redeemed_codes":redeemed_codes,"improvement_projects":improvement_manager.export_state(),"workday":workday_manager.export_state(),"career":career_manager.export_state(),"tutorial":tutorial_manager.export_state(),"life_cycle":life_cycle_manager.export_state(),"personal_life":personal_life_manager.export_state(),"campaign":campaign_manager.export_state()
    }
    var payload:=JSON.stringify(data)
    var temp:=FileAccess.open(save_temp_path,FileAccess.WRITE)
    if not temp:
        return false
    temp.store_string(payload)
    temp.flush()
    temp=null

    var save_abs:=ProjectSettings.globalize_path(save_path)
    var temp_abs:=ProjectSettings.globalize_path(save_temp_path)
    var backup_abs:=ProjectSettings.globalize_path(save_backup_path)
    if FileAccess.file_exists(save_path):
        if FileAccess.file_exists(save_backup_path):
            DirAccess.remove_absolute(backup_abs)
        if DirAccess.rename_absolute(save_abs,backup_abs)!=OK:
            return false
    var result:=DirAccess.rename_absolute(temp_abs,save_abs)
    if result!=OK:
        if FileAccess.file_exists(save_backup_path) and not FileAccess.file_exists(save_path):
            DirAccess.rename_absolute(backup_abs,save_abs)
        return false
    return true

func _read_save_dictionary(path:String) -> Dictionary:
    if not FileAccess.file_exists(path):
        return {}
    var f:=FileAccess.open(path,FileAccess.READ)
    if not f:
        return {}
    var parsed=JSON.parse_string(f.get_as_text())
    return parsed if typeof(parsed)==TYPE_DICTIONARY else {}

func load_game() -> bool:
    var recovered_from_backup:=false
    var data:Dictionary=_read_save_dictionary(save_path)
    if data.is_empty():
        data=_read_save_dictionary(save_backup_path)
        recovered_from_backup=not data.is_empty()
    if data.is_empty():
        return false
    player_name=str(data.get("player_name",player_name)); area=str(data.get("area",area))
    clt_coins=int(data.get("clt_coins",clt_coins)); player_cash=int(data.get("player_cash",player_cash)); monthly_salary=int(data.get("monthly_salary",monthly_salary)); benefits_balance=int(data.get("benefits_balance",benefits_balance)); bills_due=int(data.get("bills_due",bills_due)); easter_eggs=data.get("easter_eggs",{})
    unlocked_skins=data.get("unlocked_skins",{}); unlocked_vehicles=data.get("unlocked_vehicles",{}); active_vehicle=str(data.get("active_vehicle",active_vehicle)); garage_unlocked=bool(data.get("garage_unlocked",garage_unlocked)); vehicle_fuel=data.get("vehicle_fuel",{}); vehicle_condition=data.get("vehicle_condition",{}); vehicle_km=data.get("vehicle_km",{}); career_role=str(data.get("career_role",career_role))
    career_xp=int(data.get("career_xp",career_xp)); reputation=int(data.get("reputation",reputation))
    if career_role == "Analista Jr" and monthly_salary < 3200: monthly_salary = 3200
    current_day=str(data.get("current_day",current_day)); work_clock=str(data.get("work_clock",work_clock))
    home_comfort=int(data.get("home_comfort",home_comfort)); owned_furniture=data.get("owned_furniture",{}); city_unlocked=bool(data.get("city_unlocked",city_unlocked)); weekend_unlocked=bool(data.get("weekend_unlocked",weekend_unlocked))
    energy=int(data.get("energy",energy)); social_affinity=int(data.get("social_affinity",social_affinity)); city_time=str(data.get("city_time",city_time)); city_day=str(data.get("city_day",city_day)); relationship_stage=str(data.get("relationship_stage",relationship_stage)); alex_affinity=int(data.get("alex_affinity",alex_affinity)); lucas_help_count=int(data.get("lucas_help_count",lucas_help_count)); lucas_mastery_rewarded=bool(data.get("lucas_mastery_rewarded",lucas_mastery_rewarded)); lucas_innovation_rewarded=bool(data.get("lucas_innovation_rewarded",lucas_innovation_rewarded)); internal_requests_resolved=int(data.get("internal_requests_resolved",internal_requests_resolved)); internal_request_pressure=int(data.get("internal_request_pressure",internal_request_pressure)); internal_requests_history=data.get("internal_requests_history",[]); tower_mission_complete=bool(data.get("tower_mission_complete",tower_mission_complete)); tower_visits=int(data.get("tower_visits",tower_visits)); lucas_wife_calls_seen=int(data.get("lucas_wife_calls_seen",lucas_wife_calls_seen)); last_paid_week=int(data.get("last_paid_week",last_paid_week)); redeemed_codes=data.get("redeemed_codes",{})
    improvement_manager.import_state(data.get("improvement_projects",{}))
    workday_manager.import_state(data.get("workday",{}))
    career_manager.import_state(data.get("career",{}))
    if data.has("tutorial"):
        tutorial_manager.import_state(data.get("tutorial",{}))
    else:
        tutorial_manager.import_state({})
        tutorial_manager.migrate_legacy(career_xp > 20 or career_role != "Assistente" or workday_manager.total_completed_days > 0)
    life_cycle_manager.import_state(data.get("life_cycle",{}))
    personal_life_manager.import_state(data.get("personal_life",{}))
    campaign_manager.import_state(data.get("campaign",{}))
    var repair:Dictionary=campaign_manager.reconcile(workday_manager,life_cycle_manager,tutorial_manager,area)
    if life_cycle_manager.phase in [PHASE_WORK, PHASE_MORNING]:
        current_day=workday_manager.get_day_label()
    if recovered_from_backup:
        if FileAccess.file_exists(save_path):
            DirAccess.remove_absolute(ProjectSettings.globalize_path(save_path))
        save_game()
    elif bool(repair.get("changed",false)):
        save_game()
    return true

func reset_save() -> void:
    for path in [save_path,save_temp_path,save_backup_path]:
        if FileAccess.file_exists(path):
            DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
    workday_manager.import_state({})
    improvement_manager.import_state({})
    career_manager.import_state({})
    tutorial_manager.import_state({})
    life_cycle_manager.import_state({})
    personal_life_manager.import_state({})
    campaign_manager.import_state({})
    player_name="Funcionário"; area="Gestão de Frotas"; clt_coins=250; player_cash=1250; monthly_salary=2650; benefits_balance=420; bills_due=780; easter_eggs={}; unlocked_skins={}; unlocked_vehicles={}; active_vehicle="A pé"; garage_unlocked=false; vehicle_fuel={}; vehicle_condition={}; vehicle_km={}
    career_role="Assistente"; career_xp=20; reputation=50; current_day="SEGUNDA-FEIRA"; work_clock="07:45"; home_comfort=10; owned_furniture={}; city_unlocked=false; weekend_unlocked=false; energy=70; social_affinity=0; city_time="18:10"; city_day="SEXTA-FEIRA"; relationship_stage="Conhecido(a)"; alex_affinity=0; lucas_help_count=0; lucas_mastery_rewarded=false; lucas_innovation_rewarded=false; internal_requests_resolved=0; internal_request_pressure=0; internal_requests_history=[]; tower_mission_complete=false; tower_visits=0; lucas_wife_calls_seen=0; last_paid_week=0; redeemed_codes={}

func clear_scene() -> void:
    for c in get_children():
        if c == audio_manager or c == improvement_manager or c == workday_manager or c == career_manager or c == tutorial_manager or c == life_cycle_manager or c == personal_life_manager or c == campaign_manager or c == mobile_ui_manager or c == settings_manager or c == alpha_health_manager or c == alpha_session_manager or c == alpha_self_test_manager or c == startup_guard_timer:
            continue
        c.queue_free()

func _safe_autosave(_reason:String="") -> void:
    if not FileAccess.file_exists(save_path):
        return
    var now:=Time.get_ticks_msec()
    if now-last_autosave_msec<750:
        return
    last_autosave_msec=now
    save_game()

func _close_mobile_overlay() -> bool:
    var overlays=["AlphaSelfTest","AlphaDiagnostics","SettingsPanel","MenuShop","RedeemCode","CreditsPanel","NewGameConfirm","GamePhone","CampaignPanel","WorkdayPanel","WorkdaySummary","ImprovementProjects","CareerPanel","FinancePanel","RelationshipsPanel","InternalRequests","LucasInteraction","LucasWifeCall","LucasHelpChain","LucasLegendaryEgg","EasterEggPopup"]
    for overlay_name in overlays:
        var overlay=find_child(overlay_name,true,false)
        if overlay!=null and is_instance_valid(overlay):
            overlay.queue_free()
            return true
    return false

func _handle_back_request() -> void:
    var pause_panel=find_child("PauseMenu",true,false)
    if pause_panel!=null and is_instance_valid(pause_panel):
        close_pause_menu(pause_panel)
        return
    if _close_mobile_overlay():
        return
    if current_screen in ["gameplay","home"]:
        var ui_name:="GameUI" if current_screen=="gameplay" else "HomeUI"
        var ui=find_child(ui_name,true,false)
        if ui!=null and is_instance_valid(ui):
            show_pause_menu(ui)
        else:
            _safe_autosave("android_back_fallback")
            show_menu()
        return
    if current_screen in ["character","hiring"]:
        show_menu()
        return
    _quit_game()

func _notification(what:int) -> void:
    if what==NOTIFICATION_APPLICATION_PAUSED:
        _safe_autosave("application_paused")
    elif what==NOTIFICATION_WM_GO_BACK_REQUEST:
        _handle_back_request()
    elif what==NOTIFICATION_WM_CLOSE_REQUEST:
        _quit_game()

func _quit_game() -> void:
    if current_screen in ["gameplay","home"]:
        _safe_autosave("clean_quit")
    if alpha_session_manager != null:
        alpha_session_manager.mark_clean_shutdown()
    get_tree().quit()

func _exit_tree() -> void:
    if alpha_session_manager != null:
        alpha_session_manager.mark_clean_shutdown()

func _show_startup_loading() -> void:
    current_screen="loading"
    var bg=ColorRect.new()
    bg.name="StartupLoading"
    bg.color=Color("070b10")
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)
    var center=CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.add_child(center)
    var box=VBoxContainer.new()
    box.alignment=BoxContainer.ALIGNMENT_CENTER
    box.custom_minimum_size=Vector2(720,190)
    center.add_child(box)
    var title=label("O MUNDO CLT",42)
    title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(title)
    var subtitle=label("Preparando LR Global…",20)
    subtitle.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(subtitle)
    var detail=label("Preparando seu expediente na LR Global",13)
    detail.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    detail.modulate=Color(1,1,1,.65)
    box.add_child(detail)

func add_pause_button(ui:CanvasLayer, top_parent:Control=null, left_offset:float=0.0) -> void:
    var pause_btn=Button.new()
    pause_btn.name="PauseButton"
    pause_btn.text="⏸"
    pause_btn.tooltip_text="Pausar jogo"
    pause_btn.custom_minimum_size=Vector2(66,48)
    pause_btn.size=Vector2(66,48)
    pause_btn.process_mode=Node.PROCESS_MODE_ALWAYS
    if top_parent!=null:
        pause_btn.position=Vector2(max(0.0,top_parent.size.x-238.0-left_offset),12)
        top_parent.add_child(pause_btn)
    else:
        mobile_ui_manager.refresh_safe_area()
        var screen_size:Vector2=mobile_ui_manager.canvas_size()
        pause_btn.position=Vector2(screen_size.x-84.0-mobile_ui_manager.safe_margins.z,18.0+mobile_ui_manager.safe_margins.y)
        ui.add_child(pause_btn)
    pause_btn.pressed.connect(func(): show_pause_menu(ui))

func show_pause_menu(ui:CanvasLayer) -> void:
    var existing=ui.get_node_or_null("PauseMenu")
    if existing:
        close_pause_menu(existing)
        return
    pause_open=true
    _safe_autosave("pause_open")
    get_tree().paused=true
    var overlay=ColorRect.new()
    overlay.name="PauseMenu"
    overlay.color=Color(0,0,0,.82)
    overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.process_mode=Node.PROCESS_MODE_ALWAYS
    overlay.mouse_filter=Control.MOUSE_FILTER_STOP
    ui.add_child(overlay)
    var panel=Panel.new()
    panel.position=Vector2(390,80)
    panel.size=Vector2(500,560)
    panel.process_mode=Node.PROCESS_MODE_ALWAYS
    overlay.add_child(panel)
    var box=VBoxContainer.new()
    box.position=Vector2(28,24)
    box.size=Vector2(444,510)
    panel.add_child(box)
    box.add_child(label("⏸ JOGO PAUSADO",34))
    box.add_child(label("O MUNDO CLT • Alpha v%s" % APP_VERSION,15))
    var status=label("💾 Progresso salvo automaticamente ao pausar.",14)
    status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
    box.add_child(status)
    var resume=button("▶ CONTINUAR")
    resume.custom_minimum_size=Vector2(440,54)
    box.add_child(resume)
    resume.pressed.connect(func(): close_pause_menu(overlay))
    var save_btn=button("💾 SALVAR JOGO")
    save_btn.custom_minimum_size=Vector2(440,50)
    box.add_child(save_btn)
    save_btn.pressed.connect(func(): status.text="✅ Jogo salvo com segurança." if save_game() else "❌ Não foi possível salvar o jogo.")
    var settings_btn=button("⚙️ CONFIGURAÇÕES")
    settings_btn.custom_minimum_size=Vector2(440,50)
    box.add_child(settings_btn)
    settings_btn.pressed.connect(func(): show_settings(ui))
    var diag_btn=button("🧪 DIAGNÓSTICO ALPHA")
    diag_btn.custom_minimum_size=Vector2(440,48)
    box.add_child(diag_btn)
    diag_btn.pressed.connect(func(): show_alpha_diagnostics(ui))
    var menu_btn=button("💾 SALVAR E VOLTAR AO MENU")
    menu_btn.custom_minimum_size=Vector2(440,54)
    box.add_child(menu_btn)
    menu_btn.pressed.connect(func():
        var ok:=save_game()
        status.text="✅ Save concluído. Voltando ao menu..." if ok else "⚠️ Falha no save. Permanecendo no jogo."
        if ok:
            get_tree().paused=false
            pause_open=false
            show_menu()
    )
    var build=label("BUILD ALPHA • Use Diagnóstico Alpha se encontrar algum problema.",12)
    build.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
    box.add_child(build)

func close_pause_menu(panel:Node) -> void:
    if panel!=null and is_instance_valid(panel):
        panel.queue_free()
    pause_open=false
    get_tree().paused=false

func label(text:String, size:int=24) -> Label:
    var l=Label.new(); l.text=text; l.add_theme_font_size_override("font_size",size); return l

func button(text:String) -> Button:
    var b=Button.new(); b.text=text; b.custom_minimum_size=Vector2(310,52); return b

func _cinematic_background(node_name:String, texture_path:String, shade_alpha:float=0.42) -> Control:
    var root=Control.new()
    root.name=node_name
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var tex=load(texture_path) as Texture2D

    # Preenche telas ultrawide com a própria arte, sem cortar o quadro principal.
    var fill=TextureRect.new()
    fill.name="BackgroundFill"
    fill.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    fill.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
    fill.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_COVERED
    fill.mouse_filter=Control.MOUSE_FILTER_IGNORE
    fill.modulate=Color(0.42,0.42,0.48,1.0)
    if tex!=null:
        fill.texture=tex
    root.add_child(fill)

    # Mantém a imagem inteira visível no centro, preservando a fachada e o personagem.
    var image=TextureRect.new()
    image.name="BackgroundImage"
    image.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    image.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
    image.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    image.mouse_filter=Control.MOUSE_FILTER_IGNORE
    image.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
    if tex!=null:
        image.texture=tex
    root.add_child(image)

    var shade=ColorRect.new()
    shade.name="CinematicShade"
    shade.color=Color(0.015,0.025,0.045,shade_alpha)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter=Control.MOUSE_FILTER_IGNORE
    root.add_child(shade)
    return root

func _alpha_health_report() -> Dictionary:
    if alpha_health_manager == null:
        return {"ok": false, "status": "SISTEMAS CARREGANDO"}
    var managers := {
        "audio": audio_manager,
        "improvements": improvement_manager,
        "workday": workday_manager,
        "career": career_manager,
        "tutorial": tutorial_manager,
        "life_cycle": life_cycle_manager,
        "personal_life": personal_life_manager,
        "campaign": campaign_manager,
        "mobile_ui": mobile_ui_manager,
        "settings": settings_manager,
        "session": alpha_session_manager,
        "self_test": alpha_self_test_manager
    }
    var campaign_state := {
        "week": workday_manager.current_week if workday_manager != null else 0,
        "day": workday_manager.current_day if workday_manager != null else 0,
        "energy": energy,
        "role": career_role
    }
    return alpha_health_manager.evaluate(managers, settings_manager, save_path, save_backup_path, campaign_state)

func _show_boot_intro_visual_only() -> void:
    get_tree().paused = false
    current_screen="intro"
    if audio_manager != null and audio_manager.has_method("set_context"):
        audio_manager.set_context("menu")
    clear_scene()
    boot_intro_stage=0

    var bg=_cinematic_background("BootIntro",INTRO_BG_PATH,0.55)
    add_child(bg)

    var center=CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.add_child(center)
    var box=VBoxContainer.new()
    box.alignment=BoxContainer.ALIGNMENT_CENTER
    box.custom_minimum_size=Vector2(760,240)
    center.add_child(box)

    boot_intro_title=label("LVSR GAMES",50)
    boot_intro_title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(boot_intro_title)
    boot_intro_subtitle=label("apresenta",20)
    boot_intro_subtitle.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(boot_intro_subtitle)

    var footer=label("ALPHA v%s • DESENVOLVIMENTO EM ANDAMENTO" % APP_VERSION,13)
    footer.position=Vector2(24,680)
    footer.modulate=Color(1,1,1,.62)
    bg.add_child(footer)

    var skip=Button.new()
    skip.text="PULAR"
    skip.custom_minimum_size=Vector2(145,44)
    skip.position=Vector2(1110,24)
    bg.add_child(skip)
    skip.pressed.connect(show_menu)

    boot_intro_timer=Timer.new()
    boot_intro_timer.process_mode=Node.PROCESS_MODE_ALWAYS
    boot_intro_timer.one_shot=true
    boot_intro_timer.wait_time=1.35
    bg.add_child(boot_intro_timer)
    boot_intro_timer.timeout.connect(_advance_boot_intro)
    boot_intro_timer.start()

func show_boot_intro() -> void:
    _show_boot_intro_visual_only()

func _advance_boot_intro() -> void:
    if boot_intro_title==null or not is_instance_valid(boot_intro_title):
        return
    boot_intro_stage+=1
    match boot_intro_stage:
        1:
            boot_intro_title.text="O MUNDO CLT"
            boot_intro_subtitle.text="Sobrevivendo ao Expediente"
        2:
            boot_intro_title.text="UMA CRIAÇÃO DE LUCAS RODRIGUES"
            boot_intro_subtitle.text="LVSR Games • LR Global Logística"
        _:
            show_menu()
            return
    if boot_intro_timer!=null and is_instance_valid(boot_intro_timer):
        boot_intro_timer.start()

func show_menu() -> void:
    print("[MENU_READY] Menu principal aberto")
    if startup_guard_timer != null and is_instance_valid(startup_guard_timer):
        startup_guard_timer.stop()
        startup_guard_timer.queue_free()
        startup_guard_timer = null
    get_tree().paused=false
    pause_open=false
    current_screen="menu"
    if audio_manager != null and audio_manager.has_method("set_context"):
        audio_manager.set_context("menu")
    if settings_manager != null and settings_manager.has_method("apply_runtime_settings"):
        settings_manager.apply_runtime_settings()
    else:
        push_warning("[STARTUP] Menu aberto sem SettingsManager; usando padrões do projeto")
    clear_scene()
    var bg=_cinematic_background("MainMenu",MENU_BG_PATH,0.30)
    add_child(bg)

    var menu_panel=ColorRect.new()
    menu_panel.name="MenuPanel"
    menu_panel.color=Color(0.015,0.03,0.055,0.80)
    menu_panel.position=Vector2(42,24)
    menu_panel.size=Vector2(500,672)
    bg.add_child(menu_panel)

    var box=VBoxContainer.new()
    box.position=Vector2(28,20)
    box.custom_minimum_size=Vector2(430,0)
    menu_panel.add_child(box)
    box.add_child(label("LVSR GAMES",18)); box.add_child(label("O MUNDO CLT",46)); box.add_child(label("Sobrevivendo ao Expediente",20))
    box.add_child(label("Uma criação de Lucas Rodrigues",14))
    var gap=Control.new(); gap.custom_minimum_size.y=18; box.add_child(gap)
    var cont=button("CONTINUAR"); cont.disabled=not FileAccess.file_exists(save_path); box.add_child(cont)
    cont.pressed.connect(func(): load_game(); resume_campaign())
    var n=button("NOVO JOGO"); box.add_child(n)
    n.pressed.connect(func():
        if FileAccess.file_exists(save_path): show_new_game_confirm(bg)
        else: reset_save(); show_character()
    )
    var shop=button("LOJA"); box.add_child(shop); shop.pressed.connect(func(): show_menu_shop(bg))
    var redeem=button("RESGATAR CÓDIGO"); box.add_child(redeem); redeem.pressed.connect(func(): show_redeem_code(bg))
    var settings=button("CONFIGURAÇÕES"); box.add_child(settings); settings.pressed.connect(func(): show_settings(bg))
    var credits=button("CRÉDITOS"); box.add_child(credits); credits.pressed.connect(func(): show_credits(bg))
    var quit=button("SAIR"); box.add_child(quit); quit.pressed.connect(_quit_game)
    if FileAccess.file_exists(save_path) and campaign_manager != null and workday_manager != null and life_cycle_manager != null:
        box.add_child(label("💾 " + campaign_manager.resume_label(workday_manager,life_cycle_manager,career_role),14))
    var health:Dictionary=_alpha_health_report()
    var health_icon:="✅" if bool(health.get("ok",false)) else "⚠️"
    box.add_child(label("%s Pré-Alpha: %s" % [health_icon,str(health.get("status","ATENÇÃO"))],13))
    if alpha_session_manager != null and bool(alpha_session_manager.get("previous_unclean_exit")):
        var recovery=label("⚠️ A sessão anterior foi interrompida. Save e backup foram verificados na inicialização.",12)
        recovery.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
        recovery.custom_minimum_size=Vector2(520,0)
        box.add_child(recovery)
    box.add_child(label("LR Global Logística • Alpha v%s" % APP_VERSION,14))
    box.add_child(label("🧪 Build de testes • compras com dinheiro real desativadas",12))

func show_new_game_confirm(parent: Control) -> void:
    var old=parent.get_node_or_null("NewGameConfirm")
    if old: old.queue_free(); return
    var panel=ColorRect.new(); panel.name="NewGameConfirm"; panel.color=Color(0,0,0,.94); panel.position=Vector2(470,165); panel.size=Vector2(690,350); parent.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(34,28); box.size=Vector2(620,290); panel.add_child(box)
    box.add_child(label("NOVO JOGO",34))
    var warn=label("Já existe uma campanha salva. Iniciar um novo jogo apagará o progresso atual da campanha. Suas configurações de áudio, gráfico e controles serão mantidas.",17); warn.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(warn)
    var confirm=button("APAGAR CAMPANHA E COMEÇAR"); confirm.custom_minimum_size=Vector2(610,52); box.add_child(confirm)
    confirm.pressed.connect(func(): reset_save(); show_character())
    var cancel=button("CANCELAR"); cancel.custom_minimum_size=Vector2(610,48); box.add_child(cancel); cancel.pressed.connect(panel.queue_free)

func _shop_catalog() -> Array:
    return [["Polo LR Azul-Marinho",80],["Tênis Casual",60],["Look Sexta Casual",95],["Decoração Kitnet • Planta",45]]

func _buy_shop_item(item_name:String, cost:int, status:Label, hud_money:Label=null) -> void:
    if not FileAccess.file_exists(save_path):
        status.text="⚠️ Inicie uma campanha antes de comprar itens."; return
    if unlocked_skins.has(item_name):
        status.text="✅ Você já possui %s." % item_name; return
    if clt_coins < cost:
        status.text="⚠️ CLT Coins insuficientes."; return
    clt_coins-=cost; unlocked_skins[item_name]=true; save_game()
    status.text="✅ %s adquirido! • Saldo: 🪙 %d" % [item_name,clt_coins]
    if hud_money != null and is_instance_valid(hud_money):
        hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]

func show_menu_shop(parent: Control) -> void:
    var old=parent.get_node_or_null("MenuShop")
    if old: old.queue_free(); return
    var panel=ColorRect.new(); panel.name="MenuShop"; panel.color=Color(0,0,0,.94); panel.position=Vector2(450,60); panel.size=Vector2(760,600); parent.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(32,24); box.size=Vector2(695,550); panel.add_child(box)
    box.add_child(label("🛍️ LOJA CLT",34)); box.add_child(label("Cosméticos e personalização • sem vantagem de carreira",15))
    var status=label("Saldo da campanha: 🪙 %d CLT Coins" % clt_coins if FileAccess.file_exists(save_path) else "Crie uma campanha para usar seu saldo e comprar itens.",17); status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(status)
    for item in _shop_catalog():
        var item_name:=str(item[0]); var cost:=int(item[1])
        var b=Button.new(); b.text="%s  •  🪙 %d" % [item_name,cost]; b.custom_minimum_size=Vector2(690,48); b.disabled=unlocked_skins.has(item_name); box.add_child(b)
        b.pressed.connect(func(): _buy_shop_item(item_name,cost,status); b.disabled=unlocked_skins.has(item_name))
    box.add_child(label("Compras com dinheiro real NÃO estão ativas neste Alpha. CLT Coins são apenas da campanha/testes.",13))
    var close=button("VOLTAR"); close.custom_minimum_size=Vector2(690,46); box.add_child(close); close.pressed.connect(panel.queue_free)

func reward_code_catalog() -> Dictionary:
    return {
        "MUNDOCLT2026":{"coins":250,"skin":"","label":"Bônus O Mundo CLT"},
        "FERIAS30":{"coins":150,"skin":"","label":"Bônus Férias"},
        "SEXTOU":{"coins":100,"skin":"Camiseta Sextou","label":"Pacote Sextou"},
        "GAUCHO01":{"coins":75,"skin":"Kit Chima & 5K","label":"Pacote Chima & 5K"}
    }

func show_redeem_code(parent: Control) -> void:
    var old=parent.get_node_or_null("RedeemCode")
    if old: old.queue_free(); return
    var panel=ColorRect.new(); panel.name="RedeemCode"; panel.color=Color(0,0,0,.94); panel.position=Vector2(455,120); panel.size=Vector2(750,455); parent.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(34,28); box.size=Vector2(680,400); panel.add_child(box)
    box.add_child(label("🎁 RESGATAR CÓDIGO",34))
    box.add_child(label("Digite um código promocional. Cada código pode ser usado uma vez por campanha.",16))
    var input=LineEdit.new(); input.placeholder_text="EX.: MUNDOCLT2026"; input.custom_minimum_size=Vector2(675,52); box.add_child(input)
    var status=label("No Alpha, a validação é local. A versão comercial usará validação online.",14); status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(status)
    var redeem=button("RESGATAR"); redeem.custom_minimum_size=Vector2(675,50); box.add_child(redeem)
    redeem.pressed.connect(func():
        if not FileAccess.file_exists(save_path): status.text="⚠️ Inicie uma campanha antes de resgatar recompensas."; return
        var code:String=input.text.strip_edges().to_upper()
        var catalog:=reward_code_catalog()
        if code=="" or not catalog.has(code): status.text="❌ Código inválido ou indisponível."; return
        if redeemed_codes.has(code): status.text="⚠️ Este código já foi usado nesta campanha."; return
        var reward:Dictionary=catalog[code]
        var coins:=int(reward.get("coins",0)); var skin:=str(reward.get("skin",""))
        clt_coins+=coins
        if skin!="": unlocked_skins[skin]=true
        redeemed_codes[code]=true; save_game(); settings_manager.vibrate(35)
        status.text="✅ %s resgatado! +🪙 %d%s" % [str(reward.get("label",code)),coins,(" • 👕 "+skin if skin!="" else "")]
        redeem.disabled=true
    )
    var close=button("VOLTAR"); close.custom_minimum_size=Vector2(675,46); box.add_child(close); close.pressed.connect(panel.queue_free)

func show_settings(parent: Node) -> void:
    var old=parent.get_node_or_null("SettingsPanel")
    if old: old.queue_free(); return
    var panel=ColorRect.new(); panel.name="SettingsPanel"; panel.color=Color(0,0,0,.95); panel.position=Vector2(410,35); panel.size=Vector2(820,650); panel.process_mode=Node.PROCESS_MODE_ALWAYS; parent.add_child(panel)
    var scroll=ScrollContainer.new(); scroll.position=Vector2(26,20); scroll.size=Vector2(770,605); panel.add_child(scroll)
    var box=VBoxContainer.new(); box.custom_minimum_size=Vector2(730,0); scroll.add_child(box)
    box.add_child(label("⚙️ CONFIGURAÇÕES",34))
    box.add_child(label("ÁUDIO",19))
    for item in [["Volume Geral","master"],["Música","music"],["Efeitos","sfx"],["Vozes","voice"],["Ambiente","ambient"]]:
        var row=HBoxContainer.new(); box.add_child(row); var title=label(item[0],16); title.custom_minimum_size=Vector2(190,42); row.add_child(title)
        var slider=HSlider.new(); slider.min_value=0; slider.max_value=100; slider.step=5; slider.value=audio_manager.get_volume(item[1]); slider.custom_minimum_size=Vector2(470,42); row.add_child(slider)
        slider.value_changed.connect(func(v): audio_manager.set_volume(item[1],v))
    box.add_child(label("GRÁFICOS",19))
    var graphics_row=HBoxContainer.new(); box.add_child(graphics_row); var graphics_title=label("Qualidade",16); graphics_title.custom_minimum_size=Vector2(190,44); graphics_row.add_child(graphics_title)
    var graphics=OptionButton.new()
    for q in ["Baixo","Médio","Alto"]:
        graphics.add_item(q)
    graphics.select(maxi(0,["Baixo","Médio","Alto"].find(settings_manager.graphics_preset)))
    graphics.custom_minimum_size=Vector2(250,44); graphics_row.add_child(graphics)
    graphics.item_selected.connect(func(i): settings_manager.set_graphics_preset(graphics.get_item_text(i)))
    var fps_row=HBoxContainer.new(); box.add_child(fps_row); var fps_title=label("Limite de FPS",16); fps_title.custom_minimum_size=Vector2(190,44); fps_row.add_child(fps_title)
    var fps=OptionButton.new(); fps.add_item("30 FPS"); fps.add_item("60 FPS"); fps.select(0 if settings_manager.fps_cap==30 else 1); fps.custom_minimum_size=Vector2(250,44); fps_row.add_child(fps)
    fps.item_selected.connect(func(i): settings_manager.set_fps_cap(30 if i==0 else 60))
    var shadows=CheckButton.new(); shadows.text="Sombras"; shadows.button_pressed=settings_manager.shadows_enabled; shadows.custom_minimum_size=Vector2(690,44); box.add_child(shadows); shadows.toggled.connect(func(v): settings_manager.set_shadows(v))
    box.add_child(label("CONTROLES",19))
    var sens_row=HBoxContainer.new(); box.add_child(sens_row); var sens_title=label("Sensibilidade da câmera",16); sens_title.custom_minimum_size=Vector2(260,44); sens_row.add_child(sens_title)
    var sens=HSlider.new(); sens.min_value=.8; sens.max_value=4.0; sens.step=.1; sens.value=settings_manager.camera_sensitivity; sens.custom_minimum_size=Vector2(390,44); sens_row.add_child(sens); sens.value_changed.connect(func(v): settings_manager.set_camera_sensitivity(v))
    var touch_row=HBoxContainer.new(); box.add_child(touch_row); var touch_title=label("Tamanho dos controles",16); touch_title.custom_minimum_size=Vector2(260,44); touch_row.add_child(touch_title)
    var touch=HSlider.new(); touch.min_value=.85; touch.max_value=1.30; touch.step=.05; touch.value=settings_manager.touch_scale; touch.custom_minimum_size=Vector2(390,44); touch_row.add_child(touch); touch.value_changed.connect(func(v): settings_manager.set_touch_scale(v); mobile_ui_manager.set_touch_scale(v))
    var vibration=CheckButton.new(); vibration.text="Vibração"; vibration.button_pressed=settings_manager.vibration_enabled; vibration.custom_minimum_size=Vector2(690,44); box.add_child(vibration); vibration.toggled.connect(func(v): settings_manager.set_vibration(v))
    var invert=CheckButton.new(); invert.text="Inverter câmera vertical"; invert.button_pressed=settings_manager.invert_camera; invert.custom_minimum_size=Vector2(690,44); box.add_child(invert); invert.toggled.connect(func(v): settings_manager.set_invert_camera(v))
    box.add_child(label("Algumas mudanças de gráfico/controles serão aplicadas totalmente ao entrar novamente no gameplay.",13))
    var diagnostic=button("🧪 DIAGNÓSTICO ALPHA"); diagnostic.custom_minimum_size=Vector2(700,46); box.add_child(diagnostic)
    diagnostic.pressed.connect(func(): show_alpha_diagnostics(parent))
    var reset=button("REDEFINIR CONFIGURAÇÕES"); reset.custom_minimum_size=Vector2(700,46); box.add_child(reset)
    reset.pressed.connect(func(): settings_manager.reset_defaults(); audio_manager.reset_defaults(); mobile_ui_manager.set_touch_scale(settings_manager.touch_scale); panel.queue_free(); show_settings(parent))
    var close=button("VOLTAR"); close.custom_minimum_size=Vector2(700,46); box.add_child(close); close.pressed.connect(panel.queue_free)

func show_alpha_diagnostics(parent:Node) -> void:
    var old=parent.get_node_or_null("AlphaDiagnostics")
    if old:
        old.queue_free()
        return
    var panel=ColorRect.new(); panel.name="AlphaDiagnostics"; panel.color=Color(0,0,0,.96); panel.position=Vector2(405,65); panel.size=Vector2(820,590); panel.process_mode=Node.PROCESS_MODE_ALWAYS; parent.add_child(panel)
    var scroll=ScrollContainer.new(); scroll.position=Vector2(24,20); scroll.size=Vector2(772,545); panel.add_child(scroll)
    var box=VBoxContainer.new(); box.custom_minimum_size=Vector2(735,0); scroll.add_child(box)
    box.add_child(label("🧪 DIAGNÓSTICO ALPHA",31))
    var viewport_size:=get_viewport().get_visible_rect().size
    var save_state:="OK" if FileAccess.file_exists(save_path) else "SEM CAMPANHA"
    var backup_state:="DISPONÍVEL" if FileAccess.file_exists(save_backup_path) else "AINDA NÃO CRIADO"
    var session_state:String="N/D" if alpha_session_manager==null else str(alpha_session_manager.session_summary())
    var launches:int=0 if alpha_session_manager==null else int(alpha_session_manager.launch_count)
    var live_fps:=int(Engine.get_frames_per_second())
    var info="Versão: v%s\nPlataforma: %s\nTela: %d × %d\nQualidade: %s • limite %d FPS • atual ~%d FPS\nTouch: %.2fx • Vibração: %s\nSave: %s • Backup: %s\nTela atual: %s\nSessão: %s • Inicializações: %d" % [APP_VERSION,OS.get_name(),int(viewport_size.x),int(viewport_size.y),settings_manager.graphics_preset,settings_manager.fps_cap,live_fps,settings_manager.touch_scale,("ON" if settings_manager.vibration_enabled else "OFF"),save_state,backup_state,current_screen,session_state,launches]
    var details=label(info,16); details.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(details)
    var health:Dictionary=_alpha_health_report()
    var status_text:="✅ PRÉ-ALPHA: OK" if bool(health.get("ok",false)) else "⚠️ PRÉ-ALPHA: ATENÇÃO"
    box.add_child(label(status_text,19))
    for check in health.get("checks",[]):
        var icon:="✅" if bool(check.get("ok",false)) else ("⚠️" if not bool(check.get("required",true)) else "❌")
        var row=label("%s %s — %s" % [icon,str(check.get("name","Checagem")),str(check.get("detail",""))],14); row.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(row)
    box.add_child(label("Use esta tela quando encontrar algum bug no Alpha. Ela registra configuração, resolução e integridade básica da campanha.",13))
    var rerun=button("🔄 RODAR CHECAGEM NOVAMENTE"); rerun.custom_minimum_size=Vector2(725,46); box.add_child(rerun)
    rerun.pressed.connect(func(): panel.queue_free(); show_alpha_diagnostics(parent))
    var self_test=button("▶ RODAR AUTOTESTE DO JOGO"); self_test.custom_minimum_size=Vector2(725,46); box.add_child(self_test)
    self_test.pressed.connect(func(): show_alpha_self_test(parent))
    var save_test=button("💾 TESTAR SAVE SEGURO"); save_test.custom_minimum_size=Vector2(725,46); box.add_child(save_test)
    save_test.disabled=not FileAccess.file_exists(save_path)
    save_test.pressed.connect(func(): save_test.text="✅ SAVE E BACKUP OK" if save_game() else "❌ FALHA AO GRAVAR SAVE")
    var close=button("VOLTAR"); close.custom_minimum_size=Vector2(725,46); box.add_child(close); close.pressed.connect(panel.queue_free)

func show_alpha_self_test(parent:Node) -> void:
    var old=parent.get_node_or_null("AlphaSelfTest")
    if old:
        old.queue_free()
        return
    var panel=ColorRect.new(); panel.name="AlphaSelfTest"; panel.color=Color(0,0,0,.97); panel.position=Vector2(405,65); panel.size=Vector2(820,590); panel.process_mode=Node.PROCESS_MODE_ALWAYS; parent.add_child(panel)
    var scroll=ScrollContainer.new(); scroll.position=Vector2(24,20); scroll.size=Vector2(772,545); panel.add_child(scroll)
    var box=VBoxContainer.new(); box.custom_minimum_size=Vector2(735,0); scroll.add_child(box)
    box.add_child(label("▶ AUTOTESTE DO JOGO",31))
    box.add_child(label("Testa sistemas isolados em memória. Seu save real não é alterado.",14))
    var result:Dictionary = alpha_self_test_manager.run_all()
    var headline := "✅ %d/%d TESTES PASSARAM" % [int(result.get("passed",0)),int(result.get("total",0))] if bool(result.get("ok",false)) else "❌ %d/%d TESTES PASSARAM" % [int(result.get("passed",0)),int(result.get("total",0))]
    box.add_child(label(headline,20))
    for test in result.get("tests",[]):
        var icon := "✅" if bool(test.get("ok",false)) else "❌"
        var row=label("%s %s — %s" % [icon,str(test.get("name","Teste")),str(test.get("detail",""))],14)
        row.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
        box.add_child(row)
    box.add_child(label("Relatório técnico salvo em user://alpha_self_test_report.json",12))
    var rerun=button("🔄 RODAR NOVAMENTE"); rerun.custom_minimum_size=Vector2(725,46); box.add_child(rerun)
    rerun.pressed.connect(func(): panel.queue_free(); show_alpha_self_test(parent))
    var close=button("VOLTAR"); close.custom_minimum_size=Vector2(725,46); box.add_child(close); close.pressed.connect(panel.queue_free)

func show_credits(parent: Control) -> void:
    var old=parent.get_node_or_null("CreditsPanel")
    if old: old.queue_free(); return
    var panel=ColorRect.new(); panel.name="CreditsPanel"; panel.color=Color(0,0,0,.94); panel.position=Vector2(455,105); panel.size=Vector2(750,500); parent.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(34,28); box.size=Vector2(680,440); panel.add_child(box)
    box.add_child(label("CRÉDITOS",36))
    box.add_child(label("O MUNDO CLT\nSobrevivendo ao Expediente",25))
    box.add_child(label("Criado por Lucas Rodrigues",20))
    box.add_child(label("Conceito e Direção Criativa — Lucas Rodrigues",17))
    box.add_child(label("Desenvolvimento — LVSR Games",17))
    box.add_child(label("Empresa e personagens são fictícios. LR Global Logística.",14))
    box.add_child(label("Versão Alpha v%s • Desenvolvimento em andamento" % APP_VERSION,14))
    var close=button("VOLTAR"); close.custom_minimum_size=Vector2(675,48); box.add_child(close); close.pressed.connect(panel.queue_free)

func show_character() -> void:
    current_screen="character"
    clear_scene()
    var bg=ColorRect.new(); bg.color=Color("151c24"); bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(bg)
    var box=VBoxContainer.new(); box.position=Vector2(100,65); bg.add_child(box)
    box.add_child(label("NOVO JOGO",42)); box.add_child(label("Crie seu personagem",20))
    var name=LineEdit.new(); name.placeholder_text="Nome do personagem"; name.custom_minimum_size=Vector2(430,50); box.add_child(name)
    var sex=OptionButton.new(); sex.add_item("Masculino"); sex.add_item("Feminino"); sex.custom_minimum_size=Vector2(430,50); box.add_child(sex)
    var clothes=OptionButton.new(); for x in ["Camiseta + Jeans","Polo + Calça","Camisa Social","Casual"]: clothes.add_item(x); clothes.custom_minimum_size=Vector2(430,50); box.add_child(clothes)
    var areas=OptionButton.new(); for x in ["Atendimento","Programação","Gestão de Frotas","Operação de Contêineres Vazios"]: areas.add_item(x); areas.select(2); areas.custom_minimum_size=Vector2(430,50); box.add_child(areas)
    box.add_child(label("Cargo inicial: ASSISTENTE",18)); box.add_child(label("Unidade: LR Global — Transportes",18))
    var start=button("FINALIZAR E IR PARA CONTRATAÇÃO"); box.add_child(start)
    start.pressed.connect(func(): player_name=name.text.strip_edges() if name.text.strip_edges()!="" else "Funcionário"; area=areas.get_item_text(areas.selected); save_game(); show_hiring())

func show_hiring() -> void:
    current_screen="hiring"
    clear_scene()
    var world=Node3D.new(); add_child(world)
    var env=WorldEnvironment.new(); var e=Environment.new(); e.background_mode=Environment.BG_COLOR; e.background_color=Color("18232d"); env.environment=e; world.add_child(env)
    var light=DirectionalLight3D.new(); light.rotation_degrees=Vector3(-55,-25,0); light.shadow_enabled=true; world.add_child(light)
    var floor=MeshInstance3D.new(); var pm=PlaneMesh.new(); pm.size=Vector2(24,18); floor.mesh=pm; world.add_child(floor)
    var player=MeshInstance3D.new(); var cap=CapsuleMesh.new(); cap.height=1.8; cap.radius=.42; player.mesh=cap; player.position=Vector3(-2,.9,0); world.add_child(player)
    var director=MeshInstance3D.new(); director.mesh=cap.duplicate(); director.position=Vector3(2,.9,0); world.add_child(director)
    var cam=Camera3D.new(); cam.position=Vector3(0,3.2,7); cam.look_at_from_position(cam.position,Vector3(0,1,0)); world.add_child(cam)
    add_box(world,Vector3(0,1.1,8.0),Vector3(3.0,2.2,.25),Color("394854"))
    var exit_tag=Label3D.new(); exit_tag.text="SAÍDA / CASA"; exit_tag.position=Vector3(0,2.6,7.8); exit_tag.font_size=34; world.add_child(exit_tag)

    var ui=CanvasLayer.new(); add_child(ui); var panel=ColorRect.new(); panel.color=Color(0,0,0,.72); panel.position=Vector2(60,480); panel.size=Vector2(1160,180); ui.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(25,20); panel.add_child(box); box.add_child(label("DIRETOR LUCAS",18)); box.add_child(label("Bom dia, %s. Seja bem-vindo à LR Global." % player_name,25)); box.add_child(label("Você está sendo contratado como Assistente de %s." % area,18)); var next=button("RECEBER CRACHÁ E COMEÇAR"); box.add_child(next); next.pressed.connect(show_gameplay)


func add_box(parent: Node, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
    var m=MeshInstance3D.new()
    var b=BoxMesh.new(); b.size=size
    var mat=StandardMaterial3D.new(); mat.albedo_color=color
    b.material=mat; m.mesh=b; m.position=pos; parent.add_child(m)
    return m

func add_npc(parent: Node, npc_name: String, pos: Vector3, color: Color) -> Node3D:
    var n=Node3D.new(); n.name=npc_name; n.position=pos; parent.add_child(n)
    var body=MeshInstance3D.new(); var cap=CapsuleMesh.new(); cap.height=1.7; cap.radius=.38
    var mat=StandardMaterial3D.new(); mat.albedo_color=color; cap.material=mat; body.mesh=cap; body.position.y=.85; n.add_child(body)
    var tag=Label3D.new(); tag.text=npc_name; tag.position=Vector3(0,2.05,0); tag.font_size=34; n.add_child(tag)
    return n

func add_lucas_npc(parent: Node, pos: Vector3) -> Node3D:
    var n=Node3D.new(); n.name="LucasDasPlanilhas"; n.position=pos; n.set_script(load("res://scripts/office_npc.gd")); parent.add_child(n)
    # Corpo estilizado provisório — preparado para receber o modelo 3D final depois.
    var torso=MeshInstance3D.new(); var body=CapsuleMesh.new(); body.height=1.45; body.radius=.38
    var polo=StandardMaterial3D.new(); polo.albedo_color=Color("203b63"); body.material=polo; torso.mesh=body; torso.position.y=.78; n.add_child(torso)
    var head=MeshInstance3D.new(); var sphere=SphereMesh.new(); sphere.radius=.34; sphere.height=.68
    var skin=StandardMaterial3D.new(); skin.albedo_color=Color("b98265"); sphere.material=skin; head.mesh=sphere; head.position=Vector3(0,1.75,0); n.add_child(head)
    # Óculos: duas lentes + ponte.
    for x in [-.16,.16]:
        var lens=MeshInstance3D.new(); var lb=BoxMesh.new(); lb.size=Vector3(.27,.16,.025); var lm=StandardMaterial3D.new(); lm.albedo_color=Color("c7c9c8"); lb.material=lm; lens.mesh=lb; lens.position=Vector3(x,1.79,-.315); n.add_child(lens)
    add_box(n,Vector3(0,1.79,-.33),Vector3(.09,.025,.025),Color("c7c9c8"))
    # Estação de trabalho do NPC.
    add_box(n,Vector3(0,.42,-1.05),Vector3(2.25,.82,.85),Color("5a4635"))
    add_box(n,Vector3(-.48,1.18,-1.05),Vector3(.75,.48,.06),Color("17222d"))
    add_box(n,Vector3(.48,1.18,-1.05),Vector3(.75,.48,.06),Color("17222d"))
    var tag=Label3D.new(); tag.text="LUCAS DAS PLANILHAS\n💻 trabalhando"; tag.position=Vector3(0,2.45,0); tag.font_size=30; n.add_child(tag)
    var call=Label3D.new(); call.name="PhoneStatus"; call.text="📱"; call.position=Vector3(.65,1.55,-.2); call.font_size=34; n.add_child(call)
    return n

func make_joystick(ui: CanvasLayer, center: Vector2, label_text: String) -> Dictionary:
    var scale:float=float(mobile_ui_manager.get_touch_scale())
    var base_size:Vector2=Vector2(168,168) * scale
    var local_center:Vector2=base_size * 0.5
    var knob_size:Vector2=Vector2(64,64) * scale
    var base=Panel.new(); base.position=center-local_center; base.size=base_size; base.modulate=Color(1,1,1,.72); ui.add_child(base)
    var title=label(label_text,13); title.position=Vector2(30,7); base.add_child(title)
    var knob=Button.new(); knob.text="●"; knob.position=local_center-knob_size*0.5; knob.size=knob_size; knob.mouse_filter=Control.MOUSE_FILTER_IGNORE; base.add_child(knob)
    var touch=Control.new(); touch.position=Vector2.ZERO; touch.size=base.size; touch.mouse_filter=Control.MOUSE_FILTER_STOP; base.add_child(touch)
    return {"base":base,"knob":knob,"touch":touch,"value":Vector2.ZERO,"center":local_center,"knob_half":knob_size*0.5,"radius":58.0*scale,"drag":false}

func bind_joystick(j: Dictionary, callback: Callable) -> void:
    var touch:Control=j.touch
    touch.gui_input.connect(func(ev):
        if ev is InputEventScreenTouch:
            j.drag=ev.pressed
            if not ev.pressed:
                j.value=Vector2.ZERO; j.knob.position=j.center-j.knob_half; callback.call(Vector2.ZERO)
        elif ev is InputEventScreenDrag or (ev is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)):
            j.drag=true
        if j.drag and (ev is InputEventScreenTouch or ev is InputEventScreenDrag or ev is InputEventMouseMotion):
            var pos=ev.position
            var radius:float=float(j.radius)
            var delta=(pos-j.center).limit_length(radius)
            var raw_value:Vector2=delta/radius
            j.value=Vector2.ZERO if raw_value.length() < 0.10 else raw_value
            j.knob.position=j.center+delta-j.knob_half
            callback.call(j.value)
    )

func resume_campaign() -> void:
    var repair:Dictionary=campaign_manager.reconcile(workday_manager,life_cycle_manager,tutorial_manager,area)
    var migrated_milestone:Dictionary={}
    if life_cycle_manager.phase == PHASE_WORK:
        migrated_milestone=campaign_manager.check_first_cycle(workday_manager,life_cycle_manager)
        if not migrated_milestone.is_empty():
            clt_coins+=int(migrated_milestone.get("clt_coins",0))
            career_xp+=int(migrated_milestone.get("xp",0))
            reputation+=int(migrated_milestone.get("reputation",0))
    if bool(repair.get("changed",false)) or not migrated_milestone.is_empty():
        save_game()
    if life_cycle_manager.phase in [PHASE_HOME, PHASE_MORNING]:
        show_home_scene()
    else:
        show_gameplay()

func show_home_scene() -> void:
    current_screen="home"
    clear_scene()
    audio_manager.set_context("home")
    var bg=ColorRect.new(); bg.color=Color("20242a"); bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(bg)
    var wall=ColorRect.new(); wall.color=Color("343b43"); wall.position=Vector2(120,80); wall.size=Vector2(1040,520); bg.add_child(wall)
    var floor_band=ColorRect.new(); floor_band.color=Color("3c332d"); floor_band.position=Vector2(120,475); floor_band.size=Vector2(1040,125); bg.add_child(floor_band)
    var title=label("🏠 KITNET • LAR DOCE LAR",22); title.position=Vector2(150,100); bg.add_child(title)
    var detail=label("Seu espaço fora do expediente • Conforto %d/100" % home_comfort,15); detail.position=Vector2(150,135); bg.add_child(detail)
    var ui=CanvasLayer.new(); ui.name="HomeUI"; ui.process_mode=Node.PROCESS_MODE_ALWAYS; add_child(ui)
    add_pause_button(ui)
    if life_cycle_manager.phase == PHASE_MORNING:
        show_morning_panel(ui)
    elif life_cycle_manager.is_weekend():
        show_weekend_day(ui)
    else:
        show_home_panel(ui)

func show_gameplay() -> void:
    current_screen="gameplay"
    audio_manager.set_context("work")
    clear_scene()
    var world=Node3D.new(); add_child(world)
    var env=WorldEnvironment.new(); var e=Environment.new(); e.background_mode=Environment.BG_COLOR; e.background_color=Color("8aa0ad"); env.environment=e; world.add_child(env)
    var light=DirectionalLight3D.new(); light.rotation_degrees=Vector3(-55,-25,0); world.add_child(light)
    var floor=MeshInstance3D.new(); var pm=PlaneMesh.new(); pm.size=Vector2(40,30); floor.mesh=pm; world.add_child(floor)
    var player=CharacterBody3D.new(); player.name="Player"; player.set_script(load("res://scripts/player.gd")); world.add_child(player)
    player.camera_sensitivity=settings_manager.camera_sensitivity; player.invert_camera=settings_manager.invert_camera
    var shape=CollisionShape3D.new(); var cs=CapsuleShape3D.new(); cs.height=1.8; cs.radius=.42; shape.shape=cs; shape.position.y=.9; player.add_child(shape)
    var mesh=MeshInstance3D.new(); var cap=CapsuleMesh.new(); cap.height=1.8; cap.radius=.42; mesh.mesh=cap; mesh.position.y=.9; player.add_child(mesh)
    var pivot=Node3D.new(); pivot.name="CameraPivot"; pivot.position=Vector3(0,1.5,0); player.add_child(pivot)
    var cam=Camera3D.new(); cam.position=Vector3(0,1.4,5.5); cam.current=true; pivot.add_child(cam)

    # Escritório LR Global — primeira área 3D jogável
    add_box(world,Vector3(0,1.5,-10),Vector3(18,3,0.25),Color("d8dde2"))
    add_box(world,Vector3(-9,1.5,-1),Vector3(.25,3,18),Color("d8dde2"))
    add_box(world,Vector3(9,1.5,-1),Vector3(.25,3,18),Color("d8dde2"))
    add_box(world,Vector3(0,.45,-3.0),Vector3(3.0,.9,1.2),Color("5a4635"))
    add_box(world,Vector3(0,1.25,-3.0),Vector3(1.0,.7,.08),Color("1b2630"))
    add_box(world,Vector3(-4,.45,-6.0),Vector3(2.6,.9,1.1),Color("5a4635"))
    add_box(world,Vector3(4,.45,-6.0),Vector3(2.6,.9,1.1),Color("5a4635"))
    add_box(world,Vector3(-7,1.15,-8.7),Vector3(.8,1.5,.25),Color("28343e"))
    var point_tag=Label3D.new(); point_tag.text="RELÓGIO DE PONTO"; point_tag.position=Vector3(-7,2.15,-8.55); point_tag.font_size=34; world.add_child(point_tag)
    var mentor_name=tutorial_manager.get_mentor_name(area)
    var specialist=add_npc(world,mentor_name,Vector3(3.7,0,-5.1),Color("6f8ca5"))
    var loud=add_npc(world,"Colega da Voz Alta",Vector3(-3.7,0,-5.1),Color("9b755b"))
    var fitness=add_npc(world,"Supervisor Fitness",Vector3(6.5,0,-8.0),Color("6e8f68"))
    var metido=add_npc(world,"Colega Curioso",Vector3(-7.0,0,-2.0),Color("7f7894"))
    var brava=add_npc(world,"Colega Sem Paciência",Vector3(-5.2,0,-2.0),Color("9a6475"))
    var capacete=add_npc(world,"Colega do Capacete",Vector3(7.0,0,-2.0),Color("647b91"))
    var audio=add_npc(world,"Atendente dos Áudios",Vector3(5.2,0,-2.0),Color("8d6f78"))
    var rave=add_npc(world,"Líder da Rave",Vector3(0.0,0,-8.0),Color("775c8f"))
    var lucas=add_lucas_npc(world,Vector3(1.8,0,-6.8))
    start_office_routine(loud, Vector3(-3.7,0,-5.1), Vector3(-1.6,0,-7.2), 4.2)
    start_office_routine(fitness, Vector3(6.5,0,-8.0), Vector3(5.0,0,-4.8), 6.0)

    add_box(world,Vector3(0,1.1,8.0),Vector3(3.0,2.2,.25),Color("394854"))
    var exit_tag=Label3D.new(); exit_tag.text="SAÍDA / CASA"; exit_tag.position=Vector3(0,2.6,7.8); exit_tag.font_size=34; world.add_child(exit_tag)

    settings_manager.apply_runtime_settings()
    settings_manager.apply_scene_graphics(world)
    mobile_ui_manager.set_touch_scale(settings_manager.touch_scale)
    var ui=CanvasLayer.new(); ui.name="GameUI"; ui.process_mode=Node.PROCESS_MODE_ALWAYS; add_child(ui)
    var mobile_layout:Dictionary=mobile_ui_manager.gameplay_layout()
    var top=Panel.new(); top.position=mobile_layout.top_position; top.size=mobile_layout.top_size; top.modulate=Color(1,1,1,.92); ui.add_child(top)
    var who=label("%s  •  %s • %s" % [player_name,career_role.to_upper(),area.to_upper()],16); who.position=Vector2(18,8); top.add_child(who)
    var money=label("R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation],17); money.position=Vector2(18,38); top.add_child(money)
    var hud_day:String="SEGUNDA-FEIRA" if tutorial_manager.is_active() else str(workday_manager.get_day_label())
    var shop=Button.new(); shop.text="🛒 LOJA"; shop.size=Vector2(145,48); shop.position=Vector2(top.size.x-shop.size.x-14,12); top.add_child(shop)
    add_pause_button(ui,top)
    var clock_label=label("%s • 07:45" % life_cycle_manager.day_short(hud_day),18); clock_label.position=Vector2(max(565.0,shop.position.x-265.0),24); top.add_child(clock_label)

    var objective=Panel.new(); objective.position=mobile_layout.objective_position; objective.size=Vector2(560,98); objective.modulate=Color(1,1,1,.88); ui.add_child(objective)
    var obj=label(tutorial_manager.get_objective(area),16); obj.position=Vector2(14,8); objective.add_child(obj)
    var tutorial_hint=label(tutorial_manager.get_hint(),13); tutorial_hint.position=Vector2(14,63); objective.add_child(tutorial_hint)

    var bag=Button.new(); bag.text="🎒\nMOCHILA"; bag.position=mobile_layout.bag_position; bag.size=mobile_layout.bag_size; ui.add_child(bag)
    var phone=Button.new(); phone.text="📱"; phone.position=mobile_layout.phone_position; phone.size=mobile_layout.phone_size; ui.add_child(phone)
    var interact=Button.new(); interact.text="✋\nINTERAGIR"; interact.position=mobile_layout.interact_position; interact.size=mobile_layout.interact_size; ui.add_child(interact)
    var run=Button.new(); run.text="🏃\nCORRER"; run.position=mobile_layout.run_position; run.size=mobile_layout.run_size; ui.add_child(run)

    var inventory=Panel.new(); inventory.position=mobile_layout.inventory_position; inventory.size=Vector2(390,330); inventory.visible=false; ui.add_child(inventory)
    var invbox=VBoxContainer.new(); invbox.position=Vector2(18,15); inventory.add_child(invbox)
    invbox.add_child(label("🎒 MOCHILA / INVENTÁRIO",24))
    invbox.add_child(label("TRABALHO",14)); invbox.add_child(label("🪪 Crachá LR Global\n📱 Celular\n📄 Documentos de admissão",17))
    invbox.add_child(label("PESSOAL",14)); invbox.add_child(label("🔑 Chaves da kitnet\n👛 Carteira\n👕 Roupa reserva",17))
    var close=button("FECHAR MOCHILA"); close.custom_minimum_size=Vector2(330,44); invbox.add_child(close)
    bag.pressed.connect(func(): inventory.visible=!inventory.visible)
    close.pressed.connect(func(): inventory.visible=false)
    shop.pressed.connect(func(): show_clt_shop(ui, money))
    phone.pressed.connect(func(): show_game_phone(ui, obj, money))
    mission_finished = tutorial_manager.first_day_completed or tutorial_manager.stage in [STAGE_RETURN_MENTOR,STAGE_CLOCK_OUT,STAGE_COMPLETE]
    specialist_followup = tutorial_manager.first_day_completed or tutorial_manager.stage in [STAGE_CLOCK_OUT,STAGE_COMPLETE]
    interact.pressed.connect(func():
        settings_manager.vibrate(18)
        var p=player.global_position
        if p.distance_to(Vector3(-7,0,-8.7)) < 3.0:
            if tutorial_manager.is_active() and tutorial_manager.stage == STAGE_CLOCK_IN:
                tutorial_manager.advance("clock_in")
                save_game()
                obj.text=tutorial_manager.get_objective(area)
                tutorial_hint.text=tutorial_manager.get_hint()
            else:
                obj.text="✅ PONTO JÁ REGISTRADO • 07:45"
        elif p.distance_to(Vector3(-3.7,0,-5.1)) < 3.2:
            discover_easter_egg(ui, "voz_alta", "Colega da Voz Alta", "NÃO PRECISA GRITAR!", 50, money, "📢 ‘SEMPRE, SEMPRE, SEMPRE!’")
        elif p.distance_to(Vector3(6.5,0,-8.0)) < 3.2:
            discover_easter_egg(ui, "fitness", "Supervisor Fitness", "PROJETO VERÃO", 75, money, "🏋️ ‘Reunião depois. Primeiro, proteína.’")
        elif p.distance_to(Vector3(-7.0,0,-2.0)) < 2.8:
            discover_easter_egg(ui, "curioso", "Colega Curioso", "NINGUÉM TE CHAMOU", 60, money, "👀 Ele aparece em toda conversa — mesmo quando ninguém chamou.")
        elif p.distance_to(Vector3(-5.2,0,-2.0)) < 2.8:
            discover_easter_egg(ui, "sem_paciencia", "Colega Sem Paciência", "NÃO SE METE!", 60, money, "😤 ‘EU NÃO FALEI CONTIGO!’")
            if easter_eggs.has("curioso"):
                show_duo_easter_egg(ui, money)
        elif p.distance_to(Vector3(7.0,0,-2.0)) < 2.8:
            discover_easter_egg(ui, "capacete", "Colega do Capacete", "PROTEÇÃO MÁXIMA", 65, money, "🪖 Um capacete tão grande que virou item lendário.")
        elif p.distance_to(Vector3(5.2,0,-2.0)) < 2.8:
            discover_easter_egg(ui, "audios", "Atendente dos Áudios", "ÁUDIO DE 2 MINUTOS", 65, money, "🎙️ ‘MAS QUE P—... NÃO É POSSÍVEL!’ • gravando áudio 01:47...")
        elif p.distance_to(Vector3(0.0,0,-8.0)) < 2.8:
            discover_easter_egg(ui, "rave", "Líder da Rave", "SEXTOU!", 75, money, "🎧 Corpo no escritório. Mente no festival de sexta-feira.")
        elif p.distance_to(Vector3(1.8,0,-6.8)) < 2.8:
            show_lucas_interaction(ui, money, obj)
        elif p.distance_to(Vector3(3.7,0,-5.1)) < 3.2:
            if area == "Gestão de Frotas":
                discover_easter_egg(ui, "especialista", "Especialista da Frota", "B-B-BEM-VINDO À FROTA", 50, money, "🔧 Um personagem especial da Gestão de Frotas foi descoberto.")
            if tutorial_manager.is_active() and tutorial_manager.stage == STAGE_MEET_MENTOR:
                tutorial_manager.advance("meet_mentor")
                save_game()
                obj.text="💬 %s\nSua primeira demanda já chegou no computador." % mentor_name
                tutorial_hint.text=tutorial_manager.get_hint()
            elif tutorial_manager.is_active() and tutorial_manager.stage == STAGE_RETURN_MENTOR:
                tutorial_manager.advance("return_mentor")
                specialist_followup=true
                work_clock="17:25"
                clock_label.text="SEG • 17:25"
                save_game()
                obj.text="💬 %s\nBoa! Demanda encaminhada. Organize o fechamento e pode encerrar." % mentor_name
                tutorial_hint.text=tutorial_manager.get_hint()
            else:
                obj.text=tutorial_manager.get_objective(area)
        elif p.distance_to(Vector3(0,0,-3.0)) < 3.0:
            if tutorial_manager.is_active() and tutorial_manager.stage == STAGE_USE_COMPUTER:
                show_work_computer(ui, obj, money, func():
                    mission_finished=true
                    tutorial_manager.advance("use_computer")
                    work_clock="16:50"
                    clock_label.text="SEG • 16:50"
                    tutorial_hint.text=tutorial_manager.get_hint()
                    save_game()
                )
            elif tutorial_manager.first_day_completed:
                show_workday_panel(ui, money, obj)
            else:
                obj.text=tutorial_manager.get_objective(area)
                tutorial_hint.text=tutorial_manager.get_hint()
        elif p.distance_to(Vector3(0,0,7.5)) < 3.0:
            if tutorial_manager.is_active() and tutorial_manager.stage == STAGE_CLOCK_OUT:
                tutorial_manager.advance("clock_out")
                clock_label.text="SEG • 17:30"
                save_game()
                show_end_of_day(ui, obj, money)
            elif tutorial_manager.first_day_completed:
                obj.text="🚪 SAÍDA\nUse o painel de expediente para encerrar o dia atual."
            else:
                obj.text="🚪 SAÍDA\nSeu expediente ainda não terminou."
        else:
            obj.text="✋ INTERAGIR\nChegue mais perto de um objeto ou NPC interativo."
    )

    var left=make_joystick(ui,mobile_layout.left_joystick_center,"MOVIMENTO")
    var right=make_joystick(ui,mobile_layout.right_joystick_center,"CÂMERA")
    bind_joystick(left,func(v): player.set_mobile_move(Vector2(v.x,v.y)))
    bind_joystick(right,func(v): player.set_mobile_look(Vector2(v.x,v.y)))
    run.button_down.connect(func(): settings_manager.vibrate(12); player.set_mobile_sprint(true))
    run.button_up.connect(func(): player.set_mobile_sprint(false))
    run.mouse_exited.connect(func(): player.set_mobile_sprint(false))

    restore_life_phase(ui, obj, money)


func restore_life_phase(ui:CanvasLayer, objective_label:Label, hud_money:Label) -> void:
    if life_cycle_manager.phase == PHASE_HOME:
        objective_label.text="🏠 Tempo livre • %s" % life_cycle_manager.display_day
        if life_cycle_manager.is_weekend():
            show_weekend_day(ui)
        else:
            show_home_panel(ui)
    elif life_cycle_manager.phase == PHASE_MORNING:
        objective_label.text="☀️ Prepare-se para o próximo expediente."
        show_morning_panel(ui)


func show_lucas_interaction(ui:CanvasLayer, hud_money:Label, objective_label:Label) -> void:
    var old=ui.get_node_or_null("LucasInteraction")
    if old: old.queue_free()
    var panel=Panel.new(); panel.name="LucasInteraction"; panel.position=Vector2(350,155); panel.size=Vector2(580,405); ui.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(24,20); box.size=Vector2(532,365); panel.add_child(box)
    box.add_child(label("💻 LUCAS • ANALISTA DE GESTÃO DE FROTAS",24))
    box.add_child(label("Lucas está alternando entre uma planilha, um dashboard e um site interno.",16))
    var normal=Button.new(); normal.text="Perguntar sobre a frota"; normal.custom_minimum_size=Vector2(530,50); box.add_child(normal)
    var sheet=Button.new(); sheet.text="📊 Preciso de ajuda numa planilha"; sheet.custom_minimum_size=Vector2(530,56); box.add_child(sheet)
    if easter_eggs.has("lucas_planilhas"):
        var rapidinho=Button.new(); rapidinho.text="🛠️ Ver quem está pedindo ‘só um ajustezinho’"; rapidinho.custom_minimum_size=Vector2(530,52); box.add_child(rapidinho)
        rapidinho.pressed.connect(func(): panel.queue_free(); show_lucas_help_chain(ui,hud_money,objective_label))
        var chamados=Button.new(); chamados.text="📥 Central de chamados internos"; chamados.custom_minimum_size=Vector2(530,52); box.add_child(chamados)
        chamados.pressed.connect(func(): panel.queue_free(); show_internal_requests(ui,hud_money,objective_label))
        var ideias=Button.new(); ideias.text="💡 Ver o que o Lucas está inventando agora"; ideias.custom_minimum_size=Vector2(530,52); box.add_child(ideias)
        var wife_call=Button.new(); wife_call.text="📱 Celular do Lucas está tocando • Esposa ❤️"; wife_call.custom_minimum_size=Vector2(530,52); box.add_child(wife_call)
        wife_call.pressed.connect(func(): panel.queue_free(); show_lucas_wife_call(ui,objective_label))
        ideias.pressed.connect(func():
            objective_label.text="💭 LUCAS — MODO MELHORIA\n‘Era só uma planilha... mas se eu fizer um dashboard, ligar num site e automatizar a atualização...’ 😂"
            panel.queue_free()
        )
    var leave=Button.new(); leave.text="Deixar ele trabalhar"; leave.custom_minimum_size=Vector2(530,48); box.add_child(leave)
    normal.pressed.connect(func():
        objective_label.text="💬 LUCAS\n‘A frota tá corrida hoje. Se aparecer fórmula quebrada, me chama.’"
        panel.queue_free()
    )
    leave.pressed.connect(func(): panel.queue_free())
    sheet.pressed.connect(func():
        panel.queue_free()
        show_lucas_spreadsheet_egg(ui,hud_money,objective_label)
    )


func show_lucas_wife_call(ui:CanvasLayer, objective_label:Label) -> void:
    var old=ui.get_node_or_null("LucasWifeCall")
    if old: old.queue_free(); return
    lucas_wife_calls_seen += 1
    save_game()
    var panel=Panel.new(); panel.name="LucasWifeCall"; panel.position=Vector2(770,105); panel.size=Vector2(365,500); ui.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(20,18); box.size=Vector2(325,460); panel.add_child(box)
    box.add_child(label("📱 CHAMADA DE VÍDEO",20))
    box.add_child(label("ESPOSA ❤️",30))
    var portrait=ColorRect.new(); portrait.color=Color("d9b08c"); portrait.custom_minimum_size=Vector2(325,185); box.add_child(portrait)
    var note=Label.new(); note.text="VIDEOCHAMADA\n(personagem 2D na tela do celular)"; note.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; note.vertical_alignment=VERTICAL_ALIGNMENT_CENTER; note.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); portrait.add_child(note)
    box.add_child(label("‘Amor, que horas você vem pra casa? ❤️’",17))
    box.add_child(label("Lucas: ‘Tô terminando umas coisas aqui... já vou.’",16))
    var answer=Button.new(); answer.text="😂 OUVIR A CONVERSA"; answer.custom_minimum_size=Vector2(325,48); box.add_child(answer)
    answer.pressed.connect(func(): objective_label.text="📱 LUCAS EM VIDEOCHAMADA\nEsposa: ‘Vai treinar hoje ou vai casar com essa planilha?’\nLucas: ‘Vou treinar sim... só terminar isso aqui. 😂’")
    var close=Button.new(); close.text="DEIXAR O LUCAS ATENDER"; close.custom_minimum_size=Vector2(325,45); box.add_child(close); close.pressed.connect(func(): panel.queue_free())

# v0.21 — cadeia recorrente “Só um ajustezinho” do NPC Lucas
func show_lucas_help_chain(ui:CanvasLayer, hud_money:Label, objective_label:Label) -> void:
    var old=ui.get_node_or_null("LucasHelpChain")
    if old: old.queue_free(); return
    var requests=[
        ["Coordenadora", "A planilha não está atualizando o indicador do dia.", "Corrigir fórmula e atualizar indicador"],
        ["Programação", "O filtro de placas começou a trazer veículo duplicado.", "Revisar filtro e remover duplicidade"],
        ["Atendimento", "O dashboard ficou sem os números depois da atualização.", "Ajustar fonte de dados do dashboard"],
        ["Coordenadora", "Lucas, consegue colocar isso num site pra ficar mais fácil pro pessoal?", "Criar uma tela interna para o processo"],
        ["Financeiro", "Toda semana a gente faz isso manual. Tem como automatizar?", "Automatizar uma rotina repetitiva"],
        ["Qualidade", "O formulário está bom, mas dava pra deixar mais organizado e visual?", "Melhorar formulário e experiência do usuário"]
    ]
    var idx=lucas_help_count % requests.size()
    var req=requests[idx]
    var panel=Panel.new(); panel.name="LucasHelpChain"; panel.position=Vector2(310,125); panel.size=Vector2(660,470); ui.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(26,22); box.size=Vector2(608,425); panel.add_child(box)
    box.add_child(label("💻 SÓ UM AJUSTEZINHO...",28))
    box.add_child(label("%s: ‘Lucas, rapidinho... %s’" % [req[0],req[1]],17))
    box.add_child(label("📌 Pedido %d • %s" % [lucas_help_count+1,req[2]],16))
    var solve=Button.new(); solve.text="📊 AJUDAR O LUCAS A RESOLVER"; solve.custom_minimum_size=Vector2(605,54); box.add_child(solve)
    var later=Button.new(); later.text="AGORA NÃO"; later.custom_minimum_size=Vector2(605,46); box.add_child(later)
    later.pressed.connect(func(): panel.queue_free())
    solve.pressed.connect(func():
        lucas_help_count+=1; internal_requests_resolved+=1; internal_request_pressure=max(0,internal_request_pressure-1); career_xp+=8; reputation+=2
        internal_requests_history.push_front("%s • %s • RESOLVIDO" % [req[0],req[2]])
        if internal_requests_history.size()>8: internal_requests_history.resize(8)
        var bonus=""
        if lucas_help_count>=3 and not lucas_mastery_rewarded:
            lucas_mastery_rewarded=true; clt_coins+=75; unlocked_skins["Camiseta Só um Ajustezinho"]=true
            bonus="\n🏆 Conquista secreta: SUPORTE NÃO OFICIAL!  🪙 +75 CLT Coins  👕 Camiseta Só um Ajustezinho"
        if lucas_help_count>=6 and not lucas_innovation_rewarded:
            lucas_innovation_rewarded=true; clt_coins+=100; unlocked_skins["Moletom Modo Melhoria"]=true
            bonus += "\n💡 Nova conquista: ERA SÓ UMA PLANILHA!  🪙 +100 CLT Coins  👕 Moletom Modo Melhoria"
        save_game()
        hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]
        objective_label.text="💻 LUCAS\n‘Pronto. Agora deixa eu voltar pra minha demanda antes que apareça outro. 😂’"
        solve.disabled=true; solve.text="✅ AJUSTE CONCLUÍDO • +8 XP • +2 REP"
        box.add_child(label("Problema resolvido.%s" % bonus,16))
    )

func show_lucas_spreadsheet_egg(ui:CanvasLayer, hud_money:Label, objective_label:Label) -> void:
    if easter_eggs.has("lucas_planilhas"):
        objective_label.text="💬 LUCAS\n‘Se for planilha, já fala logo. 😂’"
        return
    easter_eggs["lucas_planilhas"]={"name":"O Cara das Planilhas","achievement":"SÓ UM AJUSTEZINHO","reward":150,"skin":"Traje Gaúcho Tricolor","vehicle":"Planilhamóvel"}
    unlocked_skins["Traje Gaúcho Tricolor"]=true
    unlocked_vehicles["Planilhamóvel"]=true
    ensure_vehicle_stats("Planilhamóvel")
    garage_unlocked=true
    if active_vehicle == "A pé": active_vehicle="Planilhamóvel"
    clt_coins+=150
    save_game()
    hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]
    objective_label.text="📊 LUCAS\n‘Deixa eu ver... pronto.’\nVocê: ‘Já?!’\nLucas: ‘Era a fórmula. 😂’"
    var panel=Panel.new(); panel.name="LucasLegendaryEgg"; panel.position=Vector2(300,105); panel.size=Vector2(680,510); ui.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(28,22); box.size=Vector2(624,465); panel.add_child(box)
    box.add_child(label("🥚✨ EASTER EGG LENDÁRIO!",31))
    box.add_child(label("O CARA DAS PLANILHAS",28))
    box.add_child(label("“Me falaram que é você que arruma essas coisas...”",17))
    box.add_child(label("🏆 Conquista: SÓ UM AJUSTEZINHO",20))
    box.add_child(label("🪙 +150 CLT Coins",21))
    box.add_child(label("👕 Traje exclusivo: GAÚCHO TRICOLOR",20))
    box.add_child(label("🚗 VEÍCULO LENDÁRIO: PLANILHAMÓVEL",22))
    box.add_child(label("Detalhe secreto: a multimídia do carro exibe uma planilha. 😂",15))
    var close=Button.new(); close.text="COLETAR RECOMPENSAS LENDÁRIAS"; close.custom_minimum_size=Vector2(620,54); box.add_child(close)
    close.pressed.connect(func(): panel.queue_free())

func discover_easter_egg(ui: CanvasLayer, egg_id: String, character_name: String, achievement: String, reward: int, hud_money: Label, flavor: String) -> void:
    if easter_eggs.has(egg_id):
        return
    var skin=skin_for_egg(egg_id)
    easter_eggs[egg_id] = {"name":character_name,"achievement":achievement,"reward":reward,"skin":skin}
    unlocked_skins[skin]=true
    clt_coins += reward
    hud_money.text="R$ 1.250     🪙 %d CLT Coins     ⭐ XP 20/100     REP 50" % clt_coins
    var old=ui.get_node_or_null("EasterEggPopup")
    if old: old.queue_free()
    var panel=Panel.new(); panel.name="EasterEggPopup"; panel.position=Vector2(335,150); panel.size=Vector2(610,420); ui.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(26,22); box.size=Vector2(558,370); panel.add_child(box)
    box.add_child(label("🥚 EASTER EGG ENCONTRADO!",30))
    box.add_child(label("PERSONAGEM ESPECIAL DA LR GLOBAL",16))
    box.add_child(label(character_name,26))
    var desc=label(flavor,16); desc.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(desc)
    box.add_child(label("🏆 Conquista: “%s”" % achievement,18))
    box.add_child(label("🪙 +%d CLT Coins" % reward,22))
    box.add_child(label("👕 SKIN EXCLUSIVA: %s" % skin,20))
    box.add_child(label("Não disponível na Loja • recompensa de descoberta",14))
    box.add_child(label("Coleção: %d/%d personagens especiais descobertos" % [easter_eggs.size(),easter_total],17))
    var close=Button.new(); close.text="COLETAR RECOMPENSA"; close.custom_minimum_size=Vector2(550,52); box.add_child(close)
    close.pressed.connect(func(): panel.queue_free())
    save_game()

func show_game_phone(ui: CanvasLayer, objective_label: Label, hud_money: Label) -> void:
    var old=ui.get_node_or_null("GamePhone")
    if old: old.queue_free(); return
    var p=Panel.new(); p.name="GamePhone"; p.position=Vector2(700,65); p.size=Vector2(470,590); ui.add_child(p)
    var scroll=ScrollContainer.new(); scroll.position=Vector2(16,16); scroll.size=Vector2(438,558); p.add_child(scroll)
    var box=VBoxContainer.new(); box.custom_minimum_size=Vector2(410,0); scroll.add_child(box)
    box.add_child(label("📱 CELULAR LR",27))
    var finance=Button.new(); finance.text="💰 FINANÇAS / HOLERITE"; finance.custom_minimum_size=Vector2(405,44); box.add_child(finance); finance.pressed.connect(func(): show_finance_panel(ui, hud_money))
    var save_btn=Button.new(); save_btn.text="💾 SALVAR PROGRESSO"; save_btn.custom_minimum_size=Vector2(405,44); box.add_child(save_btn); save_btn.pressed.connect(func(): save_game(); save_btn.text="✅ PROGRESSO SALVO")
    var campaign=Button.new(); campaign.text="🗓️ CAMPANHA / PROGRESSO"; campaign.custom_minimum_size=Vector2(405,44); box.add_child(campaign); campaign.pressed.connect(func(): show_campaign_panel(ui))
    var settings=Button.new(); settings.text="⚙️ CONFIGURAÇÕES"; settings.custom_minimum_size=Vector2(405,44); box.add_child(settings); settings.pressed.connect(func(): show_settings(ui))
    var career=Button.new(); career.text="📈 MINHA CARREIRA"; career.custom_minimum_size=Vector2(405,44); box.add_child(career); career.pressed.connect(func(): show_career_panel(ui))
    var improvements=Button.new(); improvements.text="💡 PROJETOS DE MELHORIA"; improvements.custom_minimum_size=Vector2(405,44); box.add_child(improvements); improvements.pressed.connect(func(): show_improvement_projects(ui,hud_money))
    var workday=Button.new(); workday.text="🗂️ EXPEDIENTE / DEMANDAS"; workday.custom_minimum_size=Vector2(405,44); workday.disabled=tutorial_manager.is_active(); box.add_child(workday); workday.pressed.connect(func(): show_workday_panel(ui,hud_money,objective_label))
    if tutorial_manager.is_active():
        box.add_child(label("🔒 O gerenciador completo libera após concluir o primeiro dia.",13))
    box.add_child(label("🥚 COLEÇÃO • EASTER EGGS",19))
    box.add_child(label("Descobertos: %d/%d" % [easter_eggs.size(),easter_total],18))
    var eggs=[
        ["voz_alta","Colega da Voz Alta","SEMPRE³"],
        ["fitness","Supervisor Fitness","PROJETO VERÃO"],
        ["especialista","Especialista da Frota","B-B-BEM-VINDO À FROTA"],
        ["curioso","Colega Curioso","NINGUÉM TE CHAMOU"],
        ["sem_paciencia","Colega Sem Paciência","NÃO SE METE!"],
        ["capacete","Colega do Capacete","PROTEÇÃO MÁXIMA"],
        ["audios","Atendente dos Áudios","ÁUDIO DE 2 MINUTOS"],
        ["rave","Líder da Rave","SEXTOU!"],
        ["lucas_planilhas","???","SÓ UM AJUSTEZINHO"]
    ]
    for egg in eggs:
        if easter_eggs.has(egg[0]):
            var data=easter_eggs[egg[0]]
            box.add_child(label("✅ %s\n   🏆 %s\n   👕 %s" % [egg[1],egg[2],data.get("skin","Skin Especial")],15))
        else:
            box.add_child(label("❔ PERSONAGEM NÃO DESCOBERTO",15))
    var bonus=label("",15); box.add_child(bonus)
    if easter_eggs.size()==easter_total:
        bonus.text="🎁 COLEÇÃO COMPLETA! Bônus: +100 CLT Coins"
    else:
        bonus.text="Explore a LR Global e converse com personagens diferentes."
    var tower_job=Button.new(); tower_job.text="🏙️ MISSÃO • TORRE DE CONTROLE"; tower_job.custom_minimum_size=Vector2(405,46); box.add_child(tower_job)
    tower_job.pressed.connect(func(): p.queue_free(); show_tower_story_mission(ui,hud_money,objective_label))
    var north=Button.new(); north.text="🧭 VISITAR UNIDADE NORTE • evento especial"; north.custom_minimum_size=Vector2(405,46); box.add_child(north)
    north.pressed.connect(func(): p.queue_free(); show_north_unit(ui, hud_money))
    var close=Button.new(); close.text="FECHAR CELULAR"; close.custom_minimum_size=Vector2(405,46); box.add_child(close)
    close.pressed.connect(func(): p.queue_free())

func show_campaign_panel(ui:CanvasLayer) -> void:
    var old=ui.get_node_or_null("CampaignPanel")
    if old: old.queue_free(); return
    var repair:Dictionary=campaign_manager.reconcile(workday_manager,life_cycle_manager,tutorial_manager,area)
    if bool(repair.get("changed",false)):
        save_game()
    var p=Panel.new(); p.name="CampaignPanel"; p.position=Vector2(270,80); p.size=Vector2(740,560); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(26,20); box.size=Vector2(688,515); p.add_child(box)
    box.add_child(label("🗓️ CAMPANHA / PROGRESSO",28))
    var progress=label(campaign_manager.get_progress_text(workday_manager,life_cycle_manager,career_role,improvement_manager.completed_projects.size(),easter_eggs.size(),easter_total),17); progress.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(progress)
    box.add_child(label("🎯 PRÓXIMO MARCO",15))
    var next=label(campaign_manager.get_next_milestone(career_role,workday_manager),17); next.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(next)
    if workday_manager.total_completed_days > 0:
        var week_to_show:int=int(workday_manager.current_week)
        if life_cycle_manager.weekend_stage > 0:
            week_to_show=maxi(1,workday_manager.current_week-1)
        var week_stats:Dictionary=workday_manager.get_week_summary(week_to_show)
        box.add_child(label("📊 SEMANA %d • %s\n✅ %d resolvidas • 📤 %d comunicadas • ⏳ %d pendentes" % [week_to_show,week_stats.get("performance","EM ANDAMENTO"),week_stats.get("resolved",0),week_stats.get("communicated",0),week_stats.get("pending",0)],15))
    if campaign_manager.load_repairs > 0:
        box.add_child(label("🛠️ Save compatibilizado com a v0.28 • %d ajuste(s) automático(s)." % campaign_manager.load_repairs,13))
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(680,46); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func show_workday_panel(ui:CanvasLayer, hud_money:Label, objective_label:Label) -> void:
    var old=ui.get_node_or_null("WorkdayPanel")
    if old: old.queue_free(); return
    workday_manager.set_permanent_effects(improvement_manager.permanent_effects)
    workday_manager.ensure_day(area, career_role)
    current_day=workday_manager.get_day_label()
    var stats:Dictionary=workday_manager.get_day_stats()
    var p=Panel.new(); p.name="WorkdayPanel"; p.position=Vector2(185,58); p.size=Vector2(910,610); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(24,18); box.size=Vector2(860,565); p.add_child(box)
    box.add_child(label("🗂️ GERENCIADOR DE EXPEDIENTE",28))
    box.add_child(label("SEMANA %d • %s • DIA %d/5 • %s" % [workday_manager.current_week,workday_manager.get_day_label(),workday_manager.current_day,area],17))
    var briefing:Dictionary=workday_manager.get_day_briefing()
    var brief=label("📌 %s\n%s" % [briefing.get("title","EXPEDIENTE"),briefing.get("description","")],14); brief.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(brief)
    var info=label("💡 %s" % briefing.get("tip","Resolva o que for possível e comunique o que precisa continuar."),13); info.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(info)
    box.add_child(label("✅ %d resolvidas   📤 %d comunicadas   ⏳ %d pendentes" % [stats.get("resolved",0),stats.get("communicated",0),stats.get("pending",0)],15))
    for i in range(workday_manager.active_tasks.size()):
        var task_index:=i
        var task:Dictionary=workday_manager.active_tasks[task_index]
        var row=HBoxContainer.new(); box.add_child(row)
        var effect_mark="✨ " if str(task.get("improvement_effect",""))!="" else ""
        var story_mark="📖 " if str(task.get("source",""))=="historia_semana1" else ""
        var txt=label("%s%s%s %s • %s" % [story_mark,effect_mark,workday_manager.priority_icon(str(task.get("priority","normal"))),task.get("title","Demanda"),str(task.get("status","pendente")).to_upper()],14); txt.custom_minimum_size=Vector2(555,40); row.add_child(txt)
        var solve=Button.new(); solve.text="RESOLVER"; solve.disabled=task.get("status","")!="pendente"; row.add_child(solve)
        var communicate=Button.new(); communicate.text="COMUNICAR"; communicate.disabled=task.get("status","")!="pendente"; row.add_child(communicate)
        solve.pressed.connect(func():
            var result=workday_manager.resolve_task(task_index)
            career_xp+=int(result.get("xp",0)); reputation+=int(result.get("rep",0))
            var discovered_id=str(result.get("improvement_unlocked",""))
            if discovered_id!="" and improvement_manager.discover_project(discovered_id):
                var project:Dictionary=improvement_manager.catalog.get(discovered_id,{})
                objective_label.text="💡 OPORTUNIDADE DE MELHORIA DESCOBERTA\n%s" % project.get("title","Novo projeto")
            elif str(result.get("improvement_effect",""))!="":
                objective_label.text="✨ MELHORIA EM AÇÃO\n%s" % result.get("improvement_effect","")
            else:
                objective_label.text="✅ %s" % result.get("message","Demanda resolvida.")
            save_game(); hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]; p.queue_free(); show_workday_panel(ui,hud_money,objective_label)
        )
        communicate.pressed.connect(func():
            var result=workday_manager.communicate_task(task_index); career_xp+=int(result.get("xp",0)); reputation+=int(result.get("rep",0)); objective_label.text="📤 %s" % result.get("message","Pendência comunicada."); save_game(); hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]; p.queue_free(); show_workday_panel(ui,hud_money,objective_label)
        )
    var rapid=Button.new(); rapid.text="🕔 17:29 • ‘SÓ UMA COISINHA RAPIDINHO’"; rapid.disabled=workday_manager.rapidinho_seen; box.add_child(rapid)
    rapid.pressed.connect(func(): workday_manager.add_rapidinho(); objective_label.text="🕔 17:29\n‘Consegue ver só uma coisinha rapidinho?’"; save_game(); p.queue_free(); show_workday_panel(ui,hud_money,objective_label))
    var actions=HBoxContainer.new(); box.add_child(actions)
    var end=Button.new(); end.text="ENCERRAR EXPEDIENTE"; end.custom_minimum_size=Vector2(415,46); actions.add_child(end)
    end.pressed.connect(func():
        var result=workday_manager.end_day()
        career_xp+=int(result.get("xp_bonus",0)); reputation+=int(result.get("rep",0)); current_day=str(result.get("next_day",current_day)); work_clock="17:30"
        if bool(result.get("weekly_close",false)): weekend_unlocked=true
        life_cycle_manager.begin_evening(result)
        campaign_manager.reconcile(workday_manager,life_cycle_manager,tutorial_manager,area)
        energy=max(0,energy-12)
        save_game(); hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]; p.queue_free(); show_workday_summary(ui,hud_money,objective_label,result)
    )
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(415,46); actions.add_child(close); close.pressed.connect(func(): p.queue_free())

func show_workday_summary(ui:CanvasLayer, hud_money:Label, objective_label:Label, summary:Dictionary) -> void:
    var old=ui.get_node_or_null("WorkdaySummary")
    if old: old.queue_free()
    var p=Panel.new(); p.name="WorkdaySummary"; p.position=Vector2(255,105); p.size=Vector2(770,520); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(28,24); box.size=Vector2(715,470); p.add_child(box)
    if bool(summary.get("weekly_close",false)):
        box.add_child(label("🎉 VOCÊ SOBREVIVEU À SEMANA!",30))
    else:
        box.add_child(label("🏁 EXPEDIENTE ENCERRADO",30))
    box.add_child(label("SEMANA %d • %s" % [summary.get("week",1),summary.get("day_label",current_day)],18))
    box.add_child(label("📌 %s" % summary.get("focus","EXPEDIENTE"),16))
    box.add_child(label("✅ Resolvidas: %d\n📤 Comunicadas/encaminhadas: %d\n⏳ Pendentes: %d\n🔴 Críticas pendentes: %d" % [summary.get("resolved",0),summary.get("communicated",0),summary.get("pending",0),summary.get("critical_pending",0)],18))
    var rep_change:=int(summary.get("rep",0))
    var result_text="REP %s%d" % [("+" if rep_change>=0 else ""),rep_change]
    if int(summary.get("xp_bonus",0))>0: result_text += "   •   Bônus +%d XP" % int(summary.get("xp_bonus",0))
    box.add_child(label(result_text,19))
    if int(summary.get("critical_pending",0))>0:
        box.add_child(label("⚠️ Uma demanda crítica ficou sem tratamento. A liderança vai lembrar disso.",15))
    elif int(summary.get("pending",0))==0:
        box.add_child(label("✨ Dia fechado sem pendências. Organização reconhecida.",15))
    elif int(summary.get("communicated",0))>0:
        box.add_child(label("👍 Nem tudo foi concluído, mas as pendências foram comunicadas.",15))
    box.add_child(label("Próximo expediente: SEMANA %d • %s" % [summary.get("next_week",workday_manager.current_week),summary.get("next_day",workday_manager.get_day_label())],16))
    objective_label.text="🏁 %s encerrada • Próximo: %s" % [summary.get("day_label","Dia"),summary.get("next_day","")]
    if career_manager.evaluation_available(career_role,career_xp,reputation,workday_manager):
        box.add_child(label("⭐ NOVA OPORTUNIDADE: avaliação para Analista Jr disponível.",16))
        var career_eval=button("⭐ INICIAR AVALIAÇÃO PARA ANALISTA JR"); box.add_child(career_eval)
        career_eval.pressed.connect(func(): p.queue_free(); show_promotion_evaluation(ui))
    var continue_btn=button("🏠 IR PARA CASA"); box.add_child(continue_btn)
    continue_btn.pressed.connect(func(): show_home_scene())
    if bool(summary.get("weekly_close",false)):
        var friday=button("💰 VER FECHAMENTO DA SEMANA"); box.add_child(friday); friday.pressed.connect(func(): p.queue_free(); show_friday_summary(ui,hud_money,int(summary.get("week",0))))

func show_improvement_projects(ui:CanvasLayer, hud_money:Label) -> void:
    var old=ui.get_node_or_null("ImprovementProjects")
    if old: old.queue_free(); return
    var p=Panel.new(); p.name="ImprovementProjects"; p.position=Vector2(250,95); p.size=Vector2(760,535); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(24,20); box.size=Vector2(710,490); p.add_child(box)
    box.add_child(label("💡 PROJETOS DE MELHORIA",28))
    box.add_child(label("Melhorias implantadas deixam efeitos permanentes na LR Global.",15))
    var status=label(improvement_manager.active_status(),18); box.add_child(status)
    var project_id=improvement_manager.get_project_for_area(area)
    var project=improvement_manager.catalog[project_id]
    var start=Button.new(); start.text="INICIAR • %s" % project.get("title","Projeto"); start.custom_minimum_size=Vector2(700,48); box.add_child(start)
    start.disabled=improvement_manager.active_project_id!="" or improvement_manager.completed_projects.has(project_id)
    start.pressed.connect(func():
        improvement_manager.start_project(project_id); save_game(); status.text=improvement_manager.active_status(); start.disabled=true
    )
    var advance=Button.new(); advance.text="AVANÇAR PRÓXIMA ETAPA"; advance.custom_minimum_size=Vector2(700,48); box.add_child(advance)
    advance.pressed.connect(func():
        var result=improvement_manager.advance_active_project()
        if result.is_empty(): status.text="Inicie um projeto antes de avançar."; return
        career_xp+=int(result.get("xp",0)); reputation+=int(result.get("rep",0)); save_game()
        if result.get("finished",false): status.text="✅ PROJETO CONCLUÍDO: %s\nEfeito permanente implantado: %s" % [result.get("title","Projeto"),result.get("effect","")]
        else: status.text="✅ Etapa %d/%d concluída.\n%s" % [result.get("step",0),result.get("total",0),improvement_manager.active_status()]
        hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]
    )
    box.add_child(label("Concluídos: %d  •  Efeitos permanentes: %d" % [improvement_manager.completed_projects.size(),improvement_manager.permanent_effects.size()],16))
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(700,46); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func skin_for_egg(egg_id:String) -> String:
    var skins={
        "voz_alta":"Camiseta SEMPRE³",
        "fitness":"Regata Projeto Verão",
        "especialista":"Uniforme Especialista da Frota",
        "curioso":"Camiseta NINGUÉM TE CHAMOU",
        "sem_paciencia":"Camiseta NÃO SE METE!",
        "capacete":"Capacete Proteção Máxima",
        "audios":"Moletom Sem Paciência",
        "rave":"Look Festival Sextou",
        "gemea_a":"Conjunto Fitness ARRASOU! A",
        "gemea_b":"Conjunto Fitness ARRASOU! B",
        "gaucha":"Jaqueta CHIMA & 5K",
        "torre":"Executiva da Torre",
        "lucas_planilhas":"Traje Gaúcho Tricolor"
    }
    return skins.get(egg_id,"Skin Especial LR")

func show_duo_easter_egg(ui:CanvasLayer, hud_money:Label) -> void:
    if easter_eggs.has("dupla_treta"): return
    easter_eggs["dupla_treta"]={"name":"A Brava & O Metido","achievement":"TRETA CORPORATIVA","reward":100,"skin":"Jaqueta Treta Corporativa"}
    unlocked_skins["Jaqueta Treta Corporativa"]=true
    clt_coins+=100
    save_game()
    hud_money.text="R$ 1.250     🪙 %d CLT Coins     ⭐ XP 20/100     REP 50" % clt_coins
    var panel=Panel.new(); panel.name="DuoEggPopup"; panel.position=Vector2(335,150); panel.size=Vector2(610,420); ui.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(26,22); box.size=Vector2(558,370); panel.add_child(box)
    box.add_child(label("🥚 EASTER EGG DE DUPLA!",30))
    box.add_child(label("A BRAVA & O METIDO",25))
    box.add_child(label("😡 ‘EU NÃO FALEI CONTIGO!’\n👀 ‘Mas eu só tava tentando ajudar...’",17))
    box.add_child(label("🏆 TRETA CORPORATIVA",20))
    box.add_child(label("🪙 +100 CLT Coins",20))
    box.add_child(label("👕 Jaqueta Treta Corporativa",20))
    var close=Button.new(); close.text="COLETAR RECOMPENSA"; close.custom_minimum_size=Vector2(550,52); box.add_child(close)
    close.pressed.connect(func(): panel.queue_free())

func show_work_computer(ui: CanvasLayer, objective_label: Label, hud_money: Label, on_complete: Callable) -> void:
    var existing=ui.get_node_or_null("WorkComputer")
    if existing:
        existing.queue_free()
    var first_case=tutorial_manager.get_first_case(area)
    var panel=Panel.new(); panel.name="WorkComputer"; panel.position=Vector2(210,120); panel.size=Vector2(860,500); ui.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(24,20); box.size=Vector2(810,455); panel.add_child(box)
    box.add_child(label(str(first_case.get("system","LR GLOBAL • SISTEMA")),28))
    box.add_child(label(str(first_case.get("title","PRIMEIRA DEMANDA")),16))
    var details=label(str(first_case.get("details","")),18); details.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(details)
    box.add_child(label("Investigue antes de concluir:",17))
    var actions=HBoxContainer.new(); box.add_child(actions)
    var check=Button.new(); check.text=str(first_case.get("check_label","CONFERIR")); check.custom_minimum_size=Vector2(195,52); actions.add_child(check)
    var contact=Button.new(); contact.text=str(first_case.get("contact_label","VALIDAR")); contact.custom_minimum_size=Vector2(195,52); actions.add_child(contact)
    var finish=Button.new(); finish.text=str(first_case.get("finish_label","ENCAMINHAR")); finish.custom_minimum_size=Vector2(230,52); actions.add_child(finish)
    var result=label("Selecione as verificações necessárias antes de concluir.",16); result.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(result)
    var investigated := {"check":false,"contact":false}
    check.pressed.connect(func():
        investigated.check=true
        result.text=str(first_case.get("check_result","Conferência realizada."))
    )
    contact.pressed.connect(func():
        investigated.contact=true
        result.text=str(first_case.get("contact_result","Validação realizada."))
    )
    finish.pressed.connect(func():
        if investigated.check and investigated.contact:
            result.text="%s\n+25 XP • +3 REP" % str(first_case.get("success","✅ Demanda encaminhada."))
            career_xp+=25
            reputation+=3
            objective_label.text="🎯 DEMANDA CONCLUÍDA\nRetorne ao responsável do seu setor."
            hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]
            finish.disabled=true
            check.disabled=true
            contact.disabled=true
            save_game()
            on_complete.call()
        else:
            result.text="⚠️ Antes de concluir, faça as duas verificações da ocorrência."
    )
    var close=Button.new(); close.text="FECHAR COMPUTADOR"; close.custom_minimum_size=Vector2(260,48); box.add_child(close)
    close.pressed.connect(func(): panel.queue_free())

func start_office_routine(npc: Node3D, a: Vector3, b: Vector3, seconds: float) -> void:
    var tween=create_tween().set_loops()
    tween.tween_property(npc,"position",b,seconds).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tween.tween_interval(1.2)
    tween.tween_property(npc,"position",a,seconds).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tween.tween_interval(1.2)

func show_end_of_day(ui: CanvasLayer, objective_label: Label, hud_money: Label) -> void:
    var old=ui.get_node_or_null("EndDay")
    if old: return
    var panel=Panel.new(); panel.name="EndDay"; panel.position=Vector2(260,135); panel.size=Vector2(760,470); ui.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(28,24); box.size=Vector2(700,420); panel.add_child(box)
    box.add_child(label("17:30 • EXPEDIENTE CONCLUÍDO",22))
    box.add_child(label("VOCÊ SOBREVIVEU AO PRIMEIRO DIA! 🎉",32))
    box.add_child(label("Primeira demanda concluída em %s\n+25 XP  •  +3 Reputação\nPonto de saída registrado\nPróximo destino: sua kitnet" % area,18))
    city_unlocked=true
    workday_manager.register_tutorial_day(area)
    current_day=workday_manager.get_day_label()
    life_cycle_manager.begin_evening({"week":1,"day_label":"SEGUNDA-FEIRA","next_day":current_day,"next_week":1,"weekly_close":false})
    campaign_manager.reconcile(workday_manager,life_cycle_manager,tutorial_manager,area)
    energy=max(0,energy-15)
    save_game()
    var home=button("🏠 VOLTAR PARA A KITNET"); box.add_child(home)
    home.pressed.connect(func():
        hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]
        show_home_scene()
    )

func personal_week_number() -> int:
    return maxi(1, life_cycle_manager.display_week)

func show_home_panel(ui: CanvasLayer) -> void:
    audio_manager.set_context("home")
    var old=ui.get_node_or_null("HomePanel")
    if old: old.queue_free()
    var p=Panel.new(); p.name="HomePanel"; p.position=Vector2(300,70); p.size=Vector2(680,585); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(24,20); box.size=Vector2(630,540); p.add_child(box)
    box.add_child(label("🏠 SUA KITNET",30))
    var home_time=label("%s • %s  •  ⚡ Energia %d/100" % [life_cycle_manager.time_label,life_cycle_manager.display_day.capitalize(),energy],18); box.add_child(home_time)
    var free_time=label(personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day),15); box.add_child(free_time)
    var opening := "Fim de semana começou. Você decide como aproveitar o tempo livre." if life_cycle_manager.weekend_stage == 1 else "Expediente encerrado. Organize sua noite antes do próximo dia."
    var status=label(opening,16); status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(status)

    var wardrobe=Button.new(); wardrobe.text="👕 GUARDA-ROUPA • trocar roupa"; wardrobe.custom_minimum_size=Vector2(610,43); box.add_child(wardrobe)
    var rest=Button.new(); rest.text="🛏️ DESCANSAR • recuperar energia"; rest.custom_minimum_size=Vector2(610,43); box.add_child(rest)
    var bag=Button.new(); bag.text="🎒 ORGANIZAR MOCHILA • ver itens"; bag.custom_minimum_size=Vector2(610,43); box.add_child(bag)
    var phone=Button.new(); phone.text="📱 CELULAR • mensagens e contatos"; phone.custom_minimum_size=Vector2(610,43); box.add_child(phone)
    var city=Button.new(); city.text="🌆 SAIR PARA A CIDADE • mapa e locais"; city.custom_minimum_size=Vector2(610,43); city.disabled=not city_unlocked; box.add_child(city)
    var furnish=Button.new(); furnish.text="🛋️ MELHORAR KITNET • móveis e conforto"; furnish.custom_minimum_size=Vector2(610,43); box.add_child(furnish)
    var sleep=Button.new(); sleep.text=("🌙 DORMIR • começar o sábado" if life_cycle_manager.weekend_stage == 1 else "🌙 DORMIR • ir para o próximo expediente"); sleep.custom_minimum_size=Vector2(610,48); box.add_child(sleep)

    wardrobe.pressed.connect(func(): show_wardrobe(ui, status))
    rest.pressed.connect(func():
        var action=personal_life_manager.try_action(personal_week_number(),life_cycle_manager.display_day,"rest_home",true,true)
        if not bool(action.get("ok",false)):
            status.text="⏳ %s" % action.get("message","Sem tempo livre restante."); return
        energy=min(100,energy+25)
        life_cycle_manager.register_evening_action("20:10")
        home_time.text="%s • %s  •  ⚡ Energia %d/100" % [life_cycle_manager.time_label,life_cycle_manager.display_day.capitalize(),energy]
        free_time.text=personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day)
        status.text="🛏️ Você descansou um pouco. Energia recuperada."
        rest.disabled=true
        save_game()
    )
    bag.pressed.connect(func(): status.text="🎒 Mochila organizada: crachá LR Global, celular, carteira, chaves e roupa reserva.")
    phone.pressed.connect(func(): show_home_phone(ui, status))
    city.pressed.connect(func():
        city_day=life_cycle_manager.display_day
        city_time=life_cycle_manager.time_label
        show_city_hub(ui, status)
    )
    furnish.pressed.connect(func(): show_home_store(ui, status))
    sleep.pressed.connect(func():
        energy=min(100,energy+35+int(home_comfort/10))
        var transition:String=str(life_cycle_manager.sleep_and_advance(workday_manager.get_day_label(),workday_manager.current_week))
        city_day=life_cycle_manager.display_day
        city_time=life_cycle_manager.time_label
        current_day=workday_manager.get_day_label()
        save_game()
        p.queue_free()
        if transition in ["saturday","sunday"]:
            show_weekend_day(ui)
        else:
            show_morning_panel(ui)
    )

func show_weekend_day(ui:CanvasLayer) -> void:
    audio_manager.set_context("home")
    var old=ui.get_node_or_null("WeekendDay")
    if old: old.queue_free()
    var p=Panel.new(); p.name="WeekendDay"; p.position=Vector2(270,70); p.size=Vector2(740,590); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(26,22); box.size=Vector2(688,545); p.add_child(box)
    box.add_child(label("🏖️ %s • FIM DE SEMANA" % life_cycle_manager.display_day,30))
    var stats=label("%s  •  ⚡ Energia %d/100  •  💵 R$ %d" % [life_cycle_manager.time_label,energy,player_cash],18); box.add_child(stats)
    var free_time=label(personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day),15); box.add_child(free_time)
    var feedback=label("Sem ponto para bater hoje. Você pode descansar, sair ou cuidar da vida pessoal.",16); feedback.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(feedback)
    var rest=button("😴 DESCANSAR EM CASA"); box.add_child(rest)
    rest.pressed.connect(func():
        var action=personal_life_manager.try_action(personal_week_number(),life_cycle_manager.display_day,"weekend_rest",true,true)
        if not bool(action.get("ok",false)):
            feedback.text="⏳ %s" % action.get("message","Sem tempo livre restante."); return
        energy=min(100,energy+25); life_cycle_manager.register_evening_action("14:00"); save_game()
        stats.text="%s  •  ⚡ Energia %d/100  •  💵 R$ %d" % [life_cycle_manager.time_label,energy,player_cash]
        free_time.text=personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day)
        feedback.text="😴 Você descansou sem gastar nada."
        rest.disabled=true
    )
    var city=button("🌆 PASSEAR PELA CIDADE"); box.add_child(city)
    city.pressed.connect(func(): city_day=life_cycle_manager.display_day; city_time=life_cycle_manager.time_label; show_city_hub(ui,feedback))
    var social=button("💬 CONTATOS / RELACIONAMENTOS"); box.add_child(social)
    social.pressed.connect(func(): show_relationships_panel(ui))
    var home=button("🛋️ CUIDAR DA KITNET"); box.add_child(home)
    home.pressed.connect(func(): show_home_store(ui,feedback))
    if life_cycle_manager.display_day == "DOMINGO":
        var prepare=button("📋 PREPARAR A PRÓXIMA SEMANA"); box.add_child(prepare)
        prepare.disabled=personal_life_manager.is_week_prepared(workday_manager.current_week)
        prepare.pressed.connect(func():
            var action=personal_life_manager.try_action(personal_week_number(),life_cycle_manager.display_day,"prepare_week",true,true)
            if not bool(action.get("ok",false)):
                feedback.text="⏳ %s" % action.get("message","Sem tempo livre restante."); return
            personal_life_manager.prepare_week(workday_manager.current_week)
            free_time.text=personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day)
            feedback.text="📋 Roupa, mochila e prioridades organizadas. Segunda começa com bônus de disposição."
            prepare.disabled=true
            save_game()
        )
    var next=button("🌙 ENCERRAR %s" % life_cycle_manager.display_day); box.add_child(next)
    next.pressed.connect(func():
        energy=min(100,energy+30)
        var transition:String=str(life_cycle_manager.sleep_and_advance(workday_manager.get_day_label(),workday_manager.current_week))
        city_day=life_cycle_manager.display_day; city_time=life_cycle_manager.time_label; save_game(); p.queue_free()
        if transition in ["saturday","sunday"]: show_weekend_day(ui)
        else: show_morning_panel(ui)
    )

func show_morning_panel(ui:CanvasLayer) -> void:
    audio_manager.set_context("home")
    var old=ui.get_node_or_null("MorningPanel")
    if old: old.queue_free()
    var p=Panel.new(); p.name="MorningPanel"; p.position=Vector2(250,90); p.size=Vector2(780,550); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(28,22); box.size=Vector2(720,500); p.add_child(box)
    var day_name:String=str(workday_manager.get_day_label())
    var cycle_milestone:Dictionary=campaign_manager.check_first_cycle(workday_manager,life_cycle_manager)
    if not cycle_milestone.is_empty():
        clt_coins+=int(cycle_milestone.get("clt_coins",0))
        career_xp+=int(cycle_milestone.get("xp",0))
        reputation+=int(cycle_milestone.get("reputation",0))
        save_game()
    box.add_child(label("☀️ %s" % day_name,34))
    if not cycle_milestone.is_empty():
        box.add_child(label("🏆 %s\n%s\n+%d CLT Coins • +%d XP • +%d REP" % [cycle_milestone.get("title","MARCO DA CAMPANHA"),cycle_milestone.get("message",""),cycle_milestone.get("clt_coins",0),cycle_milestone.get("xp",0),cycle_milestone.get("reputation",0)],15))
    box.add_child(label("06:30 • KITNET  •  ⚡ Energia %d/100" % energy,19))
    box.add_child(label("SEMANA %d • Seu próximo expediente na LR Global começa em breve." % workday_manager.current_week,18))
    if personal_life_manager.is_week_prepared(workday_manager.current_week):
        box.add_child(label("📋 Semana preparada • +10 de disposição ao sair para o trabalho.",16))
    var mentor:String=str(tutorial_manager.get_mentor_name(area))
    var task=label("📱 %s:\n‘Bom dia! Hoje seguimos com as prioridades de %s. Te vejo às 07:45.’" % [mentor,area],17); task.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(task)
    var prepare=Button.new(); prepare.text="🪥 SE PREPARAR PARA O TRABALHO"; prepare.custom_minimum_size=Vector2(700,54); box.add_child(prepare)
    var leave=Button.new(); leave.text="🚌 IR PARA LR GLOBAL — TRANSPORTES"; leave.custom_minimum_size=Vector2(700,54); leave.disabled=true; box.add_child(leave)
    prepare.pressed.connect(func():
        prepare.disabled=true; leave.disabled=false; task.text="✅ 07:05 • Pronto para sair.\nCrachá, celular e carteira estão na mochila."
    )
    leave.pressed.connect(func():
        if personal_life_manager.consume_week_preparation(workday_manager.current_week):
            energy=min(100,energy+10)
        life_cycle_manager.begin_workday(day_name,workday_manager.current_week)
        current_day=day_name; work_clock="07:45"; save_game(); show_gameplay()
    )

func show_wardrobe(ui: CanvasLayer, status: Label) -> void:
    var old=ui.get_node_or_null("Wardrobe")
    if old: old.queue_free()
    var p=Panel.new(); p.name="Wardrobe"; p.position=Vector2(390,150); p.size=Vector2(500,410); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(22,18); box.size=Vector2(455,370); p.add_child(box)
    box.add_child(label("👕 GUARDA-ROUPA",27))
    box.add_child(label("Roupas iniciais gratuitas",15))
    var selected=label("Roupa atual: Camiseta + Jeans",16); box.add_child(selected)
    for outfit in ["Camiseta + Jeans","Polo + Calça","Camisa Social","Casual"]:
        var b=Button.new(); b.text=outfit; b.custom_minimum_size=Vector2(450,46); box.add_child(b)
        b.pressed.connect(func():
            selected.text="Roupa atual: " + outfit
            status.text="👕 Visual alterado para: " + outfit + "."
        )
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(450,44); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func show_home_phone(ui: CanvasLayer, status: Label) -> void:
    var old=ui.get_node_or_null("HomePhone")
    if old: old.queue_free()
    var p=Panel.new(); p.name="HomePhone"; p.position=Vector2(380,145); p.size=Vector2(520,430); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(22,18); box.size=Vector2(475,390); p.add_child(box)
    box.add_child(label("📱 CELULAR",28))
    box.add_child(label("Mensagens • %s" % life_cycle_manager.display_day.capitalize(),16))
    var mentor=tutorial_manager.get_mentor_name(area)
    if life_cycle_manager.is_weekend() or life_cycle_manager.weekend_stage == 1:
        box.add_child(label("RH LR Global\n‘Bom descanso. O próximo expediente começa %s às 07:45.’" % workday_manager.get_day_label().capitalize(),16))
        box.add_child(label("%s\n‘Aproveita o fim de semana. Segunda a gente continua.’" % mentor,16))
    else:
        box.add_child(label("RH LR Global\n‘Expediente encerrado. Amanhã seu ponto abre às 07:45.’",16))
        box.add_child(label("%s\n‘Boa noite! Amanhã seguimos com as prioridades de %s.’" % [mentor,area],16))
    var reply=Button.new(); reply.text="RESPONDER: 👍 Combinado!"; reply.custom_minimum_size=Vector2(470,48); box.add_child(reply)
    reply.pressed.connect(func(): status.text="📱 Mensagem enviada para %s." % mentor)
    var close=Button.new(); close.text="FECHAR CELULAR"; close.custom_minimum_size=Vector2(470,44); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func show_tuesday_morning(ui: CanvasLayer) -> void:
    # Compatibilidade com saves/protótipos antigos: usa o novo fluxo genérico de manhã.
    show_morning_panel(ui)

func show_tuesday_briefing(ui: CanvasLayer) -> void:
    var p=Panel.new(); p.name="TuesdayBriefing"; p.position=Vector2(250,105); p.size=Vector2(780,520); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(28,22); box.size=Vector2(720,470); p.add_child(box)
    box.add_child(label("LR GLOBAL — TRANSPORTES",30))
    box.add_child(label("TERÇA-FEIRA • 07:42",18))
    box.add_child(label("DIA 2 — CHECKLIST DA FROTA",24))
    var info=label("O Especialista deixou três veículos no pátio para conferência. Cada inspeção exige verificar os itens antes de liberar ou encaminhar o veículo.",17); info.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(info)
    box.add_child(label("• %s — retorno da manutenção\n• %s — inspeção preventiva\n• %s — checklist de saída" % [FLEET_CHECKLIST_RETURN,FLEET_CHECKLIST_PREVENTIVE,FLEET_CHECKLIST_EXIT],17))
    var start=Button.new(); start.text="IR PARA O PÁTIO E INICIAR CHECKLIST"; start.custom_minimum_size=Vector2(700,54); box.add_child(start)
    start.pressed.connect(func():
        p.queue_free()
        show_vehicle_checklist(ui)
    )

func show_vehicle_checklist(ui: CanvasLayer) -> void:
    var old=ui.get_node_or_null("VehicleChecklist")
    if old: old.queue_free()
    var p=Panel.new(); p.name="VehicleChecklist"; p.position=Vector2(180,92); p.size=Vector2(920,545); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(26,20); box.size=Vector2(865,500); p.add_child(box)
    box.add_child(label("🚛 PÁTIO • CHECKLIST DE VEÍCULOS",28))
    var progress=label("TERÇA • 07:45     Progresso: 0/3",17); box.add_child(progress)
    var instruction=label("Selecione um código de frota e confira pneus, iluminação, vazamentos e itens de segurança.",16); instruction.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(instruction)
    var result=label("Nenhum veículo inspecionado.",16); result.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(result)
    var completed := {FLEET_CHECKLIST_RETURN:false,FLEET_CHECKLIST_PREVENTIVE:false,FLEET_CHECKLIST_EXIT:false}
    var count := 0
    var finish=Button.new(); finish.text="FINALIZAR CHECKLIST"; finish.custom_minimum_size=Vector2(860,48); finish.disabled=true

    var vehicles=[
        {"plate":FLEET_CHECKLIST_RETURN,"desc":"Retorno da manutenção","finding":"✅ Sem anomalias. Serviço anterior conferido.","decision":"LIBERADO"},
        {"plate":FLEET_CHECKLIST_PREVENTIVE,"desc":"Inspeção preventiva","finding":"⚠️ Lanterna delimitadora direita não acende.","decision":"MANUTENÇÃO"},
        {"plate":FLEET_CHECKLIST_EXIT,"desc":"Checklist de saída","finding":"⚠️ Pneu traseiro com desgaste acima do padrão visual.","decision":"BLOQUEADO"}
    ]
    for v in vehicles:
        var b=Button.new(); b.text="FROTA %s  •  %s" % [v.plate,v.desc]; b.custom_minimum_size=Vector2(860,50); box.add_child(b)
        b.pressed.connect(func():
            if completed[v.plate]:
                result.text="%s já foi conferido. Status: %s." % [v.plate,v.decision]
                return
            show_single_vehicle_inspection(ui, v, func():
                if completed[v.plate]: return
                completed[v.plate]=true
                count+=1
                b.disabled=true
                progress.text="TERÇA • %s     Progresso: %d/3" % ["08:05" if count==1 else ("08:22" if count==2 else "08:40"),count]
                result.text="%s concluído • %s\n%s" % [v.plate,v.decision,v.finding]
                if count==3:
                    finish.disabled=false
                    instruction.text="✅ Todos os veículos foram conferidos. Finalize o checklist para enviar o relatório ao Especialista."
            )
        )
    box.add_child(finish)
    finish.pressed.connect(func():
        finish.disabled=true
        result.text="✅ CHECKLIST ENVIADO • 08:45\n%s liberado • %s encaminhado à manutenção • %s bloqueado para revisão.\n+35 XP • +5 Reputação     XP 80/100 • REP 58" % [FLEET_CHECKLIST_RETURN,FLEET_CHECKLIST_PREVENTIVE,FLEET_CHECKLIST_EXIT]
        instruction.text="🎯 Terça-feira concluída. O acompanhamento das pendências ficou registrado para a oficina."
        var next_day=Button.new(); next_day.text="🌙 ENCERRAR TERÇA E AVANÇAR PARA QUARTA"; next_day.custom_minimum_size=Vector2(860,48); box.add_child(next_day)
        next_day.pressed.connect(func():
            p.queue_free()
            show_wednesday_briefing(ui)
        )
    )
    var close=Button.new(); close.text="VOLTAR AO ESCRITÓRIO"; close.custom_minimum_size=Vector2(860,44); box.add_child(close)
    close.pressed.connect(func():
        if finish.disabled and count==3:
            p.queue_free()
        elif count<3:
            result.text="⚠️ Conclua os três veículos antes de voltar ao escritório."
        else:
            result.text="⚠️ Envie o checklist antes de voltar ao escritório."
    )

func show_single_vehicle_inspection(ui: CanvasLayer, vehicle: Dictionary, on_done: Callable) -> void:
    var old=ui.get_node_or_null("SingleInspection")
    if old: old.queue_free()
    var p=Panel.new(); p.name="SingleInspection"; p.position=Vector2(315,130); p.size=Vector2(650,470); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(24,20); box.size=Vector2(600,425); p.add_child(box)
    box.add_child(label("🔎 INSPEÇÃO • " + vehicle.plate,26))
    box.add_child(label(vehicle.desc,16))
    var status=label("Itens conferidos: 0/4",16); box.add_child(status)
    var finding=label("Faça a inspeção antes de registrar a decisão.",16); finding.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(finding)
    var checked := {"Pneus":false,"Iluminação":false,"Vazamentos":false,"Segurança":false}
    var total := 0
    for item in ["Pneus","Iluminação","Vazamentos","Segurança"]:
        var b=Button.new(); b.text="CONFERIR • " + item; b.custom_minimum_size=Vector2(595,44); box.add_child(b)
        b.pressed.connect(func():
            if checked[item]: return
            checked[item]=true; total+=1; b.disabled=true
            status.text="Itens conferidos: %d/4" % total
            if total==4: finding.text=vehicle.finding
        )
    var register=Button.new(); register.text="REGISTRAR DECISÃO"; register.custom_minimum_size=Vector2(595,48); box.add_child(register)
    register.pressed.connect(func():
        if total<4:
            finding.text="⚠️ Confira os quatro itens antes de registrar o veículo."
        else:
            register.disabled=true
            finding.text=vehicle.finding + "\nDecisão registrada: " + vehicle.decision
            on_done.call()
    )
    var close=Button.new(); close.text="FECHAR INSPEÇÃO"; close.custom_minimum_size=Vector2(595,42); box.add_child(close)
    close.pressed.connect(func():
        if register.disabled: p.queue_free()
        else: finding.text="⚠️ Registre a decisão antes de fechar a inspeção."
    )



func show_wednesday_briefing(ui: CanvasLayer) -> void:
    var old=ui.get_node_or_null("WednesdayBriefing")
    if old: old.queue_free()
    var p=Panel.new(); p.name="WednesdayBriefing"; p.position=Vector2(230,95); p.size=Vector2(820,540); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(28,22); box.size=Vector2(760,490); p.add_child(box)
    box.add_child(label("☀️ QUARTA-FEIRA • LR GLOBAL",30))
    box.add_child(label("07:45 • Gestão de Frotas",18))
    var msg=label("O dia começa com uma ocorrência urgente: um motorista relata que o freio está puxando para a esquerda e uma roda está aquecendo.",17); msg.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(msg)
    box.add_child(label("XP atual: 80/100  •  Reputação: 58",17))
    var loud=label("📢 Ao fundo: ‘GENTE, QUEM PEGOU A CHAVE DESSE CAVALO?!’\nO Colega da Voz Alta já começou o expediente no volume máximo.",15); loud.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(loud)
    var start=Button.new(); start.text="🚨 ATENDER OCORRÊNCIA URGENTE"; start.custom_minimum_size=Vector2(750,54); box.add_child(start)
    start.pressed.connect(func(): p.queue_free(); show_wednesday_incident(ui))

func show_wednesday_incident(ui: CanvasLayer) -> void:
    var p=Panel.new(); p.name="WednesdayIncident"; p.position=Vector2(190,82); p.size=Vector2(900,565); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(26,20); box.size=Vector2(845,520); p.add_child(box)
    box.add_child(label("🚛 OCORRÊNCIA #0007 • FREIO / AQUECIMENTO",27))
    box.add_child(label("Frota: %s  •  Prioridade: IMEDIATA" % FLEET_URGENT_BRAKE,16))
    var result=label("Motorista: ‘O caminhão está puxando para a esquerda e a roda está muito quente.’",16); result.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(result)
    var state={"stop":false,"driver":false,"workshop":false}
    var stop=Button.new(); stop.text="1 • ORIENTAR PARADA SEGURA DO VEÍCULO"; stop.custom_minimum_size=Vector2(840,48); box.add_child(stop)
    var call=Button.new(); call.text="2 • CONFIRMAR SINTOMAS COM MOTORISTA"; call.custom_minimum_size=Vector2(840,48); box.add_child(call)
    var workshop=Button.new(); workshop.text="3 • ACIONAR OFICINA / MANUTENÇÃO IMEDIATA"; workshop.custom_minimum_size=Vector2(840,48); box.add_child(workshop)
    var finish=Button.new(); finish.text="CONCLUIR OCORRÊNCIA"; finish.custom_minimum_size=Vector2(840,50); finish.disabled=true; box.add_child(finish)
    stop.pressed.connect(func(): state.stop=true; stop.disabled=true; result.text="✅ Motorista orientado a parar em local seguro e não seguir viagem até avaliação.")
    call.pressed.connect(func():
        if not state.stop: result.text="⚠️ Primeiro garanta a parada segura do veículo."; return
        state.driver=true; call.disabled=true; result.text="📞 Confirmado: freio puxando à esquerda, aquecimento anormal da roda e cheiro forte próximo ao conjunto de freio."
    )
    workshop.pressed.connect(func():
        if not state.driver: result.text="⚠️ Confirme os sintomas com o motorista antes de acionar a oficina."; return
        state.workshop=true; workshop.disabled=true; finish.disabled=false; result.text="🔧 Oficina acionada. Veículo bloqueado operacionalmente até inspeção do sistema de freio."
    )
    finish.pressed.connect(func():
        finish.disabled=true
        career_xp += 30
        reputation += 6
        save_game()
        result.text="✅ OCORRÊNCIA CONTROLADA • +30 XP • +6 REP\nXP %d • REP %d\nSeu desempenho foi registrado no histórico profissional." % [career_xp,reputation]
        var eval=Button.new(); eval.text="📈 VER PROGRESSO PARA ANALISTA JR"; eval.custom_minimum_size=Vector2(840,54); box.add_child(eval)
        eval.pressed.connect(func(): p.queue_free(); show_career_panel(ui))
    )

func show_promotion_evaluation(ui: CanvasLayer) -> void:
    var old=ui.get_node_or_null("PromotionEvaluation")
    if old: old.queue_free()
    var p=Panel.new(); p.name="PromotionEvaluation"; p.position=Vector2(200,70); p.size=Vector2(880,590); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(26,20); box.size=Vector2(825,545); p.add_child(box)
    box.add_child(label("⭐ AVALIAÇÃO DE PROMOÇÃO",29))
    box.add_child(label("Assistente → Analista Jr • %s" % area,20))

    if not career_manager.evaluation_available(career_role,career_xp,reputation,workday_manager):
        var wait=label(career_manager.get_status_text(career_role,career_xp,reputation,workday_manager),17); wait.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(wait)
        var close_wait=button("VOLTAR À CARREIRA"); box.add_child(close_wait); close_wait.pressed.connect(func(): p.queue_free(); show_career_panel(ui))
        return

    var evaluation:Dictionary=career_manager.get_evaluation(area)
    box.add_child(label(str(evaluation.get("title","Situação de avaliação")),21))
    var info=label(str(evaluation.get("intro","Organize a resposta.")),16); info.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(info)
    var feedback=label("Escolha exatamente três ações para formar sua resposta.",16); feedback.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(feedback)
    var selected_ids:Array=[]
    var conclude=Button.new(); conclude.text="ENVIAR DECISÃO AO SUPERVISOR"; conclude.custom_minimum_size=Vector2(820,50); conclude.disabled=true
    for choice in evaluation.get("choices",[]):
        var choice_data:Dictionary=choice
        var choice_id:=str(choice_data.get("id",""))
        var b=Button.new(); b.text=str(choice_data.get("text","Ação")); b.toggle_mode=true; b.custom_minimum_size=Vector2(820,42); box.add_child(b)
        b.toggled.connect(_on_promotion_choice_toggled.bind(choice_id,selected_ids,conclude,feedback))
    box.add_child(conclude)
    conclude.pressed.connect(func():
        var result:Dictionary=career_manager.evaluate(selected_ids,area,workday_manager)
        save_game()
        conclude.disabled=true
        if bool(result.get("passed",false)):
            feedback.text="✅ AVALIAÇÃO APROVADA!\n%s" % result.get("feedback","")
            var promote=Button.new(); promote.text="🎉 RECEBER PROMOÇÃO"; promote.custom_minimum_size=Vector2(820,52); box.add_child(promote)
            promote.pressed.connect(func(): p.queue_free(); show_promotion_scene(ui))
        else:
            feedback.text="❌ AVALIAÇÃO NÃO APROVADA\n%s" % result.get("feedback","")
            var back=Button.new(); back.text="VOLTAR AO EXPEDIENTE"; back.custom_minimum_size=Vector2(820,48); box.add_child(back)
            back.pressed.connect(func(): p.queue_free())
    )

func _on_promotion_choice_toggled(on:bool, choice_id:String, selected_ids:Array, conclude:Button, feedback:Label) -> void:
    if on and not selected_ids.has(choice_id):
        selected_ids.append(choice_id)
    elif not on:
        selected_ids.erase(choice_id)
    conclude.disabled=selected_ids.size()!=3
    feedback.text="Ações selecionadas: %d/3" % selected_ids.size()

func show_promotion_scene(ui: CanvasLayer) -> void:
    var promotion:Dictionary=career_manager.promote_to_junior(career_role)
    if promotion.is_empty():
        show_career_panel(ui)
        return
    career_role=str(promotion.get("role","Analista Jr"))
    monthly_salary=max(monthly_salary,int(promotion.get("salary",monthly_salary)))
    save_game()
    audio_manager.play_stinger("promotion")
    var p=Panel.new(); p.name="PromotionScene"; p.position=Vector2(255,105); p.size=Vector2(770,500); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(30,25); box.size=Vector2(710,445); p.add_child(box)
    box.add_child(label("🎉 PROMOÇÃO!",42))
    box.add_child(label("ASSISTENTE  →  ANALISTA JR",28))
    box.add_child(label("%s • LR Global — Transportes" % area,18))
    box.add_child(label("⭐ XP %d  •  🏅 Reputação %d\n💰 Novo salário-base: R$ %d\n🔓 Demandas de maior autonomia liberadas no próximo expediente." % [career_xp,reputation,monthly_salary],17))
    var director=label("📱 Diretor Lucas: ‘Parabéns. Você mostrou que sabe priorizar, comunicar e resolver. Agora a cobrança aumenta.’",16); director.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(director)
    var continue_btn=Button.new(); continue_btn.text="CONTINUAR CARREIRA COMO ANALISTA JR"; continue_btn.custom_minimum_size=Vector2(700,54); box.add_child(continue_btn)
    continue_btn.pressed.connect(func():
        p.queue_free()
        var summary=Panel.new(); summary.position=Vector2(290,145); summary.size=Vector2(700,390); ui.add_child(summary)
        var vb=VBoxContainer.new(); vb.position=Vector2(24,20); summary.add_child(vb)
        vb.add_child(label("NOVO NÍVEL DE CARREIRA",24))
        vb.add_child(label("Cargo atual: ANALISTA JR DE %s" % area.to_upper(),21))
        vb.add_child(label("A partir do próximo expediente, uma demanda de autonomia será adicionada à rotina da sua área.\nProjetos de Melhoria e ocorrências continuam influenciando seu histórico profissional.",17))
        vb.add_child(label("Alpha v%s • preparação para o primeiro APK" % APP_VERSION,15))
        var close=button("VOLTAR AO JOGO"); vb.add_child(close); close.pressed.connect(func(): summary.queue_free())
    )


func show_tower_story_mission(ui:CanvasLayer, hud_money:Label, objective_label:Label) -> void:
    var old=ui.get_node_or_null("TowerStory")
    if old: old.queue_free(); return
    tower_visits+=1
    var p=Panel.new(); p.name="TowerStory"; p.position=Vector2(180,70); p.size=Vector2(920,590); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(26,20); box.size=Vector2(865,545); p.add_child(box)
    box.add_child(label("🏙️ MISSÃO DE HISTÓRIA • TORRE DE CONTROLE",29))
    var intro=label("A Coordenadora da Torre chamou a Gestão de Frotas. Três cargas estão com risco de atraso e ela precisa de uma posição antes da reunião operacional.",16); intro.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(intro)
    box.add_child(label("Coordenadora: ‘Preciso da situação real. Não quero chute. É PRA ONTEM!’",18))
    var status=label("Analise as três ocorrências e escolha a ação mais segura.",16); box.add_child(status)
    var solved=0
    var cases=[
        ["🚛 CARGA 01 • veículo perdeu força na subida","Acionar manutenção e informar nova previsão",true],
        ["📄 CARGA 02 • documento ainda não liberado","Validar documento antes de autorizar saída",true],
        ["⏱️ CARGA 03 • motorista ainda não chegou","Confirmar motorista e reprogramar janela",true]
    ]
    for c in cases:
        var b=Button.new(); b.text="%s\n→ %s" % [c[0],c[1]]; b.custom_minimum_size=Vector2(855,58); box.add_child(b)
        b.pressed.connect(func():
            if b.disabled: return
            b.disabled=true; solved+=1; status.text="✅ %d/3 ocorrências tratadas." % solved
            if solved>=3:
                status.text="✅ TORRE ATUALIZADA • todas as ocorrências possuem ação e previsão."
        )
    var finish=Button.new(); finish.text="📊 ENVIAR POSIÇÃO PARA A COORDENADORA"; finish.custom_minimum_size=Vector2(855,50); box.add_child(finish)
    finish.pressed.connect(func():
        if solved<3:
            status.text="⚠️ Ainda existem ocorrências sem tratamento."; return
        if not tower_mission_complete:
            tower_mission_complete=true; career_xp+=30; reputation+=5; clt_coins+=50
            status.text="🎉 MISSÃO CONCLUÍDA! +30 XP • +5 REP • +50 CLT Coins\nCoordenadora: ‘Agora sim. Era essa posição que eu precisava.’"
        else:
            career_xp+=5; reputation+=1; status.text="✅ Nova visita operacional concluída. +5 XP • +1 REP"
        objective_label.text="Objetivo: retornar à LR Global — Transportes com a posição da Torre."
        hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]
        finish.disabled=true; save_game()
    )
    var easter=Button.new(); easter.text="💼 CONVERSAR COM A COORDENADORA DA TORRE"; easter.custom_minimum_size=Vector2(855,46); box.add_child(easter)
    easter.pressed.connect(func(): discover_easter_egg(ui,"torre","Coordenadora da Torre","É PRA ONTEM!",75,hud_money,"💼 Cobrança, prazo e postura executiva. Tudo ao mesmo tempo."))
    var close=Button.new(); close.text="VOLTAR AO EXPEDIENTE"; close.custom_minimum_size=Vector2(855,44); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func show_north_unit(ui: CanvasLayer, hud_money: Label) -> void:
    var old=ui.get_node_or_null("NorthUnit")
    if old: old.queue_free()
    var p=Panel.new(); p.name="NorthUnit"; p.position=Vector2(145,70); p.size=Vector2(990,590); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(26,20); box.size=Vector2(935,545); p.add_child(box)
    box.add_child(label("🏢 LR GLOBAL — UNIDADE NORTE",30))
    box.add_child(label("Visita operacional • Personagens especiais podem aparecer durante o expediente",16))
    var scene=label("Duas colegas muito parecidas trabalham lado a lado. Elas são amigas — não irmãs — e resolvem uma divergência operacional enquanto discutem o treino do dia.",16); scene.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(scene)
    var dream=label("💭 DEVANEIO: por alguns segundos, a planilha vira mentalmente uma academia cheia de halteres.\nColega 1: ‘Hoje é posterior.’\nColega 2: ‘ARRASOU!’",17); dream.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(dream)
    var a=Button.new(); a.text="👯 INTERAGIR COM A PRIMEIRA AMIGA"; a.custom_minimum_size=Vector2(925,48); box.add_child(a)
    var b=Button.new(); b.text="👯 INTERAGIR COM A SEGUNDA AMIGA"; b.custom_minimum_size=Vector2(925,48); box.add_child(b)
    var gaucha=Button.new(); gaucha.text="🧉 FALAR COM A COORDENADORA GAÚCHA"; gaucha.custom_minimum_size=Vector2(925,48); box.add_child(gaucha)
    var rave=Button.new(); rave.text="🎧 OBSERVAR O LÍDER DA RAVE TRABALHANDO"; rave.custom_minimum_size=Vector2(925,48); box.add_child(rave)
    var status=label("Explore os encontros especiais da Unidade Norte.",15); box.add_child(status)
    a.pressed.connect(func(): discover_easter_egg(ui,"gemea_a","Amiga Fitness A","ARRASOU!",50,hud_money,"💪 Resolve processo difícil pensando no treino de perna."))
    b.pressed.connect(func():
        discover_easter_egg(ui,"gemea_b","Amiga Fitness B","ARRASOU!",50,hud_money,"💪 Parece irmã gêmea da amiga, mas elas juram que não são irmãs.")
        if easter_eggs.has("gemea_a"): show_twins_duo(ui,hud_money)
    )
    gaucha.pressed.connect(func(): discover_easter_egg(ui,"gaucha","Coordenadora Gaúcha","CHIMA & 5K",75,hud_money,"🧉 ‘Bah... quero um chima.’ 🏃 Já está pensando no próximo campeonato de corrida."))
    rave.pressed.connect(func():
        status.text="💭 O Líder da Rave olha o indicador... e por alguns segundos imagina luzes, DJ e festival. Sexta-feira ainda está longe."
        if not easter_eggs.has("rave"): discover_easter_egg(ui,"rave","Líder da Rave","SEXTOU!",75,hud_money,"🎧 Corpo no escritório. Mente no festival.")
    )
    var tower=Button.new(); tower.text="🏙️ SEGUIR PARA A TORRE DE CONTROLE"; tower.custom_minimum_size=Vector2(925,48); box.add_child(tower)
    tower.pressed.connect(func(): p.queue_free(); show_control_tower(ui,hud_money))
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(925,44); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func show_twins_duo(ui:CanvasLayer, hud_money:Label) -> void:
    if easter_eggs.has("dupla_gemeas"): return
    easter_eggs["dupla_gemeas"]={"name":"As Gêmeas que Não São Gêmeas","achievement":"ARRASOU EM DOBRO","reward":100,"skin":"Conjunto Fitness ARRASOU!"}
    unlocked_skins["Conjunto Fitness ARRASOU!"]=true
    clt_coins+=100
    save_game()
    hud_money.text="R$ 1.250     🪙 %d CLT Coins     ⭐ XP 20/100     REP 50" % clt_coins
    var panel=Panel.new(); panel.name="TwinsEggPopup"; panel.position=Vector2(325,145); panel.size=Vector2(630,430); ui.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(26,22); box.size=Vector2(578,380); panel.add_child(box)
    box.add_child(label("🥚 EASTER EGG DUPLO ENCONTRADO!",28))
    box.add_child(label("AS GÊMEAS QUE NÃO SÃO GÊMEAS",23))
    box.add_child(label("👯 ‘Não, a gente não é irmã.’\n💪 ‘Hoje é treino de perna.’\n💬 ‘ARRASOU!’",17))
    box.add_child(label("🏆 ARRASOU EM DOBRO",20)); box.add_child(label("🪙 +100 CLT Coins",20)); box.add_child(label("👕 Conjunto Fitness ARRASOU!",20))
    var close=Button.new(); close.text="COLETAR RECOMPENSA"; close.custom_minimum_size=Vector2(570,50); box.add_child(close); close.pressed.connect(func(): panel.queue_free())

func show_control_tower(ui:CanvasLayer, hud_money:Label) -> void:
    var p=Panel.new(); p.name="ControlTower"; p.position=Vector2(185,90); p.size=Vector2(910,550); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(26,22); box.size=Vector2(855,500); p.add_child(box)
    box.add_child(label("🏙️ LR GLOBAL — TORRE DE CONTROLE",29))
    var intro=label("No centro da operação, uma coordenadora loira acompanha prazos e atualizações em várias telas ao mesmo tempo.",16); intro.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(intro)
    var quote=label("Coordenadora: ‘Pessoal, preciso dessa atualização AGORA. É pra ontem!’",18); box.add_child(quote)
    var meet=Button.new(); meet.text="💼 INTERAGIR COM A COORDENADORA DA TORRE"; meet.custom_minimum_size=Vector2(850,52); box.add_child(meet)
    meet.pressed.connect(func(): discover_easter_egg(ui,"torre","Coordenadora da Torre","É PRA ONTEM!",75,hud_money,"💼 Cobrança, prazo e postura executiva. Tudo ao mesmo tempo."))
    box.add_child(label("🎁 Recompensa especial: Skin Executiva da Torre — exclusiva de descoberta.",16))
    var close=Button.new(); close.text="ENCERRAR VISITA"; close.custom_minimum_size=Vector2(850,48); box.add_child(close); close.pressed.connect(func(): p.queue_free())

# v0.13 — expansão de vida/carreira e loja cosmética
func show_clt_shop(ui: CanvasLayer, hud_money: Label) -> void:
    var old=ui.get_node_or_null("CLTShop")
    if old: old.queue_free(); return
    var p=Panel.new(); p.name="CLTShop"; p.position=Vector2(250,90); p.size=Vector2(790,545); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(25,20); box.size=Vector2(740,500); p.add_child(box)
    box.add_child(label("🛒 LOJA CLT",30)); box.add_child(label("Cosméticos não dão vantagem de carreira.",15))
    var status=label("Saldo: 🪙 %d CLT Coins" % clt_coins,18); box.add_child(status)
    for item in _shop_catalog():
        var item_name:=str(item[0]); var cost:=int(item[1])
        var b=Button.new(); b.text="%s  •  🪙 %d" % [item_name,cost]; b.custom_minimum_size=Vector2(730,48); b.disabled=unlocked_skins.has(item_name); box.add_child(b)
        b.pressed.connect(func(): _buy_shop_item(item_name,cost,status,hud_money); b.disabled=unlocked_skins.has(item_name))
    var wardrobe=Button.new(); wardrobe.text="👕 VER MINHAS ROUPAS / SKINS"; wardrobe.custom_minimum_size=Vector2(730,48); box.add_child(wardrobe)
    wardrobe.pressed.connect(func():
        var names=[]
        for k in unlocked_skins.keys(): names.append(str(k))
        status.text="👕 Inventário: " + (", ".join(names) if names.size()>0 else "somente roupas iniciais")
    )
    var close=Button.new(); close.text="FECHAR LOJA"; close.custom_minimum_size=Vector2(730,46); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func show_career_panel(ui:CanvasLayer) -> void:
    var old=ui.get_node_or_null("CareerPanel")
    if old: old.queue_free(); return
    var p=Panel.new(); p.name="CareerPanel"; p.position=Vector2(290,90); p.size=Vector2(700,535); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(24,20); box.size=Vector2(650,490); p.add_child(box)
    box.add_child(label("📈 CARREIRA LR GLOBAL",28))
    box.add_child(label("%s • %s de %s" % [player_name,career_role,area],19))
    box.add_child(label("⭐ XP %d     🏅 Reputação %d     💰 R$ %d/mês" % [career_xp,reputation,monthly_salary],18))
    box.add_child(label("TRILHA DE CARREIRA",15))
    box.add_child(label("Assistente → Analista Jr → Analista Pleno → Analista Sênior",17))
    box.add_child(label("Depois: Especialista  OU  Líder → Supervisor → Coordenador",17))
    var status=label(career_manager.get_status_text(career_role,career_xp,reputation,workday_manager),16); status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(status)
    if career_role=="Assistente":
        if career_manager.evaluation_passed:
            var receive=button("🎉 RECEBER PROMOÇÃO APROVADA"); box.add_child(receive); receive.pressed.connect(func(): p.queue_free(); show_promotion_scene(ui))
        else:
            var eval=button("⭐ INICIAR AVALIAÇÃO PARA ANALISTA JR"); eval.disabled=not career_manager.evaluation_available(career_role,career_xp,reputation,workday_manager); box.add_child(eval)
            eval.pressed.connect(func(): p.queue_free(); show_promotion_evaluation(ui))
    else:
        box.add_child(label("🔓 Demandas de autonomia estão ativas no Gerenciador de Expediente.",16))
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(645,48); box.add_child(close); close.pressed.connect(func(): p.queue_free())

# v0.14 — finanças pessoais, holerite e ciclo de pagamento
func show_finance_panel(ui:CanvasLayer, hud_money:Label) -> void:
    var old=ui.get_node_or_null("FinancePanel")
    if old: old.queue_free(); return
    var p=Panel.new(); p.name="FinancePanel"; p.position=Vector2(285,100); p.size=Vector2(710,520); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(24,20); box.size=Vector2(660,475); p.add_child(box)
    box.add_child(label("💰 MINHAS FINANÇAS",29))
    var balance=label("Conta: R$ %d   •   Benefícios: R$ %d" % [player_cash,benefits_balance],19); box.add_child(balance)
    box.add_child(label("HOLERITE LR GLOBAL",16))
    box.add_child(label("Salário-base: R$ %d\nDescontos estimados: R$ 310\nLíquido no próximo pagamento: R$ %d" % [monthly_salary,monthly_salary-310],17))
    var bills=label("Contas da kitnet pendentes: R$ %d" % bills_due,17); box.add_child(bills)
    var pay=Button.new(); pay.text="🏠 PAGAR CONTAS DA KITNET"; pay.custom_minimum_size=Vector2(650,50); box.add_child(pay)
    pay.pressed.connect(func():
        if bills_due<=0:
            bills.text="✅ Contas da kitnet já estão pagas."; return
        if player_cash<bills_due:
            bills.text="⚠️ Saldo insuficiente para pagar todas as contas."; return
        player_cash-=bills_due; bills_due=0; save_game()
        balance.text="Conta: R$ %d   •   Benefícios: R$ %d" % [player_cash,benefits_balance]
        bills.text="✅ Aluguel, energia e internet pagos."
        hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]
    )
    var payday=Button.new(); payday.text="📅 VER FECHAMENTO DA SEMANA"; payday.custom_minimum_size=Vector2(650,50); box.add_child(payday)
    payday.pressed.connect(func(): show_friday_summary(ui,hud_money); p.queue_free())
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(650,46); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func show_friday_summary(ui:CanvasLayer, hud_money:Label, week_number:int=0) -> void:
    var old=ui.get_node_or_null("FridaySummary")
    if old: old.queue_free(); return
    var payable_week:=week_number
    if payable_week <= 0:
        if bool(life_cycle_manager.last_summary.get("weekly_close",false)):
            payable_week=int(life_cycle_manager.last_summary.get("week",workday_manager.current_week))
        else:
            payable_week=workday_manager.current_week
    var p=Panel.new(); p.name="FridaySummary"; p.position=Vector2(245,90); p.size=Vector2(790,550); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(26,22); box.size=Vector2(735,500); p.add_child(box)
    box.add_child(label("🎉 SEXTA-FEIRA • FECHAMENTO",30))
    box.add_child(label("VOCÊ SOBREVIVEU À SEMANA!",25))
    box.add_child(label("Semana %d • demandas concluídas, pendências encaminhadas e rotina fechada." % payable_week,16))
    var week_stats:Dictionary=workday_manager.get_week_summary(payable_week)
    box.add_child(label("📊 %s\n✅ %d resolvidas  •  📤 %d comunicadas  •  ⏳ %d pendentes  •  🔴 %d críticas" % [week_stats.get("performance","SEMANA CONCLUÍDA"),week_stats.get("resolved",0),week_stats.get("communicated",0),week_stats.get("pending",0),week_stats.get("critical_pending",0)],15))
    if payable_week == 1:
        box.add_child(label("🎓 PRIMEIRA SEMANA CONCLUÍDA • O tutorial acabou. A rotina agora fica mais dinâmica.",15))
    var already_paid:=last_paid_week>=payable_week
    var status=label("✅ Pagamento desta semana já foi creditado." if already_paid else "Pagamento ainda não creditado.",17); box.add_child(status)
    var receive=Button.new(); receive.text="💵 RECEBER PAGAMENTO DA SEMANA"; receive.custom_minimum_size=Vector2(725,52); receive.disabled=already_paid; box.add_child(receive)
    receive.pressed.connect(func():
        if receive.disabled: return
        var weekly=int((monthly_salary-310)/4.0)
        player_cash+=weekly; benefits_balance+=120; clt_coins+=25; career_xp+=15; reputation+=2; last_paid_week=payable_week; current_day=workday_manager.get_day_label(); work_clock="17:30"; save_game()
        status.text="✅ +R$ %d salário proporcional  •  +R$ 120 benefícios  •  +25 CLT Coins  •  +15 XP  •  +2 REP" % weekly
        hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]
        receive.disabled=true
    )
    var weekend=Button.new(); weekend.text="🏠 INICIAR FIM DE SEMANA"; weekend.custom_minimum_size=Vector2(725,50); box.add_child(weekend)
    weekend.pressed.connect(func():
        weekend_unlocked=true; city_unlocked=true
        city_day=life_cycle_manager.display_day; city_time=life_cycle_manager.time_label; save_game()
        show_home_scene()
    )
    var close=Button.new(); close.text="🏠 IR PARA CASA" if life_cycle_manager.phase == PHASE_HOME else "FECHAR"; close.custom_minimum_size=Vector2(725,46); box.add_child(close)
    close.pressed.connect(func():
        if life_cycle_manager.phase == PHASE_HOME: show_home_scene()
        else: p.queue_free()
    )

# v0.15 — vida fora do expediente: kitnet, cidade e gastos em R$
func show_home_store(ui:CanvasLayer, status:Label) -> void:
    var old=ui.get_node_or_null("HomeStore")
    if old: old.queue_free(); return
    var p=Panel.new(); p.name="HomeStore"; p.position=Vector2(300,100); p.size=Vector2(680,530); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(24,20); box.size=Vector2(630,485); p.add_child(box)
    box.add_child(label("🛋️ MELHORAR A KITNET",28))
    var balance=label("Saldo: R$ %d  •  Conforto: %d/100" % [player_cash,home_comfort],17); box.add_child(balance)
    box.add_child(label("Compre itens com o salário. Móveis não usam CLT Coins.",15))
    var items={"sofá":"Sofá compacto","tv":"TV 43 polegadas","mesa":"Mesa para refeições","pc":"PC / setup gamer"}
    var prices={"sofá":450,"tv":700,"mesa":280,"pc":1200}
    var comfort={"sofá":8,"tv":6,"mesa":4,"pc":12}
    for id in items.keys():
        var b=Button.new(); var owned=owned_furniture.has(id)
        b.text=("✅ " if owned else "COMPRAR • ") + str(items[id]) + ("" if owned else " • R$ %d" % prices[id])
        b.custom_minimum_size=Vector2(620,46); b.disabled=owned; box.add_child(b)
        b.pressed.connect(func():
            if player_cash<int(prices[id]): status.text="💸 Saldo insuficiente para " + str(items[id]) + "."; return
            player_cash-=int(prices[id]); home_comfort=min(100,home_comfort+int(comfort[id])); owned_furniture[id]=true; save_game()
            status.text="🏠 " + str(items[id]) + " chegou à sua kitnet."
            balance.text="Saldo: R$ %d  •  Conforto: %d/100" % [player_cash,home_comfort]
            b.text="✅ " + str(items[id]); b.disabled=true
        )
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(620,44); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func show_city_hub(ui:CanvasLayer, status:Label) -> void:
    audio_manager.set_context("city")
    var old=ui.get_node_or_null("CityHub")
    if old: old.queue_free(); return
    city_unlocked=true; save_game()
    var p=Panel.new(); p.name="CityHub"; p.position=Vector2(235,55); p.size=Vector2(810,620); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(26,18); box.size=Vector2(755,575); p.add_child(box)
    box.add_child(label("🌆 CIDADE • TEMPO LIVRE",30))
    box.add_child(label("As atividades usam seu tempo livre do dia. Abrir lojas, garagem e contatos não consome uma ação.",14))
    var city_status=label("Saldo: R$ %d  •  ⚡ %d/100  •  💬 %d\n%s" % [player_cash,energy,social_affinity,personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day)],16); box.add_child(city_status)
    var places=[
        ["gym","🏋️ ACADEMIA","Treino pós-expediente",35,8,0,"19:20","Treino concluído. Corpo cansado, cabeça mais leve."],
        ["restaurant","🍔 RESTAURANTE","Jantar no centro",55,10,1,"19:40","Jantar tranquilo e uma conversa casual."],
        ["orla","🌊 ORLA","Caminhar na orla",0,8,1,"19:15","Caminhada gratuita na orla. Você desacelerou depois do expediente."],
        ["city_store","🛍️ LOJA DO CENTRO","Comprar item casual",90,2,1,"20:00","Roupa casual adicionada ao guarda-roupa."],
        ["arcade","🎮 LAN HOUSE / ARCADE","Jogar depois do trabalho",25,5,2,"20:10","Algumas partidas e conversa com gente nova."]
    ]
    for place in places:
        var action_id:=str(place[0])
        var b=Button.new(); b.text="%s • %s%s" % [place[1],place[2],(" • R$ %d" % place[3]) if int(place[3])>0 else " • GRÁTIS"]; b.custom_minimum_size=Vector2(745,44); box.add_child(b)
        b.disabled=personal_life_manager.has_done(personal_week_number(),life_cycle_manager.display_day,action_id) or (action_id=="city_store" and unlocked_skins.has("casual_cidade"))
        b.pressed.connect(func():
            var cost=int(place[3])
            if player_cash<cost: city_status.text="⚠️ Saldo insuficiente para essa atividade."; return
            var action=personal_life_manager.try_action(personal_week_number(),life_cycle_manager.display_day,action_id,true,true)
            if not bool(action.get("ok",false)):
                city_status.text="⏳ %s" % action.get("message","Sem tempo livre restante."); return
            player_cash-=cost
            energy=clampi(energy+int(place[4]),0,100)
            social_affinity=maxi(0,social_affinity+int(place[5]))
            if action_id=="city_store": unlocked_skins["casual_cidade"]=true
            life_cycle_manager.register_evening_action(str(place[6])); city_time=life_cycle_manager.time_label
            b.disabled=true
            save_game(); city_status.text="%s\n%s\nSaldo: R$ %d • ⚡ %d/100 • 💬 %d\n%s" % [place[1],place[7],player_cash,energy,social_affinity,personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day)]
        )
    var dealer=Button.new(); dealer.text="🚘 CONCESSIONÁRIA • comprar veículos com R$"; dealer.custom_minimum_size=Vector2(745,44); box.add_child(dealer)
    dealer.pressed.connect(func(): show_dealership(ui))
    var garage=Button.new(); garage.text="🏠 GARAGEM • veículo ativo: " + active_vehicle; garage.custom_minimum_size=Vector2(745,44); box.add_child(garage)
    garage.pressed.connect(func(): show_garage(ui))
    var life=Button.new(); life.text="🌙 VIDA SOCIAL / CONTATOS"; life.custom_minimum_size=Vector2(745,44); box.add_child(life)
    life.pressed.connect(func(): show_after_work_life(ui,status))
    var home=Button.new(); home.text="🏠 VOLTAR PARA A KITNET"; home.custom_minimum_size=Vector2(745,44); box.add_child(home)
    home.pressed.connect(func(): p.queue_free(); status.text="🏠 Você voltou para a kitnet depois de passear pela cidade.")

func show_after_work_life(ui:CanvasLayer, status:Label) -> void:
    var old=ui.get_node_or_null("AfterWorkLife")
    if old: old.queue_free(); return
    city_unlocked=true
    var p=Panel.new(); p.name="AfterWorkLife"; p.position=Vector2(220,65); p.size=Vector2(840,600); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(26,20); box.size=Vector2(785,555); p.add_child(box)
    box.add_child(label("🌆 VIDA FORA DO EXPEDIENTE",30))
    var stats=label("%s • %s   ⚡ %d/100   💬 %d   💵 R$ %d\n%s" % [city_day,city_time,energy,social_affinity,player_cash,personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day)],16); box.add_child(stats)
    var note=label("Você não precisa fazer tudo no mesmo dia. Escolhas de lazer e socialização usam tempo livre.",15); note.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(note)
    var result=label("Escolha uma atividade ou abra seus contatos.",16); result.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(result)
    var actions=[
        ["gym","🏋️ TREINAR NA ACADEMIA",35,8,0,"19:20","Treino concluído. Você encontra funcionários da LR Global fora do escritório."],
        ["restaurant","🍽️ JANTAR NO CENTRO",55,10,1,"19:40","Jantar tranquilo. Uma conversa casual aumenta sua vida social."],
        ["orla","🌊 CAMINHAR NA ORLA",0,8,1,"19:15","Caminhada gratuita na orla. Cabeça mais leve depois do expediente."],
        ["arcade","🎮 IR AO ARCADE",25,5,2,"20:10","Você joga algumas partidas e conhece gente nova."],
        ["home_evening","🏠 FICAR NA KITNET",0,18,0,"20:30","Noite em casa. Descanso maior e nenhum gasto."]
    ]
    for a in actions:
        var action_id:=str(a[0])
        var b=Button.new(); b.text="%s%s" % [a[1], (" • R$ %d" % a[2]) if int(a[2])>0 else " • GRÁTIS"]; b.custom_minimum_size=Vector2(775,44); box.add_child(b)
        b.disabled=personal_life_manager.has_done(personal_week_number(),life_cycle_manager.display_day,action_id)
        b.pressed.connect(func():
            if player_cash<int(a[2]): result.text="⚠️ Você não tem dinheiro suficiente para essa atividade."; return
            var action=personal_life_manager.try_action(personal_week_number(),life_cycle_manager.display_day,action_id,true,true)
            if not bool(action.get("ok",false)):
                result.text="⏳ %s" % action.get("message","Sem tempo livre restante."); return
            player_cash-=int(a[2]); energy=clampi(energy+int(a[3]),0,100); social_affinity=maxi(0,social_affinity+int(a[4])); city_time=str(a[5]); life_cycle_manager.register_evening_action(city_time); b.disabled=true; save_game()
            result.text=str(a[6]); stats.text="%s • %s   ⚡ %d/100   💬 %d   💵 R$ %d\n%s" % [city_day,city_time,energy,social_affinity,player_cash,personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day)]
        )
    var social=Button.new(); social.text="💬 VER CONTATOS / RELACIONAMENTOS"; social.custom_minimum_size=Vector2(775,46); box.add_child(social)
    social.pressed.connect(func(): show_relationships_panel(ui))
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(775,42); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func update_relationship_stage() -> void:
    if alex_affinity >= 60: relationship_stage="Namoro"
    elif alex_affinity >= 35: relationship_stage="Interesse"
    elif alex_affinity >= 15: relationship_stage="Amizade"
    else: relationship_stage="Conhecido(a)"

func show_relationships_panel(ui:CanvasLayer) -> void:
    var old=ui.get_node_or_null("RelationshipsPanel")
    if old: old.queue_free(); return
    update_relationship_stage()
    var p=Panel.new(); p.name="RelationshipsPanel"; p.position=Vector2(300,75); p.size=Vector2(680,570); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(24,20); box.size=Vector2(630,525); p.add_child(box)
    box.add_child(label("💬 CONTATOS & RELACIONAMENTOS",27))
    var info=label("👤 Alex • %s\n❤️ Afinidade: %d/100" % [relationship_stage,alex_affinity],18); box.add_child(info)
    var time_info=label(personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day),14); box.add_child(time_info)
    var feedback=label("Relacionamentos são opcionais. Mensagem não gasta uma ação, mas só rende afinidade uma vez por dia.",15); feedback.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(feedback)
    var msg=Button.new(); msg.text="📱 ENVIAR MENSAGEM • GRÁTIS"; msg.custom_minimum_size=Vector2(620,44); box.add_child(msg)
    msg.disabled=personal_life_manager.has_done(personal_week_number(),life_cycle_manager.display_day,"alex_message")
    msg.pressed.connect(func():
        var action=personal_life_manager.try_action(personal_week_number(),life_cycle_manager.display_day,"alex_message",false,true)
        if not bool(action.get("ok",false)):
            feedback.text="💬 %s" % action.get("message","Você já conversou hoje."); return
        alex_affinity=min(100,alex_affinity+3); social_affinity+=1; update_relationship_stage(); save_game(); info.text="👤 Alex • %s\n❤️ Afinidade: %d/100" % [relationship_stage,alex_affinity]; feedback.text="💬 A conversa fluiu bem. +3 afinidade."; msg.disabled=true
    )
    var coffee=Button.new(); coffee.text="☕ CONVIDAR PARA UM CAFÉ • R$ 25"; coffee.custom_minimum_size=Vector2(620,44); box.add_child(coffee)
    coffee.disabled=personal_life_manager.has_done(personal_week_number(),life_cycle_manager.display_day,"alex_coffee")
    coffee.pressed.connect(func():
        if player_cash<25: feedback.text="⚠️ Saldo insuficiente."; return
        var action=personal_life_manager.try_action(personal_week_number(),life_cycle_manager.display_day,"alex_coffee",true,true)
        if not bool(action.get("ok",false)):
            feedback.text="⏳ %s" % action.get("message","Sem tempo livre restante."); return
        player_cash-=25; alex_affinity=min(100,alex_affinity+7); social_affinity+=2; city_time="20:30"; life_cycle_manager.register_evening_action(city_time); update_relationship_stage(); save_game(); info.text="👤 Alex • %s\n❤️ Afinidade: %d/100" % [relationship_stage,alex_affinity]; time_info.text=personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day); feedback.text="☕ Vocês conversaram fora do trabalho. +7 afinidade."; coffee.disabled=true
    )
    var date=Button.new(); date.text="🍽️ CONVIDAR PARA UM ENCONTRO • R$ 80"; date.custom_minimum_size=Vector2(620,44); date.disabled=alex_affinity<35 or personal_life_manager.has_done(personal_week_number(),life_cycle_manager.display_day,"alex_date"); box.add_child(date)
    date.pressed.connect(func():
        if player_cash<80: feedback.text="⚠️ Saldo insuficiente."; return
        var action=personal_life_manager.try_action(personal_week_number(),life_cycle_manager.display_day,"alex_date",true,true)
        if not bool(action.get("ok",false)):
            feedback.text="⏳ %s" % action.get("message","Sem tempo livre restante."); return
        player_cash-=80; alex_affinity=min(100,alex_affinity+12); social_affinity+=4; energy=max(0,energy-5); city_time="22:10"; life_cycle_manager.register_evening_action(city_time); update_relationship_stage(); save_game(); info.text="👤 Alex • %s\n❤️ Afinidade: %d/100" % [relationship_stage,alex_affinity]; time_info.text=personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day); feedback.text="❤️ Encontro concluído. +12 afinidade."; date.disabled=true
    )
    var weekend=Button.new(); weekend.text="🎉 EVENTO DE SÁBADO • FESTA NA ORLA"; weekend.custom_minimum_size=Vector2(620,44); weekend.disabled=not weekend_unlocked or life_cycle_manager.display_day!="SÁBADO" or not personal_life_manager.weekend_event_available(personal_week_number()); box.add_child(weekend)
    weekend.pressed.connect(func(): show_weekend_event(ui,feedback); time_info.text=personal_life_manager.status_text(personal_week_number(),life_cycle_manager.display_day); weekend.disabled=not personal_life_manager.weekend_event_available(personal_week_number()))
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(620,42); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func show_weekend_event(ui:CanvasLayer, feedback:Label) -> void:
    if life_cycle_manager.display_day != "SÁBADO":
        feedback.text="📅 Esse evento acontece somente no sábado."; return
    if not personal_life_manager.weekend_event_available(personal_week_number()):
        feedback.text="🎉 Você já participou do evento deste fim de semana."; return
    if energy<20:
        feedback.text="😴 Energia baixa. Descanse antes de sair."; return
    var action=personal_life_manager.try_action(personal_week_number(),life_cycle_manager.display_day,"weekend_orla_event",true,true)
    if not bool(action.get("ok",false)):
        feedback.text="⏳ %s" % action.get("message","Sem tempo livre restante."); return
    personal_life_manager.mark_weekend_event(personal_week_number())
    city_day="SÁBADO"; city_time="19:00"; life_cycle_manager.register_evening_action(city_time)
    energy=max(0,energy-15); social_affinity+=5; alex_affinity=min(100,alex_affinity+5); clt_coins+=10; update_relationship_stage(); save_game()
    feedback.text="🎉 Festa na orla concluída! +5 social, +5 afinidade e +10 CLT Coins. O evento só recompensa uma vez por fim de semana."

func show_dealership(ui:CanvasLayer) -> void:
    var old=ui.get_node_or_null("DealershipPanel")
    if old: old.queue_free(); return
    var p=Panel.new(); p.name="DealershipPanel"; p.position=Vector2(285,85); p.size=Vector2(710,550); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(24,20); box.size=Vector2(660,505); p.add_child(box)
    box.add_child(label("🚘 CONCESSIONÁRIA PORTO VALE",28))
    var balance=label("Saldo: R$ %d  •  Veículo ativo: %s" % [player_cash,active_vehicle],17); box.add_child(balance)
    var feedback=label("Veículos comuns são comprados com o dinheiro do trabalho. Veículos de Easter Egg não ficam à venda.",15); feedback.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(feedback)
    var catalog=[
        ["Moto Urbana 125",900,"🏍️ Econômica para circular pela cidade."],
        ["Compacto Popular",4800,"🚗 Primeiro carro: simples, confiável e barato de manter."],
        ["Sedan Executivo",12500,"🚙 Mais conforto para quem já cresceu na carreira."]
    ]
    for item in catalog:
        var vehicle_name=str(item[0]); var price=int(item[1])
        var b=Button.new(); b.custom_minimum_size=Vector2(650,52)
        if unlocked_vehicles.has(vehicle_name): b.text="✅ %s • NA GARAGEM" % vehicle_name; b.disabled=true
        else: b.text="%s • R$ %d" % [vehicle_name,price]
        box.add_child(b)
        b.pressed.connect(func():
            if player_cash<price: feedback.text="⚠️ Saldo insuficiente para comprar " + vehicle_name + ". Continue trabalhando e juntando R$."; return
            player_cash-=price; unlocked_vehicles[vehicle_name]=true; ensure_vehicle_stats(vehicle_name); garage_unlocked=true; active_vehicle=vehicle_name; save_game()
            b.text="✅ %s • COMPRADO" % vehicle_name; b.disabled=true
            balance.text="Saldo: R$ %d  •  Veículo ativo: %s" % [player_cash,active_vehicle]
            feedback.text="🔑 %s agora está na sua garagem e foi definido como veículo ativo." % vehicle_name
        )
    var legendary=label("🔒 Veículo lendário: PLANILHAMÓVEL • somente pelo Easter Egg ‘O Cara das Planilhas’." if not unlocked_vehicles.has("Planilhamóvel") else "✨ PLANILHAMÓVEL • veículo lendário já desbloqueado!",15); legendary.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(legendary)
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(650,44); box.add_child(close); close.pressed.connect(func(): p.queue_free())

func show_garage(ui:CanvasLayer) -> void:
    var old=ui.get_node_or_null("GaragePanel")
    if old: old.queue_free(); return
    var p=Panel.new(); p.name="GaragePanel"; p.position=Vector2(285,80); p.size=Vector2(710,565); ui.add_child(p)
    var box=VBoxContainer.new(); box.position=Vector2(24,20); box.size=Vector2(660,520); p.add_child(box)
    box.add_child(label("🏠 MINHA GARAGEM",28))
    var info=label("Veículo ativo: %s" % active_vehicle,18); box.add_child(info)
    var feedback=label("Escolha como você quer circular pela cidade. Ir a pé continua sempre disponível.",15); feedback.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(feedback)
    var walk=Button.new(); walk.text="🚶 IR A PÉ"; walk.custom_minimum_size=Vector2(650,46); box.add_child(walk)
    walk.pressed.connect(func(): active_vehicle="A pé"; save_game(); info.text="Veículo ativo: A pé"; feedback.text="🚶 Você decidiu ir a pé.")
    if unlocked_vehicles.is_empty():
        box.add_child(label("Nenhum veículo próprio ainda. Visite a concessionária ou descubra um veículo secreto.",15))
    else:
        for key in unlocked_vehicles.keys():
            if not bool(unlocked_vehicles[key]): continue
            var vehicle_name=str(key)
            var b=Button.new(); b.text=("✨ " if vehicle_name=="Planilhamóvel" else "🚗 ") + vehicle_name; b.custom_minimum_size=Vector2(650,46); box.add_child(b)
            b.pressed.connect(func(): active_vehicle=vehicle_name; garage_unlocked=true; save_game(); info.text="Veículo ativo: " + active_vehicle; feedback.text="🔑 %s selecionado. Ele será usado nos próximos deslocamentos." % active_vehicle)
    var drive=Button.new(); drive.text="🛣️ DAR UMA VOLTA PELA CIDADE"; drive.custom_minimum_size=Vector2(650,46); drive.disabled=active_vehicle=="A pé"; box.add_child(drive)
    drive.pressed.connect(func():
        take_vehicle_trip(active_vehicle, feedback, info)
    )
    if active_vehicle != "A pé":
        ensure_vehicle_stats(active_vehicle)
        var fuel=Button.new(); fuel.text="⛽ ABASTECER • R$ 80"; fuel.custom_minimum_size=Vector2(650,46); box.add_child(fuel)
        fuel.pressed.connect(func(): refuel_vehicle(active_vehicle,feedback,info))
        var maint=Button.new(); maint.text="🔧 REVISÃO / MANUTENÇÃO • R$ 180"; maint.custom_minimum_size=Vector2(650,46); box.add_child(maint)
        maint.pressed.connect(func(): service_vehicle(active_vehicle,feedback,info))
    var close=Button.new(); close.text="VOLTAR"; close.custom_minimum_size=Vector2(650,44); box.add_child(close); close.pressed.connect(func(): p.queue_free())


# v0.20 — uso real dos veículos: combustível, condição, km e imprevistos
func ensure_vehicle_stats(vehicle_name:String) -> void:
    if not vehicle_fuel.has(vehicle_name): vehicle_fuel[vehicle_name]=100
    if not vehicle_condition.has(vehicle_name): vehicle_condition[vehicle_name]=100
    if not vehicle_km.has(vehicle_name): vehicle_km[vehicle_name]=0

func vehicle_status_text(vehicle_name:String) -> String:
    if vehicle_name=="A pé": return "Veículo ativo: A pé"
    ensure_vehicle_stats(vehicle_name)
    return "Veículo ativo: %s  •  ⛽ %d%%  •  🔧 %d%%  •  %d km" % [vehicle_name,int(vehicle_fuel[vehicle_name]),int(vehicle_condition[vehicle_name]),int(vehicle_km[vehicle_name])]

func take_vehicle_trip(vehicle_name:String, feedback:Label, info:Label) -> void:
    if vehicle_name=="A pé":
        feedback.text="🚶 Selecione um veículo na garagem para dirigir."; return
    ensure_vehicle_stats(vehicle_name)
    var fuel_cost=6 if vehicle_name=="Moto Urbana 125" else 9
    if vehicle_name=="Planilhamóvel": fuel_cost=5
    if int(vehicle_fuel[vehicle_name]) < fuel_cost:
        feedback.text="⛽ Combustível insuficiente. Passe no posto antes de sair."; return
    vehicle_fuel[vehicle_name]=max(0,int(vehicle_fuel[vehicle_name])-fuel_cost)
    vehicle_condition[vehicle_name]=max(0,int(vehicle_condition[vehicle_name])-2)
    vehicle_km[vehicle_name]=int(vehicle_km[vehicle_name])+12
    energy=max(0,energy-2); social_affinity+=1; city_time="20:10"
    var event_roll=int(vehicle_km[vehicle_name]) % 5
    if int(vehicle_condition[vehicle_name]) <= 35:
        feedback.text="⚠️ %s começou a fazer um barulho estranho. Melhor fazer manutenção antes do próximo passeio." % vehicle_name
    elif event_roll==0:
        player_cash=max(0,player_cash-35)
        feedback.text="🚧 IMPREVISTO NA RUA! Você pegou um desvio e gastou R$ 35 a mais no trajeto."
    elif vehicle_name=="Planilhamóvel":
        clt_coins+=5
        feedback.text="📊🚗 PLANILHAMÓVEL EM AÇÃO! O painel exibiu uma planilha secreta. +5 CLT Coins 😂"
    else:
        feedback.text="🛣️ Passeio concluído com %s. +1 social • -2 energia • +12 km." % vehicle_name
    info.text=vehicle_status_text(vehicle_name); save_game()

func refuel_vehicle(vehicle_name:String, feedback:Label, info:Label) -> void:
    ensure_vehicle_stats(vehicle_name)
    if int(vehicle_fuel[vehicle_name])>=100:
        feedback.text="⛽ O tanque já está cheio."; return
    if player_cash<80:
        feedback.text="⚠️ Saldo insuficiente para abastecer."; return
    player_cash-=80; vehicle_fuel[vehicle_name]=100; save_game()
    info.text=vehicle_status_text(vehicle_name); feedback.text="⛽ Tanque cheio! -R$ 80."

func service_vehicle(vehicle_name:String, feedback:Label, info:Label) -> void:
    ensure_vehicle_stats(vehicle_name)
    if int(vehicle_condition[vehicle_name])>=100:
        feedback.text="🔧 O veículo está em ótima condição."; return
    if player_cash<180:
        feedback.text="⚠️ Saldo insuficiente para a manutenção."; return
    player_cash-=180; vehicle_condition[vehicle_name]=100; save_game()
    info.text=vehicle_status_text(vehicle_name); feedback.text="🔧 Revisão concluída. Condição restaurada para 100%. -R$ 180."


# v0.24 — Central de chamados internos e pressão do expediente
func show_internal_requests(ui:CanvasLayer, hud_money:Label, objective_label:Label) -> void:
    var old=ui.get_node_or_null("InternalRequests")
    if old: old.queue_free(); return
    var panel=Panel.new(); panel.name="InternalRequests"; panel.position=Vector2(275,85); panel.size=Vector2(730,555); ui.add_child(panel)
    var box=VBoxContainer.new(); box.position=Vector2(26,20); box.size=Vector2(678,510); panel.add_child(box)
    box.add_child(label("📥 CENTRAL DE CHAMADOS INTERNOS",28))
    box.add_child(label("Lucas virou o suporte não oficial da LR Global. Quanto mais pedidos chegam, maior a pressão do expediente.",15))
    var status=label("Resolvidos: %d   •   Pressão: %d/5" % [internal_requests_resolved,internal_request_pressure],18); box.add_child(status)
    var incoming=Button.new(); incoming.text="📲 RECEBER NOVO ‘RAPIDINHO’"; incoming.custom_minimum_size=Vector2(670,50); box.add_child(incoming)
    var solve=Button.new(); solve.text="🛠️ RESOLVER CHAMADO PRIORITÁRIO"; solve.custom_minimum_size=Vector2(670,50); box.add_child(solve)
    solve.disabled=internal_request_pressure<=0
    var history=label("Histórico:\n%s" % ("Nenhum chamado registrado." if internal_requests_history.is_empty() else "\n".join(internal_requests_history)),14); history.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(history)
    incoming.pressed.connect(func():
        internal_request_pressure=min(5,internal_request_pressure+1)
        var callers=["Coordenadora","Programação","Atendimento","Financeiro","Qualidade"]
        var topics=["indicador não atualiza","placa duplicada no filtro","dashboard sem números","rotina manual demais","formulário confuso"]
        var idx=(internal_requests_resolved+internal_request_pressure)%callers.size()
        internal_requests_history.push_front("%s • %s • PENDENTE" % [callers[idx],topics[idx]])
        if internal_requests_history.size()>8: internal_requests_history.resize(8)
        objective_label.text="📲 %s: ‘Lucas, rapidinho... %s.’" % [callers[idx],topics[idx]]
        if internal_request_pressure>=4:
            objective_label.text += "\n⚠️ A Coordenadora: ‘Lucas, tem bastante coisa acumulando aí, hein!’"
        save_game(); panel.queue_free(); show_internal_requests(ui,hud_money,objective_label)
    )
    solve.pressed.connect(func():
        if internal_request_pressure<=0: return
        internal_request_pressure-=1; internal_requests_resolved+=1; career_xp+=6; reputation+=1
        internal_requests_history.push_front("Lucas • chamado prioritário • RESOLVIDO")
        if internal_requests_history.size()>8: internal_requests_history.resize(8)
        objective_label.text="💻 LUCAS: ‘Resolvido. Próximo... porque eu sei que vai aparecer outro. 😂’\n+6 XP • +1 REP"
        if internal_requests_resolved==10:
            clt_coins+=80; unlocked_skins["Camiseta TI Sem Ser TI"]=true
            objective_label.text += "\n🏆 Conquista: TI SEM SER TI • +80 CLT Coins • Camiseta exclusiva"
        save_game(); hud_money.text="R$ %d     🪙 %d CLT Coins     ⭐ XP %d/100     REP %d" % [player_cash,clt_coins,career_xp,reputation]
        panel.queue_free(); show_internal_requests(ui,hud_money,objective_label)
    )
    var close=Button.new(); close.text="VOLTAR AO EXPEDIENTE"; close.custom_minimum_size=Vector2(670,46); box.add_child(close); close.pressed.connect(func(): panel.queue_free())
