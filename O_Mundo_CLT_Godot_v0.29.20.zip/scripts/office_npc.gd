extends Node3D

@export var npc_role := "NPC"
@export var idle_motion := true
var base_y := 0.0
var phase := 0.0

func _ready() -> void:
    base_y = position.y
    phase = float(get_instance_id() % 100) / 13.0

func _process(delta: float) -> void:
    if not idle_motion:
        return
    phase += delta
    rotation.y = sin(phase * 0.65) * 0.025
