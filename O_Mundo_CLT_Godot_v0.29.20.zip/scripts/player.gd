extends CharacterBody3D

@export var speed := 5.0
@export var sprint_multiplier := 1.55
@export var camera_sensitivity := 2.2
@export var mobile_deadzone := 0.10
@export var invert_camera := false
var move_input := Vector2.ZERO
var look_input := Vector2.ZERO
var yaw := 0.0
var pitch := -0.25
var mobile_sprint := false
var camera_pivot: Node3D

func _ready() -> void:
    camera_pivot = get_node_or_null("CameraPivot")

func set_mobile_move(v: Vector2) -> void:
    var limited := v.limit_length(1.0)
    move_input = Vector2.ZERO if limited.length() < mobile_deadzone else limited

func set_mobile_look(v: Vector2) -> void:
    var limited := v.limit_length(1.0)
    look_input = Vector2.ZERO if limited.length() < mobile_deadzone else limited

func set_mobile_sprint(enabled: bool) -> void:
    mobile_sprint = enabled

func _physics_process(delta: float) -> void:
    var keyboard := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
    var input := move_input if move_input.length() > 0.05 else keyboard
    yaw -= look_input.x * camera_sensitivity * delta
    var look_y := -look_input.y if invert_camera else look_input.y
    pitch = clamp(pitch - look_y * camera_sensitivity * delta, -0.75, 0.35)
    rotation.y = yaw
    if camera_pivot:
        camera_pivot.rotation.x = pitch
    var dir := (transform.basis * Vector3(input.x, 0, input.y)).normalized()
    var current_speed := speed * (sprint_multiplier if mobile_sprint and input.length() > mobile_deadzone else 1.0)
    velocity.x = dir.x * current_speed
    velocity.z = dir.z * current_speed
    velocity.y = 0.0
    move_and_slide()
