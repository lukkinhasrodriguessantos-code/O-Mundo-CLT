extends Node
class_name MobileUIManager

const DESIGN_SIZE := Vector2(1280.0, 720.0)
const MIN_TOUCH_SIZE := 72.0
const MAX_SAFE_MARGIN := 96.0

var safe_margins := Vector4.ZERO # left, top, right, bottom in canvas units
var touch_scale := 1.0

func _ready() -> void:
    refresh_safe_area()

func canvas_size() -> Vector2:
    var size := get_viewport().get_visible_rect().size
    if size.x < 640.0 or size.y < 360.0:
        return DESIGN_SIZE
    return size

func refresh_safe_area() -> void:
    safe_margins = Vector4.ZERO
    if OS.get_name() not in ["Android", "iOS"]:
        return
    var screen_size_i := DisplayServer.screen_get_size()
    var safe := DisplayServer.get_display_safe_area()
    if screen_size_i.x <= 0 or screen_size_i.y <= 0 or safe.size.x <= 0 or safe.size.y <= 0:
        return
    var virtual_size := canvas_size()
    var scale_x := virtual_size.x / float(screen_size_i.x)
    var scale_y := virtual_size.y / float(screen_size_i.y)
    safe_margins.x = clamp(float(safe.position.x) * scale_x, 0.0, MAX_SAFE_MARGIN)
    safe_margins.y = clamp(float(safe.position.y) * scale_y, 0.0, MAX_SAFE_MARGIN)
    safe_margins.z = clamp(float(screen_size_i.x - safe.end.x) * scale_x, 0.0, MAX_SAFE_MARGIN)
    safe_margins.w = clamp(float(screen_size_i.y - safe.end.y) * scale_y, 0.0, MAX_SAFE_MARGIN)

func gameplay_layout() -> Dictionary:
    refresh_safe_area()
    var size := canvas_size()
    var left := 18.0 + safe_margins.x
    var top := 15.0 + safe_margins.y
    var right := size.x - 18.0 - safe_margins.z
    var bottom := size.y - 18.0 - safe_margins.w
    var bag_size := Vector2(100.0, 78.0) * touch_scale
    var phone_size := Vector2(100.0, 68.0) * touch_scale
    var interact_size := Vector2(132.0, 94.0) * touch_scale
    var run_size := Vector2(88.0, 80.0) * touch_scale
    return {
        "canvas_size": size,
        "top_position": Vector2(left, top),
        "top_size": Vector2(max(760.0, right - left), 72.0),
        "objective_position": Vector2(left, top + 85.0),
        "bag_position": Vector2(right - bag_size.x, top + 90.0),
        "bag_size": bag_size,
        "phone_position": Vector2(right - phone_size.x, top + 178.0),
        "phone_size": phone_size,
        "interact_position": Vector2(right - 218.0, bottom - 98.0),
        "interact_size": interact_size,
        "run_position": Vector2(right - run_size.x, bottom - 90.0),
        "run_size": run_size,
        "left_joystick_center": Vector2(left + 112.0, bottom - 112.0),
        "right_joystick_center": Vector2(right - 350.0, bottom - 112.0),
        "inventory_position": Vector2(right - 410.0, top + 90.0)
    }

func apply_touch_target(control: Control, minimum := Vector2(MIN_TOUCH_SIZE, MIN_TOUCH_SIZE)) -> void:
    control.custom_minimum_size = Vector2(max(minimum.x, MIN_TOUCH_SIZE), max(minimum.y, MIN_TOUCH_SIZE))

func set_touch_scale(value: float) -> void:
    touch_scale = clamp(value, 0.85, 1.30)

func get_touch_scale() -> float:
    return touch_scale
