extends Node
class_name AlphaSessionManager

const LOCK_PATH := "user://alpha_session.lock"
const META_PATH := "user://alpha_session_meta.json"

var previous_unclean_exit := false
var launch_count := 0
var session_started_unix := 0
var app_version := ""

func _read_meta() -> Dictionary:
    if not FileAccess.file_exists(META_PATH):
        return {}
    var f := FileAccess.open(META_PATH, FileAccess.READ)
    if not f:
        return {}
    var parsed = JSON.parse_string(f.get_as_text())
    return parsed if typeof(parsed) == TYPE_DICTIONARY else {}

func _write_meta() -> void:
    var f := FileAccess.open(META_PATH, FileAccess.WRITE)
    if not f:
        return
    f.store_string(JSON.stringify({
        "launch_count": launch_count,
        "last_version": app_version,
        "last_session_started_unix": session_started_unix,
        "previous_unclean_exit": previous_unclean_exit
    }))

func begin_session(version: String) -> void:
    app_version = version
    previous_unclean_exit = FileAccess.file_exists(LOCK_PATH)
    var meta := _read_meta()
    launch_count = int(meta.get("launch_count", 0)) + 1
    session_started_unix = int(Time.get_unix_time_from_system())
    var lock := FileAccess.open(LOCK_PATH, FileAccess.WRITE)
    if lock:
        lock.store_string(JSON.stringify({
            "version": app_version,
            "started_unix": session_started_unix,
            "launch_count": launch_count
        }))
        lock.flush()
    _write_meta()

func mark_clean_shutdown() -> void:
    if FileAccess.file_exists(LOCK_PATH):
        DirAccess.remove_absolute(ProjectSettings.globalize_path(LOCK_PATH))

func session_summary() -> String:
    if previous_unclean_exit:
        return "Sessão anterior foi encerrada inesperadamente"
    return "Sessão anterior encerrada normalmente"
