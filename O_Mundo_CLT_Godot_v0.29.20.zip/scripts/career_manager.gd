extends Node
class_name CareerManager

const ROLE_ASSISTANT := "Assistente"
const ROLE_JUNIOR := "Analista Jr"

var evaluation_attempts := 0
var evaluation_passed := false
var retry_after_completed_days := 0
var last_feedback := ""

func completed_days(workday_manager:Node) -> int:
    if workday_manager == null:
        return 0
    return int(workday_manager.total_completed_days)

func recent_performance(workday_manager:Node) -> Dictionary:
    var score := 0
    var clean_days := 0
    var communicated := 0
    var critical_pending := 0
    if workday_manager == null:
        return {"score":0,"clean_days":0,"communicated":0,"critical_pending":0}
    var history:Array = workday_manager.daily_history
    var limit := mini(history.size(), 5)
    for i in range(limit):
        var day:Dictionary = history[i]
        communicated += int(day.get("communicated", 0))
        critical_pending += int(day.get("critical_pending", 0))
        if int(day.get("critical_pending", 0)) == 0:
            score += 1
        else:
            score -= 2
        if int(day.get("pending", 0)) == 0:
            score += 1
            clean_days += 1
        elif int(day.get("communicated", 0)) > 0:
            score += 1
    return {"score":score,"clean_days":clean_days,"communicated":communicated,"critical_pending":critical_pending}

func get_assistant_progress(xp:int, reputation:int, workday_manager:Node) -> Dictionary:
    var days := completed_days(workday_manager)
    var performance := recent_performance(workday_manager)
    var ready_xp := xp >= 100
    var ready_rep := reputation >= 58
    var ready_days := days >= 5
    var ready_history := int(performance.get("score", 0)) >= 5
    var retry_ready := days >= retry_after_completed_days
    return {
        "xp":xp,
        "xp_required":100,
        "reputation":reputation,
        "reputation_required":58,
        "completed_days":days,
        "days_required":5,
        "performance_score":int(performance.get("score",0)),
        "performance_ready":ready_history,
        "retry_ready":retry_ready,
        "eligible":ready_xp and ready_rep and ready_days and ready_history and retry_ready and not evaluation_passed
    }

func get_status_text(role:String, xp:int, reputation:int, workday_manager:Node) -> String:
    if role != ROLE_ASSISTANT:
        return "Cargo atual: %s\nNovas responsabilidades e demandas de autonomia estão liberadas." % role
    var p := get_assistant_progress(xp, reputation, workday_manager)
    var performance_text := "PRONTO" if bool(p.get("performance_ready",false)) else "EM DESENVOLVIMENTO"
    var retry_text := ""
    if not bool(p.get("retry_ready",true)):
        retry_text = "\n⏳ Nova tentativa após concluir mais um expediente."
    return "Próxima promoção: ANALISTA JR\n⭐ XP: %d/%d\n🏅 Reputação: %d/%d\n📅 Expedientes concluídos: %d/%d\n📊 Desempenho recente: %s%s" % [
        int(p.get("xp",0)), int(p.get("xp_required",100)),
        int(p.get("reputation",0)), int(p.get("reputation_required",58)),
        int(p.get("completed_days",0)), int(p.get("days_required",5)),
        performance_text, retry_text
    ]

func evaluation_available(role:String, xp:int, reputation:int, workday_manager:Node) -> bool:
    if role != ROLE_ASSISTANT:
        return false
    return bool(get_assistant_progress(xp, reputation, workday_manager).get("eligible",false))

func get_evaluation(area:String) -> Dictionary:
    match area:
        "Programação":
            return {
                "title":"Carga urgente com divergência",
                "intro":"Uma carga urgente precisa sair, mas o vínculo motorista/veículo e o romaneio apresentam divergências. Monte uma resposta que preserve a operação sem liberar informação incorreta.",
                "choices":[
                    {"id":"check","text":"Conferir motorista, veículo e dados obrigatórios antes da liberação","correct":true},
                    {"id":"replan","text":"Reprogramar a carga enquanto a divergência é corrigida","correct":true},
                    {"id":"communicate","text":"Registrar e comunicar Operação/Atendimento sobre a nova previsão","correct":true},
                    {"id":"force","text":"Liberar assim mesmo porque a carga é urgente","correct":false},
                    {"id":"hide","text":"Corrigir sem registrar para evitar questionamentos","correct":false}
                ]
            }
        "Atendimento":
            return {
                "title":"Cliente cobrando posição urgente",
                "intro":"O cliente pede uma previsão imediata, mas a operação ainda não confirmou a liberação. Organize a resposta sem inventar prazo.",
                "choices":[
                    {"id":"facts","text":"Confirmar a situação real com a área responsável","correct":true},
                    {"id":"partial","text":"Retornar ao cliente com o que já está confirmado e informar o próximo horário de atualização","correct":true},
                    {"id":"record","text":"Registrar o retorno e acompanhar até a conclusão","correct":true},
                    {"id":"promise","text":"Prometer um horário de entrega para acalmar o cliente","correct":false},
                    {"id":"ignore","text":"Esperar a operação resolver antes de responder qualquer coisa","correct":false}
                ]
            }
        "Operação de Contêineres Vazios":
            return {
                "title":"Divergência no pátio",
                "intro":"Uma movimentação urgente aparece com divergência de contêiner. A fila está aumentando e a equipe pede uma decisão rápida.",
                "choices":[
                    {"id":"hold","text":"Segurar a movimentação divergente até confirmar os dados","correct":true},
                    {"id":"checkyard","text":"Conferir posição física e registro operacional do contêiner","correct":true},
                    {"id":"update","text":"Atualizar as áreas envolvidas e reorganizar a sequência do pátio","correct":true},
                    {"id":"move","text":"Movimentar primeiro e corrigir o sistema depois","correct":false},
                    {"id":"delete","text":"Excluir o registro divergente para liberar a fila","correct":false}
                ]
            }
        _:
            return {
                "title":"Veículos indisponíveis e carga urgente",
                "intro":"Dois veículos estão indisponíveis e uma carga urgente precisa sair. Organize a resposta sem liberar veículo inseguro.",
                "choices":[
                    {"id":"block","text":"Bloquear os veículos com pendência de segurança","correct":true},
                    {"id":"replace","text":"Buscar veículo apto disponível e reprogramar a carga","correct":true},
                    {"id":"communicate","text":"Registrar a decisão e avisar Programação/Operação","correct":true},
                    {"id":"unsafe","text":"Liberar o veículo com pendência para evitar atraso","correct":false},
                    {"id":"roadtest","text":"Pedir ao motorista para testar o problema na estrada","correct":false}
                ]
            }

func evaluate(selected_ids:Array, area:String, workday_manager:Node) -> Dictionary:
    evaluation_attempts += 1
    var data := get_evaluation(area)
    var choices:Array = data.get("choices", [])
    var correct_selected := 0
    var wrong_selected := 0
    for choice in choices:
        if selected_ids.has(str(choice.get("id", ""))):
            if bool(choice.get("correct", false)):
                correct_selected += 1
            else:
                wrong_selected += 1
    var passed := correct_selected == 3 and wrong_selected == 0 and selected_ids.size() == 3
    if passed:
        evaluation_passed = true
        last_feedback = "Você priorizou segurança, continuidade operacional e comunicação."
    else:
        retry_after_completed_days = completed_days(workday_manager) + 1
        last_feedback = "A avaliação não foi aprovada. Conclua mais um expediente antes de tentar novamente."
    return {"passed":passed,"correct":correct_selected,"wrong":wrong_selected,"feedback":last_feedback}

func promote_to_junior(current_role:String) -> Dictionary:
    if current_role != ROLE_ASSISTANT or not evaluation_passed:
        return {}
    return {"role":ROLE_JUNIOR,"salary":3200,"title":"Analista Jr"}

func export_state() -> Dictionary:
    return {
        "evaluation_attempts":evaluation_attempts,
        "evaluation_passed":evaluation_passed,
        "retry_after_completed_days":retry_after_completed_days,
        "last_feedback":last_feedback
    }

func import_state(data:Dictionary) -> void:
    evaluation_attempts = int(data.get("evaluation_attempts",0))
    evaluation_passed = bool(data.get("evaluation_passed",false))
    retry_after_completed_days = int(data.get("retry_after_completed_days",0))
    last_feedback = str(data.get("last_feedback",""))
