extends Node
class_name LifeCycleManager

const PHASE_WORK := "work"
const PHASE_HOME := "home"
const PHASE_MORNING := "morning"

var phase := PHASE_WORK
var display_day := "SEGUNDA-FEIRA"
var display_week := 1
var time_label := "07:45"
var weekend_stage := 0 # 0=sem fim de semana, 1=sexta à noite, 2=sábado, 3=domingo
var evening_actions := 0
var last_summary := {}

func begin_evening(summary:Dictionary) -> void:
    phase = PHASE_HOME
    display_day = str(summary.get("day_label", display_day))
    display_week = int(summary.get("week", display_week))
    time_label = "18:10"
    evening_actions = 0
    last_summary = summary.duplicate(true)
    weekend_stage = 1 if bool(summary.get("weekly_close", false)) else 0

func register_evening_action(new_time:String="20:10") -> void:
    evening_actions += 1
    time_label = new_time

func sleep_and_advance(next_workday:String, next_week:int) -> String:
    evening_actions = 0
    if weekend_stage == 1:
        weekend_stage = 2
        phase = PHASE_HOME
        display_day = "SÁBADO"
        time_label = "09:00"
        return "saturday"
    if weekend_stage == 2:
        weekend_stage = 3
        phase = PHASE_HOME
        display_day = "DOMINGO"
        time_label = "09:30"
        return "sunday"
    weekend_stage = 0
    phase = PHASE_MORNING
    display_day = next_workday
    display_week = next_week
    time_label = "06:30"
    return "work_morning"

func begin_workday(day_label:String, week_number:int) -> void:
    phase = PHASE_WORK
    display_day = day_label
    display_week = week_number
    time_label = "07:45"
    weekend_stage = 0
    evening_actions = 0

func is_weekend() -> bool:
    return weekend_stage >= 2

func day_short(day_label:String="") -> String:
    var value := day_label if day_label != "" else display_day
    match value:
        "SEGUNDA-FEIRA": return "SEG"
        "TERÇA-FEIRA": return "TER"
        "QUARTA-FEIRA": return "QUA"
        "QUINTA-FEIRA": return "QUI"
        "SEXTA-FEIRA": return "SEX"
        "SÁBADO": return "SÁB"
        "DOMINGO": return "DOM"
        _: return value.left(3).to_upper()

func export_state() -> Dictionary:
    return {
        "phase": phase,
        "display_day": display_day,
        "display_week": display_week,
        "time_label": time_label,
        "weekend_stage": weekend_stage,
        "evening_actions": evening_actions,
        "last_summary": last_summary
    }

func import_state(data:Dictionary) -> void:
    if data.is_empty():
        phase = PHASE_WORK
        display_day = "SEGUNDA-FEIRA"
        display_week = 1
        time_label = "07:45"
        weekend_stage = 0
        evening_actions = 0
        last_summary = {}
        return
    phase = str(data.get("phase", PHASE_WORK))
    display_day = str(data.get("display_day", "SEGUNDA-FEIRA"))
    display_week = max(1, int(data.get("display_week", 1)))
    time_label = str(data.get("time_label", "07:45"))
    weekend_stage = clampi(int(data.get("weekend_stage", 0)), 0, 3)
    evening_actions = max(0, int(data.get("evening_actions", 0)))
    last_summary = data.get("last_summary", {})
