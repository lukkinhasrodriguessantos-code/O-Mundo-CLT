extends Node
class_name PersonalLifeManager

var day_actions := {}
var day_unique_actions := {}
var weekend_event_weeks := {}
var prepared_for_week := 0
var total_personal_actions := 0
var activity_history:Array = []

func _day_key(week_number:int, day_label:String) -> String:
    return "%d|%s" % [maxi(1, week_number), day_label]

func max_actions_for_day(day_label:String) -> int:
    match day_label:
        "SÁBADO": return 3
        "DOMINGO": return 2
        _: return 2

func used_actions(week_number:int, day_label:String) -> int:
    return int(day_actions.get(_day_key(week_number, day_label), 0))

func remaining_actions(week_number:int, day_label:String) -> int:
    return maxi(0, max_actions_for_day(day_label) - used_actions(week_number, day_label))

func has_done(week_number:int, day_label:String, action_id:String) -> bool:
    var actions:Array = day_unique_actions.get(_day_key(week_number, day_label), [])
    return actions.has(action_id)

func try_action(week_number:int, day_label:String, action_id:String, consume_slot:bool=true, unique:bool=true) -> Dictionary:
    var key := _day_key(week_number, day_label)
    if unique and has_done(week_number, day_label, action_id):
        return {"ok":false,"message":"Essa atividade já foi feita hoje."}
    if consume_slot and remaining_actions(week_number, day_label) <= 0:
        return {"ok":false,"message":"Seu tempo livre de hoje acabou. Descanse para continuar amanhã."}

    if consume_slot:
        day_actions[key] = int(day_actions.get(key, 0)) + 1
    if unique:
        var actions:Array = day_unique_actions.get(key, []).duplicate()
        actions.append(action_id)
        day_unique_actions[key] = actions
    total_personal_actions += 1
    activity_history.push_front({"week":week_number,"day":day_label,"action":action_id,"uses_slot":consume_slot})
    if activity_history.size() > 40:
        activity_history.resize(40)
    return {"ok":true,"remaining":remaining_actions(week_number, day_label)}

func weekend_event_available(week_number:int) -> bool:
    return not bool(weekend_event_weeks.get(str(week_number), false))

func mark_weekend_event(week_number:int) -> void:
    weekend_event_weeks[str(week_number)] = true

func prepare_week(week_number:int) -> bool:
    if prepared_for_week == week_number:
        return false
    prepared_for_week = week_number
    return true

func is_week_prepared(week_number:int) -> bool:
    return prepared_for_week == week_number

func consume_week_preparation(week_number:int) -> bool:
    if prepared_for_week != week_number:
        return false
    prepared_for_week = 0
    return true

func status_text(week_number:int, day_label:String) -> String:
    return "🕒 Tempo livre: %d/%d atividades restantes" % [remaining_actions(week_number, day_label), max_actions_for_day(day_label)]

func export_state() -> Dictionary:
    return {
        "day_actions":day_actions,
        "day_unique_actions":day_unique_actions,
        "weekend_event_weeks":weekend_event_weeks,
        "prepared_for_week":prepared_for_week,
        "total_personal_actions":total_personal_actions,
        "activity_history":activity_history
    }

func import_state(data:Dictionary) -> void:
    if data.is_empty():
        day_actions = {}
        day_unique_actions = {}
        weekend_event_weeks = {}
        prepared_for_week = 0
        total_personal_actions = 0
        activity_history = []
        return
    day_actions = data.get("day_actions", {})
    day_unique_actions = data.get("day_unique_actions", {})
    weekend_event_weeks = data.get("weekend_event_weeks", {})
    prepared_for_week = maxi(0, int(data.get("prepared_for_week", 0)))
    total_personal_actions = maxi(0, int(data.get("total_personal_actions", 0)))
    activity_history = data.get("activity_history", [])
