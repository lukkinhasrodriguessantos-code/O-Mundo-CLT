extends Node
class_name GameSettingsManager

const SETTINGS_PATH := "user://game_settings.json"

var graphics_preset := "Médio"
var fps_cap := 60
var shadows_enabled := true
var camera_sensitivity := 2.2
var touch_scale := 1.0
var vibration_enabled := true
var invert_camera := false

func _ready() -> void:
    load_settings()
    apply_runtime_settings()

func render_scale() -> float:
    match graphics_preset:
        "Baixo": return 0.75
        "Alto": return 1.0
        _: return 0.88

func apply_runtime_settings() -> void:
    Engine.max_fps = fps_cap
    get_viewport().set("scaling_3d_scale", render_scale())

func apply_scene_graphics(root: Node) -> void:
    if root is Light3D:
        root.shadow_enabled = shadows_enabled
    for child in root.get_children():
        apply_scene_graphics(child)

func set_graphics_preset(value: String) -> void:
    graphics_preset = value if value in ["Baixo", "Médio", "Alto"] else "Médio"
    apply_runtime_settings()
    save_settings()

func set_fps_cap(value: int) -> void:
    fps_cap = 30 if value <= 30 else 60
    apply_runtime_settings()
    save_settings()

func set_shadows(enabled: bool) -> void:
    shadows_enabled = enabled
    if get_tree().current_scene:
        apply_scene_graphics(get_tree().current_scene)
    save_settings()

func set_camera_sensitivity(value: float) -> void:
    camera_sensitivity = clamp(value, 0.8, 4.0)
    save_settings()

func set_touch_scale(value: float) -> void:
    touch_scale = clamp(value, 0.85, 1.30)
    save_settings()

func set_vibration(enabled: bool) -> void:
    vibration_enabled = enabled
    save_settings()

func set_invert_camera(enabled: bool) -> void:
    invert_camera = enabled
    save_settings()

func vibrate(duration_ms := 25) -> void:
    if vibration_enabled and OS.get_name() in ["Android", "iOS"]:
        Input.vibrate_handheld(duration_ms)

func reset_defaults() -> void:
    graphics_preset = "Médio"
    fps_cap = 60
    shadows_enabled = true
    camera_sensitivity = 2.2
    touch_scale = 1.0
    vibration_enabled = true
    invert_camera = false
    apply_runtime_settings()
    save_settings()

func export_state() -> Dictionary:
    return {
        "graphics_preset": graphics_preset,
        "fps_cap": fps_cap,
        "shadows_enabled": shadows_enabled,
        "camera_sensitivity": camera_sensitivity,
        "touch_scale": touch_scale,
        "vibration_enabled": vibration_enabled,
        "invert_camera": invert_camera
    }

func save_settings() -> void:
    var f := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(export_state()))

func load_settings() -> void:
    if not FileAccess.file_exists(SETTINGS_PATH):
        return
    var f := FileAccess.open(SETTINGS_PATH, FileAccess.READ)
    if not f:
        return
    var data = JSON.parse_string(f.get_as_text())
    if typeof(data) != TYPE_DICTIONARY:
        return
    graphics_preset = str(data.get("graphics_preset", graphics_preset))
    if graphics_preset not in ["Baixo", "Médio", "Alto"]: graphics_preset = "Médio"
    fps_cap = 30 if int(data.get("fps_cap", fps_cap)) <= 30 else 60
    shadows_enabled = bool(data.get("shadows_enabled", shadows_enabled))
    camera_sensitivity = clamp(float(data.get("camera_sensitivity", camera_sensitivity)), 0.8, 4.0)
    touch_scale = clamp(float(data.get("touch_scale", touch_scale)), 0.85, 1.30)
    vibration_enabled = bool(data.get("vibration_enabled", vibration_enabled))
    invert_camera = bool(data.get("invert_camera", invert_camera))
