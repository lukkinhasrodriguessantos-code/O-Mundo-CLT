extends Control

const MAIN_SCENE := "res://scenes/Main.tscn"
const MENU_SCENE := "res://scenes/MainMenu.tscn"
const BG_PATH := "res://assets/backgrounds/menu_lr_global.png"

var progress_label: Label
var detail_label: Label
var request_started := false
var finished := false

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    get_tree().paused = false
    _build_ui()
    _ensure_request()

func _process(_delta: float) -> void:
    if finished:
        return
    var progress: Array = []
    var status = ResourceLoader.load_threaded_get_status(MAIN_SCENE, progress)
    if status == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
        if progress.size() > 0:
            progress_label.text = "Preparando expediente... %d%%" % int(float(progress[0]) * 100.0)
        return
    if status == ResourceLoader.THREAD_LOAD_LOADED:
        finished = true
        var packed = ResourceLoader.load_threaded_get(MAIN_SCENE) as PackedScene
        if packed == null:
            _show_error("Não foi possível abrir o jogo.")
            return
        get_tree().change_scene_to_packed(packed)
        return
    if status == ResourceLoader.THREAD_LOAD_FAILED or status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
        if not request_started:
            _ensure_request()
        else:
            _show_error("Não foi possível preparar o expediente.")

func _ensure_request() -> void:
    var status = ResourceLoader.load_threaded_get_status(MAIN_SCENE)
    if status == ResourceLoader.THREAD_LOAD_IN_PROGRESS or status == ResourceLoader.THREAD_LOAD_LOADED:
        request_started = true
        return
    var err = ResourceLoader.load_threaded_request(MAIN_SCENE)
    request_started = err == OK
    if not request_started:
        _show_error("Falha ao iniciar o carregamento do jogo.")

func _build_ui() -> void:
    var tex = load(BG_PATH) as Texture2D
    var image = TextureRect.new()
    image.texture = tex
    image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    image.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(image)

    var shade = ColorRect.new()
    shade.color = Color(0.002, 0.008, 0.02, 0.72)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(shade)

    var center = CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(center)

    var box = VBoxContainer.new()
    box.custom_minimum_size = Vector2(650, 210)
    box.alignment = BoxContainer.ALIGNMENT_CENTER
    box.add_theme_constant_override("separation", 12)
    center.add_child(box)

    var title = Label.new()
    title.text = "O MUNDO CLT"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 40)
    box.add_child(title)

    progress_label = Label.new()
    progress_label.text = "Preparando expediente..."
    progress_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    progress_label.add_theme_font_size_override("font_size", 20)
    box.add_child(progress_label)

    detail_label = Label.new()
    detail_label.text = "Carregando os sistemas da LR Global"
    detail_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    detail_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    detail_label.modulate = Color(1, 1, 1, 0.72)
    box.add_child(detail_label)

    var back = Button.new()
    back.text = "VOLTAR AO MENU"
    back.custom_minimum_size = Vector2(300, 46)
    back.pressed.connect(func(): get_tree().change_scene_to_file(MENU_SCENE))
    box.add_child(back)

func _show_error(message: String) -> void:
    finished = true
    progress_label.text = "Não foi possível iniciar agora"
    detail_label.text = message + " Volte ao menu e tente novamente."

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        get_tree().change_scene_to_file(MENU_SCENE)
