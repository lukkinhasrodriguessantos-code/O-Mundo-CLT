# O MUNDO CLT — Preparação Android Alpha

Esta revisão prepara o projeto para a exportação Android, mas **não contém um APK compilado**.

## Identidade preparada
- App: O Mundo CLT
- Studio: LVSR Games
- Package ID de desenvolvimento: `com.lvsrgames.omundoclt`
- Arquitetura inicial: ARM64
- Orientação: paisagem
- Renderer: GL Compatibility
- Meta inicial: 30/60 FPS configurável

## Antes da primeira exportação
1. Abrir o projeto em uma versão compatível do Godot 4.
2. Instalar os Export Templates correspondentes à mesma versão do Godot.
3. Configurar o Android SDK/JDK no editor.
4. Abrir Project > Export > Android Alpha e conferir o preset.
5. Para o primeiro teste local, gerar um APK de debug.
6. Instalar no aparelho e testar: Novo Jogo, Continuar, save/backup, botão Voltar, touch, 30/60 FPS, áudio e retomada após minimizar o app.

## Segurança de progresso adicionada na v0.29.2
O save principal usa gravação temporária e mantém uma cópia `.bak`. Se o JSON principal não puder ser lido, o jogo tenta recuperar o backup automaticamente.

## Observação
Antes de publicação comercial, o Package ID, assinatura, ícone final, permissões e dados da Play Store devem ser revisados.

## Smoke test obrigatório antes de chamar a build de v0.30
- Abrir o menu e conferir `Pré-Alpha: OK`.
- Criar Novo Jogo e concluir a contratação.
- Finalizar o tutorial do primeiro dia e salvar.
- Fechar/reabrir e usar Continuar.
- Abrir Configurações e alternar 30/60 FPS, qualidade e volumes.
- Minimizar o app e retornar sem perder progresso.
- Testar botão Voltar do Android em painel, gameplay e menu.
- Abrir Loja e Resgatar Código com campanha ativa.
- Concluir ao menos um expediente dinâmico e conferir o resumo.
- Ir para casa, dormir e validar mudança de dia.
- Conferir Diagnóstico Alpha e testar Save Seguro.
- Confirmar que todos os veículos exibem somente códigos de frota fictícios.
