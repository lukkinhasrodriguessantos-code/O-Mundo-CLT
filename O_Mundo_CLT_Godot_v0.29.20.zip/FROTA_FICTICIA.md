# Frota Fictícia — LR Global Logística

Os identificadores abaixo são **códigos internos de frota do universo do jogo**. Eles não representam placas oficiais de trânsito nem veículos reais.

## Padrão oficial
- LVS-001 a LVS-004
- VSR-101 a VSR-104
- LRG-201 a LRG-204
- LSR-301 a LSR-304
- RGL-401 a RGL-404

## Catálogo completo
1. LVS-001
2. LVS-002
3. LVS-003
4. LVS-004
5. VSR-101
6. VSR-102
7. VSR-103
8. VSR-104
9. LRG-201
10. LRG-202
11. LRG-203
12. LRG-204
13. LSR-301
14. LSR-302
15. LSR-303
16. LSR-304
17. RGL-401
18. RGL-402
19. RGL-403
20. RGL-404

Fonte única no código: `scripts/fleet_catalog.gd`.
