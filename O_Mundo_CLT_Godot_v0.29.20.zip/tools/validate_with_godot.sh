#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GODOT_BIN="${GODOT_BIN:-godot}"
if ! command -v "$GODOT_BIN" >/dev/null 2>&1 && [ ! -x "$GODOT_BIN" ]; then
  echo "ERRO: Godot não encontrado. Defina GODOT_BIN=/caminho/para/Godot_v4.7.2-stable_linux.x86_64"
  exit 2
fi
python3 "$ROOT/tools/preflight_check.py"
LOG="$(mktemp)"
trap 'rm -f "$LOG"' EXIT
set +e
"$GODOT_BIN" --headless --editor --path "$ROOT" --quit 2>&1 | tee "$LOG"
STATUS=${PIPESTATUS[0]}
set -e
if [ "$STATUS" -ne 0 ]; then
  echo "ERRO: Godot retornou código $STATUS durante importação."
  exit "$STATUS"
fi
if grep -Eqi 'SCRIPT ERROR|Parse Error|Compile Error|Failed to load script|Cannot load script' "$LOG"; then
  echo "ERRO: Godot encontrou erro de script durante importação."
  exit 1
fi
printf 'OK: Godot abriu/importou o projeto sem erros de script detectados.\n'
