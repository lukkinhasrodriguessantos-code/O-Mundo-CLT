extends SceneTree

const SCENES := [
    "res://scenes/Boot.tscn",
    "res://scenes/MainMenu.tscn",
    "res://scenes/NewGame.tscn",
    "res://scenes/Hiring.tscn",
    "res://scenes/RuntimeLoader.tscn",
    "res://scenes/Main.tscn"
]

func _initialize() -> void:
    for path in SCENES:
        var packed = load(path) as PackedScene
        if packed == null:
            push_error("SMOKE TEST: falha ao carregar " + path)
            quit(1)
            return
        var instance = packed.instantiate()
        if instance == null:
            push_error("SMOKE TEST: falha ao instanciar " + path)
            quit(1)
            return
        instance.free()
        print("SMOKE TEST OK: ", path)
    print("SMOKE TEST COMPLETO: todas as cenas principais carregam")
    quit(0)
