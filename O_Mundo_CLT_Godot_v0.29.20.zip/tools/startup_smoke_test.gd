extends SceneTree

const SCENES := [
    "res://scenes/Boot.tscn",
    "res://scenes/MainMenu.tscn",
    "res://scenes/NewGame.tscn",
    "res://scenes/Hiring.tscn",
    "res://scenes/RuntimeLoader.tscn",
    "res://scenes/Main.tscn"
]

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    for path in SCENES:
        var packed = load(path) as PackedScene
        if packed == null:
            _fail("falha ao carregar " + path)
            return

        var instance = packed.instantiate()
        if instance == null:
            _fail("falha ao instanciar " + path)
            return

        if path.ends_with("RuntimeLoader.tscn"):
            instance.set_process(false)
        root.add_child(instance)
        await process_frame
        await process_frame

        if path.ends_with("MainMenu.tscn") and _count_buttons(instance) < 6:
            _fail("menu principal não criou os seis botões")
            return

        if path.ends_with("Main.tscn") and instance.get("workday_manager") == null:
            _fail("Main abriu sem os managers essenciais")
            return

        instance.queue_free()
        await process_frame
        print("SMOKE TEST OK: ", path)

    print("SMOKE TEST COMPLETO: abertura, menu e fluxo principal inicializam")
    quit(0)

func _count_buttons(node: Node) -> int:
    var total := 1 if node is Button else 0
    for child in node.get_children():
        total += _count_buttons(child)
    return total

func _fail(message: String) -> void:
    push_error("SMOKE TEST: " + message)
    quit(1)
