#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GODOT_BIN="${GODOT_BIN:-godot}"
VERSION="$(python3 - <<'PY' "$ROOT/project.godot"
import re,sys
text=open(sys.argv[1],encoding='utf-8').read()
m=re.search(r'config/version="([^"]+)"',text)
print(m.group(1) if m else '')
PY
)"
OUT="$ROOT/build/android/O_Mundo_CLT_Alpha_v${VERSION}.apk"
if [ -z "$VERSION" ]; then echo 'ERRO: versão não encontrada'; exit 2; fi
if ! command -v "$GODOT_BIN" >/dev/null 2>&1 && [ ! -x "$GODOT_BIN" ]; then
  echo "ERRO: Godot não encontrado. Defina GODOT_BIN para o executável Godot 4.7.2."
  exit 2
fi
python3 "$ROOT/tools/preflight_check.py"
mkdir -p "$ROOT/build/android"
"$GODOT_BIN" --headless --path "$ROOT" --export-debug "Android Alpha" "$OUT"
test -s "$OUT"
printf 'APK gerado: %s\n' "$OUT"
