#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, re, time
ROOT=Path(__file__).resolve().parents[1]
project=(ROOT/'project.godot').read_text(encoding='utf-8')
m=re.search(r'config/version="([^"]+)"',project)
version=m.group(1) if m else 'unknown'
items=[]
for path in sorted(ROOT.rglob('*')):
    if not path.is_file():
        continue
    rel=path.relative_to(ROOT).as_posix()
    if rel.startswith('.godot/') or rel.startswith('build/') or rel=='BUILD_MANIFEST.json' or rel.endswith('__pycache__'):
        continue
    data=path.read_bytes()
    items.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
payload={
    'project':'O Mundo CLT',
    'version':version,
    'generated_unix':int(time.time()),
    'file_count':len(items),
    'files':items,
}
(ROOT/'BUILD_MANIFEST.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
print(f"Manifesto criado: v{version} • {len(items)} arquivos")
