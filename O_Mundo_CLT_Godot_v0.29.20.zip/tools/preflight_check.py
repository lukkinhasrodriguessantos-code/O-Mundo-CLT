#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
errors=[]; warnings=[]
required=["assets/audio/menu_theme.wav","assets/backgrounds/intro_lr_global.png","assets/backgrounds/menu_final.png","project.godot","export_presets.cfg","scenes/Boot.tscn","scenes/MainMenu.tscn","scenes/NewGame.tscn","scenes/Hiring.tscn","scenes/RuntimeLoader.tscn","scenes/Main.tscn","scripts/boot.gd","scripts/main_menu.gd","scripts/new_game.gd","scripts/hiring.gd","scripts/runtime_loader.gd","scripts/main.gd","scripts/alpha_health_manager.gd","scripts/alpha_session_manager.gd","scripts/alpha_self_test_manager.gd","scripts/fleet_catalog.gd","tools/validate_with_godot.sh","tools/build_android_alpha.sh","tools/startup_smoke_test.gd","tools/make_build_manifest.py","BUILD_MANIFEST.json"]
for rel in required:
    if not (ROOT/rel).exists(): errors.append(f"arquivo obrigatório ausente: {rel}")
project=(ROOT/'project.godot').read_text(encoding='utf-8')
export=(ROOT/'export_presets.cfg').read_text(encoding='utf-8')

if 'AudioManager="*res://scripts/audio_manager.gd"' not in project:
    errors.append('AudioManager não está configurado como Autoload')

# startup/menu routing
if 'run/main_scene="res://scenes/Boot.tscn"' not in project:
    errors.append('Boot.tscn não está definido como cena inicial')
if 'boot_splash/show_image=false' not in project:
    errors.append('splash padrão do Godot não está desativado')
intro=(ROOT/'assets/backgrounds/intro_lr_global.png').read_bytes() if (ROOT/'assets/backgrounds/intro_lr_global.png').exists() else b''
menu=(ROOT/'assets/backgrounds/menu_final.png').read_bytes() if (ROOT/'assets/backgrounds/menu_final.png').exists() else b''
if intro and menu and intro==menu:
    errors.append('imagem da abertura e imagem do menu são idênticas')
if not (ROOT/'assets/audio/menu_theme.wav').exists() or (ROOT/'assets/audio/menu_theme.wav').stat().st_size < 1000:
    errors.append('trilha de menu ausente ou vazia')
m=re.search(r'config/version="([^"]+)"',project); version=m.group(1) if m else ''
if not version: errors.append('versão não encontrada em project.godot')
if version and f'version/name="{version}-alpha"' not in export: errors.append('version/name do Android não corresponde ao project.godot')
if version and f'O_Mundo_CLT_Alpha_v{version}.apk' not in export: errors.append('nome do APK no preset não corresponde à versão')
text='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in ROOT.rglob('*') if p.is_file() and p.suffix.lower() in {'.gd','.tscn','.cfg','.md','.godot'} and 'tools' not in p.parts)
for blocked in ['Multilog','@multilog.com.br']:
    if blocked.lower() in text.lower(): errors.append(f'dado real bloqueado encontrado: {blocked}')
ui_scripts='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in (ROOT/'scripts').rglob('*.gd'))
for blocked_message in ['menu de segurança','inicialização demorou','carregamento está demorando']:
    if blocked_message.lower() in ui_scripts.lower():
        errors.append(f'mensagem técnica visível bloqueada: {blocked_message}')
# Mercosul AAA1A23 / padrão antigo AAA1234 ou AAA-1234
patterns=[r'\b[A-Z]{3}[0-9][A-Z][0-9]{2}\b',r'\b[A-Z]{3}-?[0-9]{4}\b']
for pat in patterns:
    hits=sorted(set(re.findall(pat,text)))
    if hits: errors.append('padrão de placa brasileira encontrado: '+', '.join(hits[:10]))
# res:// refs
for gd in ROOT.rglob('*.gd'):
    content=gd.read_text(encoding='utf-8',errors='ignore')
    for ref in re.findall(r'res://[A-Za-z0-9_./ -]+',content):
        rel=ref[6:].rstrip('"\')],;} ')
        if rel and not (ROOT/rel).exists(): errors.append(f'referência ausente em {gd.relative_to(ROOT)}: res://{rel}')
# duplicate top-level GDScript functions
for gd in ROOT.rglob('*.gd'):
    content=gd.read_text(encoding='utf-8',errors='ignore')
    funcs=re.findall(r'(?m)^func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(',content)
    dupes=sorted({name for name in funcs if funcs.count(name)>1})
    if dupes: errors.append(f'função duplicada em {gd.relative_to(ROOT)}: '+', '.join(dupes))
# app version must agree with main.gd
main_text=(ROOT/'scripts/main.gd').read_text(encoding='utf-8',errors='ignore')
app_version=re.search(r'const\s+APP_VERSION\s*:=\s*"([^"]+)"',main_text)
if version and (not app_version or app_version.group(1)!=version):
    errors.append('APP_VERSION em main.gd não corresponde ao project.godot')
# hardcoded local/windows paths
for pat in [r'[A-Za-z]:\\(?:Users|Desktop|Documents|Downloads|Projects|Temp|Windows|Program Files)\\[^\n\r\"]+',r'/home/[^\n\r\"]+']:
    if re.search(pat,text): warnings.append('caminho local absoluto encontrado no conteúdo')
print(f'O MUNDO CLT preflight — v{version or "?"}')
for w in warnings: print('AVISO:',w)
for e in errors: print('ERRO:',e)
if errors:
    print(f'FALHOU: {len(errors)} erro(s), {len(warnings)} aviso(s)')
    sys.exit(1)
print(f'OK: {len(warnings)} aviso(s)')
