extends Node

const SETTINGS_PATH := "user://audio_settings.json"
var current_context := ""
var volumes := {"master":100.0,"music":70.0,"sfx":80.0,"voice":85.0,"ambient":65.0}
var music_player: AudioStreamPlayer
var ambient_player: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var voice_player: AudioStreamPlayer

func _ready() -> void:
    music_player=AudioStreamPlayer.new(); music_player.name="Music"; add_child(music_player)
    ambient_player=AudioStreamPlayer.new(); ambient_player.name="Ambient"; add_child(ambient_player)
    sfx_player=AudioStreamPlayer.new(); sfx_player.name="SFX"; add_child(sfx_player)
    voice_player=AudioStreamPlayer.new(); voice_player.name="Voice"; add_child(voice_player)
    _load_settings(); _apply_volumes()

func set_context(context:String) -> void:
    if context==current_context: return
    current_context=context
    # v0.25 establishes dynamic routing. Original commercial-safe tracks plug in here later.
    print("[AUDIO] Contexto: ",context," | trilha preparada: ",track_name(context))

func track_name(context:String) -> String:
    return {"menu":"Tema O Mundo CLT","work":"Expediente LR Global","home":"Fim de Expediente","city":"Cidade Depois das 18"}.get(context,"Ambiente LR Global")

func play_stinger(kind:String) -> void:
    print("[AUDIO] Vinheta: ",kind)

func get_volume(channel:String) -> float:
    return float(volumes.get(channel,70.0))

func set_volume(channel:String,value:float) -> void:
    volumes[channel]=clamp(value,0.0,100.0); _apply_volumes(); _save_settings()

func _db(value:float) -> float:
    return -80.0 if value<=0.0 else linear_to_db(value/100.0)

func _apply_volumes() -> void:
    var master := float(volumes.get("master",100.0)) / 100.0
    if music_player: music_player.volume_db=_db(float(volumes.music) * master)
    if sfx_player: sfx_player.volume_db=_db(float(volumes.sfx) * master)
    if voice_player: voice_player.volume_db=_db(float(volumes.voice) * master)
    if ambient_player: ambient_player.volume_db=_db(float(volumes.ambient) * master)

func reset_defaults() -> void:
    volumes = {"master":100.0,"music":70.0,"sfx":80.0,"voice":85.0,"ambient":65.0}
    _apply_volumes()
    _save_settings()

func _save_settings() -> void:
    var f=FileAccess.open(SETTINGS_PATH,FileAccess.WRITE)
    if f: f.store_string(JSON.stringify(volumes))

func _load_settings() -> void:
    if not FileAccess.file_exists(SETTINGS_PATH): return
    var f=FileAccess.open(SETTINGS_PATH,FileAccess.READ)
    if not f: return
    var data=JSON.parse_string(f.get_as_text())
    if typeof(data)==TYPE_DICTIONARY:
        for k in volumes.keys(): volumes[k]=float(data.get(k,volumes[k]))
