# Build Info — O MUNDO CLT v0.29.18

## v0.29.18 — Correção da tela cinza no Android

- Parte da v0.29.16 e mantém imagem, música, menu, save e demais sistemas existentes.
- A cena de `Boot.tscn` volta a ser a entrada resiliente do APK, mantendo a arte visível enquanto a interface principal é preparada.
- A splash interna do Godot continua desativada (`boot_splash/show_image=false`).
- `main.gd` deixou de depender do cache global de `class_name` para os managers no primeiro carregamento; todos os scripts essenciais são pré-carregados explicitamente.
- Alias `FleetCatalog` duplicado foi removido/renomeado nos scripts que o utilizavam.
- A abertura é desenhada antes da inicialização dos managers, evitando a tela cinza caso algum sistema demore ou falhe durante o primeiro frame.
- A criação dos managers ocorre de forma adiada, no frame seguinte.
- O menu espera os managers ficarem prontos antes de montar os controles.
- Timer da abertura e guardião continuam em `PROCESS_MODE_ALWAYS`.
- Ícones Android personalizados e trilha de abertura foram preservados.

Fluxo esperado: iniciar APK → arte de abertura + música → vinheta → menu principal.
