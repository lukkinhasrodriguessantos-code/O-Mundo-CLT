extends Control

@onready var status_label: Label = $LoadingOverlay/Center/Box/Status
@onready var overlay: ColorRect = $LoadingOverlay

var main_instance: Node = null
var loading_tick := 0
var loading_timer: Timer
var watchdog: Timer

func _ready() -> void:
    _install_boot_background()
    _start_loading_animation()
    print("[BOOT] Cena de carregamento pronta")
    await get_tree().process_frame

    var packed := load("res://scenes/Main.tscn") as PackedScene
    if packed == null:
        status_label.text = "Não foi possível iniciar o jogo"
        push_error("[BOOT] Main.tscn não pôde ser carregada")
        return

    main_instance = packed.instantiate()
    if main_instance == null:
        status_label.text = "Não foi possível iniciar o jogo"
        push_error("[BOOT] Main.tscn não pôde ser instanciada")
        return

    add_child(main_instance)
    print("[BOOT] Main adicionada à árvore")
    _start_watchdog()

func mark_game_ready() -> void:
    print("[BOOT] Interface principal sinalizou pronto")
    _hide_loading_overlay()

func _hide_loading_overlay() -> void:
    if loading_timer != null:
        loading_timer.stop()
    if watchdog != null:
        watchdog.stop()
    if overlay != null and is_instance_valid(overlay):
        overlay.visible = false

func _start_watchdog() -> void:
    watchdog = Timer.new()
    watchdog.one_shot = true
    watchdog.wait_time = 5.0
    add_child(watchdog)
    watchdog.timeout.connect(_on_watchdog_timeout)
    watchdog.start()

func _on_watchdog_timeout() -> void:
    if overlay == null or not overlay.visible:
        return
    push_warning("[BOOT] Watchdog acionado")
    if main_instance != null and is_instance_valid(main_instance) and main_instance.has_method("force_open_menu"):
        main_instance.call_deferred("force_open_menu")
        await get_tree().create_timer(0.35).timeout
        _hide_loading_overlay()
        return

    # Se a Main perdeu o script por erro de parse/carregamento, não escondemos
    # o overlay e não deixamos o jogador olhando uma imagem parada sem explicação.
    status_label.text = "Falha ao iniciar a interface"
    push_error("[BOOT] Main não expôs force_open_menu; script provavelmente não carregou")

func _start_loading_animation() -> void:
    loading_timer = Timer.new()
    loading_timer.wait_time = 0.45
    loading_timer.one_shot = false
    add_child(loading_timer)
    loading_timer.timeout.connect(_animate_loading)
    loading_timer.start()

func _animate_loading() -> void:
    loading_tick = (loading_tick + 1) % 4
    status_label.text = "Carregando" + ".".repeat(loading_tick)

func _install_boot_background() -> void:
    var tex := load("res://assets/backgrounds/intro_lr_global.png") as Texture2D
    if tex == null:
        return

    # Camada de preenchimento para telas ultrawide. Ela ocupa as bordas extras
    # sem obrigar a imagem principal a dar zoom e cortar a fachada.
    var fill := TextureRect.new()
    fill.name = "BootBackgroundFill"
    fill.texture = tex
    fill.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    fill.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    fill.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    fill.modulate = Color(0.42, 0.42, 0.48, 1.0)
    add_child(fill)

    # Imagem principal preserva o quadro completo: logo, faixa e personagem.
    var bg := TextureRect.new()
    bg.name = "BootBackground"
    bg.texture = tex
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bg.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    add_child(bg)

    move_child(fill, 0)
    move_child(bg, 1)
