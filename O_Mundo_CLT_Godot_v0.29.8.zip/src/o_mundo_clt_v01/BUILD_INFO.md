# Build Info — O MUNDO CLT v0.29.8

- Status: Pré-APK / preparação Android
- Engine alvo: Godot 4.x
- Renderer: GL Compatibility
- Orientação: paisagem
- Arquitetura Android preparada: ARM64
- Package ID de desenvolvimento: `com.lvsrgames.omundoclt`
- Save seguro: arquivo temporário + backup automático
- Autosave mobile: ao pausar o aplicativo
- Botão Voltar: fecha overlay; em gameplay/casa salva e retorna ao menu
- Diagnóstico Alpha: disponível em Configurações

## Limitação desta build
O ZIP foi validado estruturalmente e por integridade, mas não foi executado dentro do editor Godot neste ambiente. O APK ainda não foi compilado.

## Privacidade da frota — v0.29.3
- Removidos identificadores que coincidiam com placas reais/realistas do protótipo.
- Frota passou a usar códigos fictícios próprios da LR Global: LVS, VSR, LRG, LSR e RGL.
- Catálogo central em `scripts/fleet_catalog.gd` com 20 códigos fictícios.
- Os códigos são identificadores de frota do universo do jogo, não placas oficiais de trânsito.


## QA v0.29.4
- Diagnóstico automático em runtime adicionado.
- Preflight estático incluído em `tools/preflight_check.py`.
- Objetivo: transformar a v0.29.4 em candidata de base para a primeira compilação v0.30 Alpha.

## Pré-Alpha v0.29.6
- Abertura de boot integrada: LVSR Games → O MUNDO CLT → criação de Lucas Rodrigues → menu.
- Abertura pode ser pulada.
- Diagnóstico Alpha passa a registrar a versão real da engine em runtime.
- Esta versão continua sendo fonte pré-APK; v0.30 só será usada após compilação Android real.


## v0.29.6
Checkpoint pré-APK com menu de pausa e proteção extra de sessão/save para testes Android.


## v0.29.7 — Inicialização & recuperação de sessão
- Tela curta de inicialização “Preparando LR Global…” antes da abertura.
- Novo `alpha_session_manager.gd` detecta encerramento inesperado da sessão anterior.
- Menu avisa quando a execução anterior terminou de forma brusca e confirma a verificação do save/backup.
- Diagnóstico Alpha mostra FPS medido, contador de inicializações e estado da sessão.
- Saída normal limpa o marcador de sessão; encerramento brusco deixa evidência para a próxima inicialização.


## v0.29.8 — Autoteste e pipeline pré-APK
- Novo `alpha_self_test_manager.gd` executa 9 testes isolados sem alterar o save real.
- Diagnóstico Alpha ganhou botão para executar o autoteste e gerar `user://alpha_self_test_report.json`.
- Testes cobrem frota fictícia, tutorial das 4 áreas, demandas, fechamento de sexta, carreira, fim de semana, primeiro ciclo, melhorias e limites de vida pessoal.
- `tools/validate_with_godot.sh` prepara a validação real em Godot headless quando o executável estiver disponível.
- `tools/build_android_alpha.sh` centraliza a exportação debug Android e falha se a toolchain não estiver pronta.
- v0.30 continua reservada para um APK real compilado e aberto em Android.
