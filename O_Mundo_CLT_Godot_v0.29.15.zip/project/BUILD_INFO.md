# Build Info — O MUNDO CLT v0.29.15

## v0.29.15 — Enquadramento ultrawide corrigido

- Corrige o corte da faixa LR Global na abertura em celulares ultrawide.
- Mantém a arte principal inteira e centralizada.
- Usa uma camada de preenchimento da própria arte nas laterais extras.
- Aplica o mesmo tratamento cinematográfico ao menu principal.
- Mantém ícone Android, música de abertura/menu e boot limpo.
