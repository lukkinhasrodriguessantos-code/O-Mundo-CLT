#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GODOT_BIN="${GODOT_BIN:-godot}"
if ! command -v "$GODOT_BIN" >/dev/null 2>&1 && [ ! -x "$GODOT_BIN" ]; then
  echo "ERRO: Godot não encontrado. Defina GODOT_BIN=/caminho/para/Godot_v4.7.2-stable_linux.x86_64"
  exit 2
fi
python3 "$ROOT/tools/preflight_check.py"
"$GODOT_BIN" --headless --editor --path "$ROOT" --quit
printf 'OK: Godot abriu/importou o projeto em modo headless.\n'
