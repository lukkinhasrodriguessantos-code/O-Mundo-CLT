# O MUNDO CLT — Godot 4 — Alpha v0.29.9

Continuação do protótipo jogável de **O Mundo CLT: Sobrevivendo ao Expediente**, por LVSR Games.

## Novidades v0.9
- Sistema de **Personagens Especiais / Easter Eggs** dentro da LR Global.
- Primeira descoberta de um NPC especial abre um pop-up de recompensa.
- Recompensas únicas em **CLT Coins**; conversar novamente não duplica a recompensa.
- Cada NPC especial possui uma conquista própria.
- Coleção de Easter Eggs acessível pelo celular durante o expediente.
- Personagens ainda não encontrados aparecem como `PERSONAGEM NÃO DESCOBERTO`.
- Primeiros 3 Easter Eggs:
  - Colega da Voz Alta — `NÃO PRECISA GRITAR!` — +50 CLT Coins.
  - Supervisor Fitness — `PROJETO VERÃO` — +75 CLT Coins.
  - Especialista da Frota — `B-B-BEM-VINDO À FROTA` — +50 CLT Coins.
- Contador da coleção: 0/3 até 3/3.
- Mantém toda a progressão v0.8: primeiro dia, kitnet, terça/checklist, quarta/ocorrência e promoção para Analista Jr.

## Observação
Os modelos 3D ainda são proxies/blocos de prototipagem. Personagens, animações, mobiliário e cenários finais serão substituídos progressivamente.

## v0.10 — Easter Eggs & Skins
- Cada personagem especial agora desbloqueia CLT Coins + conquista + skin exclusiva.
- Skins de Easter Egg não são vendidas na Loja.
- Novos personagens especiais: Colega Curioso, Colega Sem Paciência, Colega do Capacete, Atendente dos Áudios e Líder da Rave.
- Easter Egg de dupla: A Brava & O Metido, com recompensa adicional e Jaqueta Treta Corporativa.
- Bordão do Colega da Voz Alta atualizado para “SEMPRE, SEMPRE, SEMPRE!”.
- Coleção do celular ampliada para 8 personagens especiais da unidade Transportes.
- Preparação de arquitetura para futuras skins das Gêmeas que Não São Gêmeas, Coordenadora Gaúcha e Coordenadora da Torre.


## v0.11
- Expansão explorável da Unidade Norte pelo celular.
- Easter Egg duplo “As Gêmeas que Não São Gêmeas”, bordão ARRASOU! e skin fitness exclusiva.
- Devaneios de academia durante o expediente.
- Coordenadora Gaúcha com “QUERO UM CHIMA”, corrida e recompensa CHIMA & 5K.
- Devaneio do Líder da Rave durante o trabalho.
- Primeira visita à Torre de Controle.
- Coordenadora da Torre com conquista É PRA ONTEM! e Skin Executiva da Torre.


## v0.12 — Save/Continue
- Save persistente em `user://mundo_clt_save.json`.
- Botão CONTINUAR habilitado quando existe progresso salvo.
- Persiste nome, área, cargo, XP, reputação, CLT Coins, Easter Eggs e skins.
- Botão Salvar Progresso no celular.
- Descobertas e promoção acionam autosave.
- Novo Jogo limpa o save anterior e inicia uma nova campanha.

## v0.13
- Loja CLT funcional com compra de cosméticos usando CLT Coins.
- Itens comprados entram no inventário persistente e são salvos.
- Easter Egg skins continuam exclusivas e não são vendidas.
- Painel Minha Carreira no celular com XP, reputação e trilha de promoção.
- Promoção permanece vinculada a desempenho/avaliação, nunca compra.


## v0.14
- Sistema de dinheiro em R$ persistente no save.
- Finanças/Holerite no celular.
- Contas da kitnet e pagamento.
- Fechamento de sexta-feira com salário proporcional, benefícios, CLT Coins, XP e reputação.
- Preparação para o loop vida pessoal/fim de semana.

## v0.15
- Vida fora do expediente expandida.
- Hub da cidade com academia, restaurante, orla, loja e arcade.
- Gastos usam R$ do salário, separados de CLT Coins.
- Kitnet ganhou loja de móveis e atributo de conforto persistente.
- Móveis, desbloqueio da cidade e fim de semana entram no save.


## v0.17
- Energia, vida social e afinidade agora persistem no save.
- Progressão de relacionamento: Conhecido(a) → Amizade → Interesse → Namoro.
- Mensagens, convite para café e primeiro encontro com custo/horário/energia.
- Primeiro evento jogável de sábado: Festa na Orla.
- Recompensa de evento e integração com CLT Coins.


## v0.18 — Easter Egg Lendário: O Cara das Planilhas
- Novo NPC: Lucas, Analista de Gestão de Frotas.
- Personalidade: apaixonado por planilhas, dashboards, sites e melhorias; colegas vivem chamando para “só um ajustezinho”.
- O Easter Egg não desbloqueia só ao conversar: é obrigatório escolher **“Preciso de ajuda numa planilha”**.
- Conquista lendária: **SÓ UM AJUSTEZINHO**.
- Recompensas: +150 CLT Coins, traje exclusivo **Gaúcho Tricolor** e veículo lendário **Planilhamóvel**.
- O Planilhamóvel e o traje são persistidos no save e não fazem parte da loja comum.
- Depois da descoberta, Lucas passa a responder: “Se for planilha, já fala logo. 😂”


## v0.19 — Garagem e veículos pessoais
- Concessionária adicionada à cidade.
- Veículos comuns comprados com R$: Moto Urbana 125, Compacto Popular e Sedan Executivo.
- Garagem permite escolher o veículo ativo ou continuar a pé.
- Planilhamóvel permanece exclusivo do Easter Egg lendário do Lucas e não pode ser comprado.
- Veículos, garagem e veículo ativo agora persistem no save.
- Passeio de carro/moto pela cidade afeta energia e vida social.


## v0.20 — Veículos ganham vida
- Combustível individual por veículo.
- Condição/manutenção e quilometragem persistentes no save.
- Abastecimento e revisão pagos com R$ do salário.
- Passeios agora consomem combustível, energia e acumulam km.
- Imprevistos de rua podem acontecer durante deslocamentos.
- Planilhamóvel ganhou evento exclusivo com planilha secreta e bônus de CLT Coins.
- Veículos comprados e o Planilhamóvel recebem status automaticamente.


## v0.21 — Só um ajustezinho
- NPC Lucas virou personagem recorrente após o Easter Egg lendário.
- Nova cadeia de pedidos internos: Coordenadora, Programação e Atendimento chamam para ajustes em planilha/dashboard.
- Cada ajuda rende +8 XP e +2 reputação.
- Após 3 ajudas: conquista secreta SUPORTE NÃO OFICIAL, +75 CLT Coins e skin Camiseta Só um Ajustezinho.
- Progresso das ajudas e recompensa ficam persistidos no save.


## v0.22
- Nova missão de história na LR Global — Torre de Controle.
- Três ocorrências operacionais: veículo sem força, documento pendente e motorista atrasado.
- Missão exige tratar todos os casos antes de enviar a posição.
- Primeira conclusão rende +30 XP, +5 reputação e +50 CLT Coins.
- Visitas seguintes rendem experiência menor e ficam registradas no save.
- Coordenadora da Torre integrada à missão e ao Easter Egg “É PRA ONTEM!”.
- Progresso da Torre persistente no save.


## v0.23 — NPC Lucas: Modo Melhoria
- O NPC Lucas ganhou personalidade mais forte inspirada no criador: vive mexendo em planilhas, dashboards, sites e automações.
- A Coordenadora e outros setores agora chamam Lucas para novos “ajustezinhos”.
- A cadeia recorrente passou de 3 para 6 tipos de pedidos, incluindo site interno, automação e melhoria de formulário.
- Nova interação “Ver o que o Lucas está inventando agora”, com devaneio Modo Melhoria.
- Ao completar 6 ajudas: conquista **ERA SÓ UMA PLANILHA!**, +100 CLT Coins e skin exclusiva **Moletom Modo Melhoria**.
- A nova recompensa fica persistida no save.


## v0.24 — Central de Chamados Internos
- O NPC Lucas ganhou uma Central de Chamados Internos ligada ao cotidiano da LR Global.
- Coordenadora, Programação, Atendimento, Financeiro e Qualidade podem gerar pedidos “rapidinho”.
- Novo indicador de pressão do expediente (0–5), que aumenta com chamados acumulados.
- Chamados prioritários rendem XP e reputação e ficam registrados em histórico persistente.
- Com pressão alta, a Coordenadora cobra Lucas durante o expediente.
- Ao atingir 10 chamados resolvidos: conquista TI SEM SER TI, +80 CLT Coins e skin Camiseta TI Sem Ser TI.
- Todo o progresso da central de chamados é salvo.


## v0.25 — Sistema de Áudio
- AudioManager modular separado do main.gd.
- Contextos automáticos: menu, expediente, casa e cidade.
- Canais separados: Música, Efeitos, Vozes e Ambiente.
- Volumes persistentes em user://audio_settings.json.
- Tela de Configurações de Áudio no menu principal.
- Estrutura para vinhetas de promoção/Easter Egg/eventos.
- Slots preparados para trilhas originais/comercialmente seguras; nenhuma música protegida foi incorporada.

## v0.26 — Escritório Vivo: Lucas das Planilhas
- Lucas agora é tratado explicitamente como NPC fixo do mundo; o jogador continua usando o personagem criado no Novo Jogo.
- Nova estação 3D provisória do Lucas com dois monitores, identificação própria e óculos característicos.
- Novo script modular `office_npc.gd` para estados/animação ambiente de NPCs, preparado para expansão.
- Interação do Lucas ganhou evento de celular: chamada de vídeo da esposa durante o expediente.
- A esposa não existe como NPC 3D no mapa: aparece somente na interface do celular/videochamada do Lucas.
- Contador de chamadas vistas persistido no save.
- Central de Chamados, Modo Melhoria e Easter Eggs das versões anteriores foram preservados.
- A geometria atual do Lucas é um placeholder funcional; o modelo 3D final poderá substituir a malha sem alterar as missões.

## v0.27 — Projetos de Melhoria (base jogável)
- Novo módulo `improvement_manager.gd`, separado do script principal.
- Projetos específicos para Gestão de Frotas, Programação, Atendimento e Operação de Contêineres Vazios.
- Cada projeto possui categoria, quatro etapas, XP, reputação e um efeito permanente no mundo.
- Novo aplicativo **Projetos de Melhoria** dentro do celular LR.
- Progresso, projetos concluídos e efeitos permanentes são persistidos no save da campanha.
- Estrutura preparada para conectar os efeitos a ocorrências, dashboards e mudanças visuais do escritório nas próximas expansões da v0.27.

## v0.27 — Gerenciador de Expediente
- Novo módulo `workday_manager.gd` com demandas específicas por área.
- Prioridades normal, importante e crítica com impacto diferente no fechamento.
- Ações RESOLVER e COMUNICAR/ENCAMINHAR; comunicar uma pendência evita tratar velocidade como única resposta correta.
- Evento 17:29 “Só uma coisinha rapidinho”.
- Fechamento diário contabiliza pendências e reputação.
- Estado do expediente persistido no save.
- Acesso pelo Celular LR em `EXPEDIENTE / DEMANDAS`.


## v0.27 revisão - Expediente conectado às Melhorias
- Demandas recorrentes são registradas.
- Ao repetir um tipo de problema, o jogo pode descobrir um Projeto de Melhoria relacionado.
- Descobertas e contadores persistem no save.
- Mantém o evento 17:29 e prioridades normal/importante/crítica.

## v0.27.2 — Ciclo completo do expediente
- Gerenciador de Expediente agora controla semana e dia útil (segunda a sexta).
- Cada dia combina demandas da área com uma interrupção corporativa contextual.
- Fechamento diário ganhou resumo com resolvidas, comunicadas, pendentes e críticas pendentes.
- Comunicação correta de pendências pode render bônus de fechamento; deixar demanda crítica sem tratamento reduz reputação.
- Fechar o dia sem pendências concede bônus de organização.
- Sexta-feira exibe “VOCÊ SOBREVIVEU À SEMANA!” e conecta ao fechamento financeiro já existente.
- Evento das 17:29 permanece integrado ao resumo diário.
- Projetos de Melhoria concluídos agora alteram ocorrências futuras: controles preventivos podem reduzir uma ocorrência crítica para importante e exibir “Melhoria em ação”.
- Repetição de problemas descobre oportunidades de Projeto de Melhoria diretamente pelo expediente.
- Histórico diário, semana atual, contadores de recorrência e demandas continuam persistidos no save.
- Compatibilidade mantida com saves das revisões anteriores da v0.27.


## v0.27.3 — Carreira integrada ao expediente
- Novo módulo `career_manager.gd`, separado do `main.gd`.
- Promoção de Assistente para Analista Jr agora exige 100 XP, reputação 58, pelo menos 5 expedientes concluídos e histórico recente consistente.
- A avaliação de promoção ganhou situações diferentes para Gestão de Frotas, Programação, Atendimento e Operação de Contêineres Vazios.
- Reprovação não encerra a campanha: o jogador conclui mais um expediente antes de receber nova tentativa.
- Aprovação altera cargo, salário-base e libera demandas de maior autonomia específicas da área no Gerenciador de Expediente.
- Progresso e tentativas de avaliação são persistidos no save, mantendo compatibilidade com saves anteriores.
- A antiga promoção hardcoded da quarta-feira foi substituída pela progressão centralizada de carreira.
- Correção estrutural: `clear_scene()` preserva AudioManager, ImprovementManager, WorkdayManager e CareerManager ao trocar interfaces.

## v0.27.4 — Primeiro dia e tutorial contextual
- Novo módulo `tutorial_manager.gd`, persistente e separado do `main.gd`.
- Tutorial do primeiro dia agora acompanha etapas reais: ponto → mentor → computador → retorno ao mentor → saída.
- Objetivo e dica contextual mudam conforme o avanço; não há sequência de telas obrigatórias de tutorial.
- Mentor inicial muda conforme a área escolhida: Frotas, Programação, Atendimento ou Contêineres Vazios.
- A primeira demanda também é específica por área, com investigação em duas etapas antes do encaminhamento.
- Recompensa da primeira demanda agora altera XP e reputação reais do save, em vez de apenas atualizar o texto do HUD.
- Saves anteriores são migrados para não obrigar jogadores já avançados a refazer o primeiro dia.
- Após concluir o tutorial, o computador passa a abrir o Gerenciador de Expediente normal.
- Interface de topo agora mostra o cargo real do jogador em vez de manter “Assistente” fixo.

## v0.27.5 — Casa, noite e ciclo semanal integrado
- Novo módulo `life_cycle_manager.gd` para separar trabalho, casa, manhã e fim de semana.
- Encerrar o expediente agora leva o personagem para uma cena-base própria da kitnet, em vez de manter o escritório por trás da interface.
- O save registra a fase da rotina, dia exibido, semana, horário, fim de semana e último fechamento.
- Carregar um save feito em casa, sábado, domingo ou pela manhã retorna ao momento correto da rotina.
- Dormir após um dia útil avança para a manhã do próximo expediente.
- Fechar a sexta-feira inicia sexta à noite → sábado → domingo → segunda-feira.
- Sábado e domingo possuem opções de descanso, cidade, relacionamentos e cuidados com a kitnet.
- Energia é consumida ao finalizar o trabalho e recuperada por descanso/sono; conforto da kitnet melhora a recuperação noturna.
- HUD do escritório mostra o dia útil correto em vez de permanecer fixo em SEG.
- Celular da casa passou a adaptar mensagens ao dia atual e ao fim de semana.
- Fechamento financeiro de sexta usa a semana realmente concluída, evitando crédito vinculado à semana seguinte após a virada do calendário.
- Correção adicional de strings multilinha antigas na missão da Torre de Controle, reduzindo risco de erro de parsing no Godot.
- Compatibilidade preservada com saves anteriores: sem dados de ciclo de vida, a campanha assume estado de trabalho normal.


## v0.27.6 — Primeira Semana Completa
- A Semana 1 agora possui ritmo próprio de terça a sexta, sem repetir exatamente a mesma lista de tarefas todos os dias.
- Cada área ganhou quatro demandas de história específicas para terça, quarta, quinta e sexta-feira.
- O Gerenciador de Expediente mostra foco do dia, Dia X/5 e dicas contextuais.
- Terça introduz a rotina; quarta traz o primeiro imprevisto crítico; quinta foca organização; sexta trabalha fechamento e pendências para a próxima semana.
- O celular bloqueia o Gerenciador de Expediente durante o tutorial de segunda-feira para evitar criar tarefas paralelas antes da primeira missão.
- Fechamento semanal ganhou consolidação de resolvidas, comunicadas, pendentes e críticas da semana inteira.
- A primeira sexta informa explicitamente que o tutorial terminou e que a rotina passa a ser dinâmica.
- Mantida compatibilidade com saves da v0.27.5 e anteriores.

## v0.27.7 — Tempo Livre e Fim de Semana Persistente
- Novo módulo `personal_life_manager.gd`, separado do `main.gd`.
- Noites de dias úteis têm 2 ações de tempo livre; sábado tem 3 e domingo tem 2.
- Atividades de cidade, descanso, café e encontros passam a consumir tempo e não podem ser repetidas infinitamente no mesmo dia.
- Mensagens de relacionamento continuam gratuitas, mas rendem afinidade apenas uma vez por dia.
- Evento de sábado na orla recompensa apenas uma vez por fim de semana, eliminando farm de CLT Coins.
- Academia, restaurante, orla, loja e arcade agora aplicam de forma consistente seus efeitos de energia, social, horário e R$.
- Domingo ganhou a ação **Preparar a próxima semana**; ao concluir, a segunda-feira começa com bônus de disposição.
- Progresso de atividades pessoais, eventos de fim de semana e preparação semanal ficam persistidos no save.
- Saves anteriores continuam compatíveis: quando o bloco `personal_life` não existe, o sistema inicia com histórico vazio.
- Versão interna do projeto atualizada para 0.27.7.


## v0.28 — Primeiro Ciclo Completo
- Novo módulo `campaign_manager.gd` para consolidar o estado da campanha e compatibilizar saves antigos.
- O botão **Continuar** agora usa o estado real da campanha: expediente, casa/tempo livre ou manhã de preparação.
- Sincronização automática de dia/semana/fim de semana reduz inconsistências de save entre os managers.
- Novo painel **Campanha / Progresso** no celular LR com semana, cargo, expedientes concluídos, melhorias, Easter Eggs e próximo marco.
- Celular LR passa a usar rolagem vertical, evitando opções cortadas conforme novos aplicativos e coleções são adicionados.
- Primeiro ciclo reconhecido somente após: primeira semana de trabalho → sexta à noite → sábado → domingo → retorno para a Semana 2.
- Conquista de marco **PRIMEIRO CICLO COMPLETO**: +50 CLT Coins, +10 XP e +2 reputação, concedida apenas uma vez.
- Save passa a registrar schema da v0.28 e estado dos marcos da campanha.
- Projeto configurado com `canvas_items` para preparar escalonamento de interface na etapa mobile da v0.29.
- Mantém compatibilidade com os sistemas de expediente, carreira, melhorias, vida pessoal, áudio e Easter Eggs das versões anteriores.


## v0.29 — Preparação Mobile / Android
- Novo `mobile_ui_manager.gd` para layout do HUD em diferentes proporções de tela e respeito à área segura de aparelhos com notch/cutout.
- HUD do expediente passa a reposicionar topo, mochila, celular, interação, corrida, inventário e joysticks a partir da área útil da tela.
- Joysticks virtuais aumentados para melhorar precisão em telas touch e ganharam deadzone de 10%.
- Botão **CORRER** agora funciona por pressionar/soltar e aplica multiplicador de velocidade no personagem.
- Controles principais de toque ficaram maiores para reduzir toques perdidos em celular.
- Projeto fixado em modo paisagem para mobile, com `canvas_items + expand` para aproveitar proporções mais largas.
- Limite de 60 FPS definido no projeto e também em runtime, priorizando estabilidade, temperatura e bateria nesta primeira fase Android.
- Mantido renderer `gl_compatibility` para ampliar compatibilidade com aparelhos Android.
- Estrutura continua compatível com os saves da v0.28.


## v0.29.1 — Menu Final do Alpha, Loja, Códigos e Configurações
- Menu principal reorganizado: **Continuar, Novo Jogo, Loja, Resgatar Código, Configurações, Créditos e Sair**.
- Novo Jogo pede confirmação quando já existe campanha, evitando apagar o save por toque acidental.
- Loja CLT acessível pelo menu e integrada ao mesmo saldo/inventário da campanha; cosméticos continuam sem vantagem de carreira.
- Sistema local de códigos do Alpha com uso único por campanha e persistência no save.
- Códigos de teste: `MUNDOCLT2026`, `FERIAS30`, `SEXTOU` e `GAUCHO01`. A versão comercial permanece planejada para validação em backend.
- Novo `settings_manager.gd` com persistência independente da campanha.
- Configurações: Volume Geral, Música, Efeitos, Vozes, Ambiente, qualidade Baixo/Médio/Alto, 30/60 FPS, sombras, sensibilidade da câmera, tamanho dos controles touch, vibração e câmera vertical invertida.
- Configurações também disponíveis dentro do Celular LR durante o gameplay.
- Volume Geral passou a multiplicar os quatro canais do AudioManager.
- Escala touch configurável passa a afetar botões principais e joysticks na próxima montagem do gameplay.
- Sensibilidade/inversão da câmera aplicadas ao personagem ao entrar no expediente.
- Tela de Créditos atualizada com LVSR Games e Lucas Rodrigues.
- Projeto atualizado para `0.29.1`, mantendo compatibilidade com saves da v0.29.


## v0.29.2 — Pré-APK / Segurança Mobile
- Save passou a usar arquivo temporário + backup automático antes da substituição do arquivo principal.
- Se o save principal estiver inválido, o jogo tenta recuperar automaticamente `mundo_clt_save.bak.json`.
- Minimizar o app durante uma campanha dispara autosave com proteção contra gravações repetidas em sequência.
- Botão Voltar do Android fecha primeiro o painel aberto; no gameplay/casa salva e retorna ao menu principal.
- Novo painel **Diagnóstico Alpha** em Configurações com versão, plataforma, resolução, qualidade, FPS, escala touch e estado do save/backup.
- Adicionado preset inicial `Android Alpha` para exportação ARM64 em paisagem.
- Package ID de desenvolvimento preparado como `com.lvsrgames.omundoclt`.
- Adicionado `ANDROID_ALPHA_EXPORT.md` com checklist para o primeiro APK.
- Projeto atualizado para `0.29.2`, mantendo compatibilidade com saves da v0.29.1.


## v0.29.3 — Frota Fictícia / Privacidade
- Removidas do protótipo todas as placas brasileiras reais/realistas encontradas na base atual.
- Novo catálogo central `fleet_catalog.gd` com 20 códigos de frota 100% fictícios.
- Padrões oficiais do universo LR Global: `LVS`, `VSR`, `LRG`, `LSR` e `RGL`.
- Exemplos em uso: `LVS-001`, `VSR-101`, `LRG-201` e `LSR-301`.
- O formato `AAA-000` é tratado no jogo como **código interno de frota**, não como placa veicular oficial.
- Missões de checklist, manutenção e tutorial agora usam apenas os identificadores fictícios.
- Projeto atualizado para `0.29.3`, mantendo compatibilidade com saves da v0.29.2.


## v0.29.4 — Pré-Alpha QA / Diagnóstico Automático
- Novo `alpha_health_manager.gd` executa checagens de integridade da sessão: managers, catálogo fictício de frota, save/backup, configurações e estado básico da campanha.
- Menu principal mostra status resumido **Pré-Alpha: OK / ATENÇÃO**.
- Diagnóstico Alpha ganhou lista detalhada de verificações e botão para rodar novamente.
- Novo `tools/preflight_check.py` faz auditoria estática antes de builds Android: versão/preset, referências `res://`, dados reais bloqueados e padrões brasileiros de placa.
- Preset Android atualizado para `0.29.4-alpha` e version code 294.
- Mantida compatibilidade com saves da v0.29.3.

## v0.29.5 — Abertura & candidata pré-APK
- Sequência de abertura LVSR Games / O Mundo CLT adicionada antes do menu principal.
- Botão PULAR disponível para testes rápidos.
- Menu identifica claramente a build Alpha e informa que compras reais estão desativadas.
- Diagnóstico Alpha mostra a versão do Godot em runtime.
- Mantém todos os sistemas e proteções da v0.29.4.


## v0.29.6 — Pause & segurança de sessão
- Menu de pausa real durante gameplay e casa.
- Botão Voltar do Android abre o pause em vez de sair direto.
- Autosave ao abrir o pause.
- Ações: Continuar, Salvar Jogo, Configurações, Diagnóstico Alpha e Salvar e Voltar ao Menu.
- UI de pause continua responsiva enquanto a árvore do jogo está pausada.
- Configurações e Diagnóstico funcionam dentro do pause.
- Build Alpha identificada no próprio menu de pausa.


## v0.29.9 — Inicialização segura & recuperação de sessão
- Nova tela curta **Preparando LR Global…** antes da abertura oficial, exibida enquanto os managers e o save são inicializados.
- Novo módulo `alpha_session_manager.gd` registra uma sessão ativa e detecta quando a execução anterior não encerrou normalmente.
- Se houver encerramento inesperado, o menu principal exibe um aviso e o fluxo normal de leitura/recuperação do save e backup é mantido.
- Diagnóstico Alpha agora mostra FPS medido no momento, contador de inicializações e estado da sessão anterior.
- Saídas normais pelo menu ou fechamento da janela removem o marcador de sessão.
- Mantém todas as proteções de save, pausa, frota fictícia e QA das versões anteriores.


## Pré-APK v0.29.9
O Diagnóstico Alpha inclui um autoteste não destrutivo dos principais sistemas e scripts auxiliares para validação/exportação Android.


## v0.29.13 — Identidade visual e sonora do Alpha
- Fundo cinematográfico da LR Global na abertura.
- Fundo ilustrado da LR Global no menu principal.
- Painel escuro dedicado aos botões para melhorar leitura em telas de celular.
- Trilha original de menu em loop, integrada aos controles de Volume Geral e Música.
- Boot diagnóstico preservado com imagem de fundo; se o Main falhar, a etapa de inicialização continua visível.
- Ícone Android oficial preservado.


## v0.29.16 — Entrada direta + menu garantido
- Mantém imagem e música da abertura da v0.29.15.
- `Main.tscn` é carregada diretamente, sem a `Boot.tscn` intermediária.
- A sequência de abertura possui timer em modo `ALWAYS` e guardião de 5,5 s para impedir travamento antes do menu.
- Splash interna do Godot desativada.
- Ícone Android personalizado, enquadramento ultrawide e sistemas anteriores preservados.
