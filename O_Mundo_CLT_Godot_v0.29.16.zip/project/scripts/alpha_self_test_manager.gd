extends Node
class_name AlphaSelfTestManager

const FleetCatalog := preload("res://scripts/fleet_catalog.gd")
const TutorialScript := preload("res://scripts/tutorial_manager.gd")
const WorkdayScript := preload("res://scripts/workday_manager.gd")
const CareerScript := preload("res://scripts/career_manager.gd")
const LifeCycleScript := preload("res://scripts/life_cycle_manager.gd")
const CampaignScript := preload("res://scripts/campaign_manager.gd")
const ImprovementScript := preload("res://scripts/improvement_manager.gd")
const PersonalLifeScript := preload("res://scripts/personal_life_manager.gd")

const REPORT_PATH := "user://alpha_self_test_report.json"
const AREAS := [
    "Atendimento",
    "Programação",
    "Gestão de Frotas",
    "Operação de Contêineres Vazios"
]

var last_result: Dictionary = {}

func _result(name:String, ok:bool, detail:String) -> Dictionary:
    return {"name":name,"ok":ok,"detail":detail}

func _test_fleet_catalog() -> Dictionary:
    var unique:Dictionary = {}
    var ok := FleetCatalog.CODES.size() == 20
    for raw in FleetCatalog.CODES:
        var code := str(raw)
        var parts := code.split("-")
        if parts.size() != 2 or str(parts[0]).length() != 3 or str(parts[1]).length() != 3 or not str(parts[1]).is_valid_int():
            ok = false
        if unique.has(code):
            ok = false
        unique[code] = true
    return _result("Frota fictícia",ok,"20 códigos únicos e fora do formato de placa real" if ok else "catálogo de frota inconsistente")

func _test_tutorial_areas() -> Dictionary:
    var tutorial = TutorialScript.new()
    var ok := true
    var covered := 0
    var required_keys := ["system","title","details","check_label","check_result","contact_label","contact_result","finish_label","success"]
    for area in AREAS:
        var data:Dictionary = tutorial.get_first_case(area)
        var mentor := tutorial.get_mentor_name(area)
        if mentor.strip_edges() == "":
            ok = false
        for key in required_keys:
            if not data.has(key) or str(data.get(key,"")).strip_edges() == "":
                ok = false
        if not data.is_empty():
            covered += 1
    return _result("Tutorial por área",ok and covered == AREAS.size(),"4/4 áreas com mentor e primeira demanda" if ok else "há área sem conteúdo de tutorial")

func _test_workday_generation() -> Dictionary:
    var ok := true
    var details:Array = []
    for area in AREAS:
        var work = WorkdayScript.new()
        work.current_week = 1
        work.current_day = 2
        work.ensure_day(area,"Assistente")
        var ids:Dictionary = {}
        var area_ok := work.active_tasks.size() >= 4
        for task in work.active_tasks:
            var id := str(task.get("id",""))
            var priority := str(task.get("priority",""))
            if id == "" or ids.has(id) or not (priority in ["normal","importante","critica"]) or str(task.get("status","")) != "pendente":
                area_ok = false
            ids[id] = true
        ok = ok and area_ok
        details.append("%s:%d" % [area,work.active_tasks.size()])
    return _result("Gerador de expediente",ok," • ".join(details) if ok else "tarefas inválidas, duplicadas ou sem prioridade")

func _test_friday_transition() -> Dictionary:
    var work = WorkdayScript.new()
    work.current_week = 1
    work.current_day = 5
    work.total_completed_days = 4
    work.ensure_day("Gestão de Frotas","Assistente")
    for i in range(work.active_tasks.size()):
        work.resolve_task(i)
    var summary:Dictionary = work.end_day()
    var ok := bool(summary.get("weekly_close",false)) and int(work.current_week) == 2 and int(work.current_day) == 1 and int(work.total_completed_days) == 5
    return _result("Fechamento de sexta",ok,"Semana 1 → Semana 2 com 5 expedientes" if ok else "transição semanal não fechou corretamente")

func _test_career_evaluations() -> Dictionary:
    var career = CareerScript.new()
    var ok := true
    for area in AREAS:
        var data:Dictionary = career.get_evaluation(area)
        var choices:Array = data.get("choices",[])
        var correct := 0
        var ids:Dictionary = {}
        for choice in choices:
            var id := str(choice.get("id",""))
            if id == "" or ids.has(id):
                ok = false
            ids[id] = true
            if bool(choice.get("correct",false)):
                correct += 1
        if choices.size() != 5 or correct != 3:
            ok = false
    return _result("Avaliação Analista Jr",ok,"4/4 áreas com 5 escolhas e 3 decisões válidas" if ok else "avaliação de carreira inconsistente")

func _test_weekend_cycle() -> Dictionary:
    var life = LifeCycleScript.new()
    life.begin_evening({"day_label":"SEXTA-FEIRA","week":1,"weekly_close":true})
    var saturday := life.sleep_and_advance("SEGUNDA-FEIRA",2)
    var sunday := life.sleep_and_advance("SEGUNDA-FEIRA",2)
    var monday := life.sleep_and_advance("SEGUNDA-FEIRA",2)
    var ok := saturday == "saturday" and sunday == "sunday" and monday == "work_morning" and life.phase == life.PHASE_MORNING and life.display_week == 2 and life.display_day == "SEGUNDA-FEIRA"
    return _result("Ciclo de fim de semana",ok,"Sexta → sábado → domingo → segunda de manhã" if ok else "transição de fim de semana inconsistente")

func _test_campaign_reward_once() -> Dictionary:
    var work = WorkdayScript.new()
    work.current_week = 2
    work.current_day = 1
    work.total_completed_days = 5
    var life = LifeCycleScript.new()
    life.phase = life.PHASE_MORNING
    life.display_day = "SEGUNDA-FEIRA"
    life.display_week = 2
    life.weekend_stage = 0
    var campaign = CampaignScript.new()
    var first:Dictionary = campaign.check_first_cycle(work,life)
    var second:Dictionary = campaign.check_first_cycle(work,life)
    var ok := str(first.get("id","")) == "primeiro_ciclo" and second.is_empty()
    return _result("Recompensa do primeiro ciclo",ok,"marco concedido uma única vez" if ok else "recompensa pode duplicar ou não liberar")

func _test_improvements() -> Dictionary:
    var ok := true
    var completed := 0
    for area in AREAS:
        var improvements = ImprovementScript.new()
        var project_id := improvements.get_project_for_area(area)
        if project_id == "" or not improvements.discover_project(project_id) or not improvements.start_project(project_id):
            ok = false
            continue
        var guard := 0
        var finish:Dictionary = {}
        while guard < 8:
            finish = improvements.advance_active_project()
            guard += 1
            if bool(finish.get("finished",false)):
                break
        if not bool(finish.get("finished",false)) or improvements.permanent_effects.is_empty():
            ok = false
        else:
            completed += 1
    return _result("Projetos de melhoria",ok and completed == AREAS.size(),"4/4 projetos concluem e geram efeito permanente" if ok else "há projeto sem conclusão/efeito")

func _test_personal_life_limits() -> Dictionary:
    var life = PersonalLifeScript.new()
    var ok := life.max_actions_for_day("SÁBADO") == 3 and life.max_actions_for_day("DOMINGO") == 2 and life.max_actions_for_day("SEGUNDA-FEIRA") == 2
    var a1:Dictionary = life.try_action(1,"SÁBADO","gym")
    var a2:Dictionary = life.try_action(1,"SÁBADO","orla")
    var a3:Dictionary = life.try_action(1,"SÁBADO","cafe")
    var a4:Dictionary = life.try_action(1,"SÁBADO","arcade")
    ok = ok and bool(a1.get("ok",false)) and bool(a2.get("ok",false)) and bool(a3.get("ok",false)) and not bool(a4.get("ok",true))
    return _result("Limites de tempo livre",ok,"sábado aceita 3 ações e bloqueia a 4ª" if ok else "limite de ações pessoais inconsistente")

func run_all() -> Dictionary:
    var tests:Array = [
        _test_fleet_catalog(),
        _test_tutorial_areas(),
        _test_workday_generation(),
        _test_friday_transition(),
        _test_career_evaluations(),
        _test_weekend_cycle(),
        _test_campaign_reward_once(),
        _test_improvements(),
        _test_personal_life_limits()
    ]
    var passed := 0
    for test in tests:
        if bool(test.get("ok",false)):
            passed += 1
    last_result = {
        "ok":passed == tests.size(),
        "passed":passed,
        "failed":tests.size()-passed,
        "total":tests.size(),
        "tests":tests,
        "generated_unix":int(Time.get_unix_time_from_system())
    }
    _write_report(last_result)
    return last_result.duplicate(true)

func _write_report(result:Dictionary) -> void:
    var f := FileAccess.open(REPORT_PATH,FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(result,"  "))
