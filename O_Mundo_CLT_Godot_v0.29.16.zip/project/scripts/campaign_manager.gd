extends Node
class_name CampaignManager

const SAVE_SCHEMA := 28

var first_week_completed := false
var first_cycle_completed := false
var first_cycle_rewarded := false
var milestones := {}
var load_repairs := 0
var last_repair_note := ""

func reconcile(workday_manager:Node, life_cycle_manager:Node, tutorial_manager:Node, area_name:String="Gestão de Frotas") -> Dictionary:
    var changes:Array = []
    if workday_manager == null or life_cycle_manager == null:
        return {"changed":false,"changes":changes}

    workday_manager.current_area = area_name

    # Migração de protótipos antigos: o tutorial podia estar concluído sem o Dia 1
    # ter sido registrado no histórico do Gerenciador de Expediente.
    if tutorial_manager != null and bool(tutorial_manager.first_day_completed) and int(workday_manager.total_completed_days) == 0:
        if workday_manager.register_tutorial_day(area_name):
            changes.append("primeiro expediente recuperado a partir do tutorial")

    if int(workday_manager.total_completed_days) >= 5 or int(workday_manager.current_week) >= 2:
        if not first_week_completed:
            changes.append("primeira semana reconhecida")
        first_week_completed = true
        milestones["primeira_semana"] = true

    var valid_phases := [life_cycle_manager.PHASE_WORK, life_cycle_manager.PHASE_HOME, life_cycle_manager.PHASE_MORNING]
    if not valid_phases.has(life_cycle_manager.phase):
        life_cycle_manager.phase = life_cycle_manager.PHASE_WORK
        changes.append("fase inválida corrigida")

    if life_cycle_manager.phase == life_cycle_manager.PHASE_WORK:
        var expected_day := workday_manager.get_day_label()
        if life_cycle_manager.display_day != expected_day:
            life_cycle_manager.display_day = expected_day
            changes.append("dia do expediente sincronizado")
        if int(life_cycle_manager.display_week) != int(workday_manager.current_week):
            life_cycle_manager.display_week = int(workday_manager.current_week)
            changes.append("semana do expediente sincronizada")
        life_cycle_manager.weekend_stage = 0
        if life_cycle_manager.time_label == "":
            life_cycle_manager.time_label = "07:45"

    elif life_cycle_manager.phase == life_cycle_manager.PHASE_MORNING:
        var expected_morning_day := workday_manager.get_day_label()
        if life_cycle_manager.display_day != expected_morning_day:
            life_cycle_manager.display_day = expected_morning_day
            changes.append("manhã sincronizada com o próximo expediente")
        if int(life_cycle_manager.display_week) != int(workday_manager.current_week):
            life_cycle_manager.display_week = int(workday_manager.current_week)
            changes.append("semana da manhã sincronizada")
        life_cycle_manager.weekend_stage = 0
        if life_cycle_manager.time_label == "":
            life_cycle_manager.time_label = "06:30"

    elif life_cycle_manager.phase == life_cycle_manager.PHASE_HOME:
        if int(life_cycle_manager.weekend_stage) > 0:
            var finished_week := maxi(1, int(workday_manager.current_week) - 1)
            if int(life_cycle_manager.display_week) != finished_week:
                life_cycle_manager.display_week = finished_week
                changes.append("semana do fim de semana sincronizada")
            match int(life_cycle_manager.weekend_stage):
                1:
                    if life_cycle_manager.display_day != "SEXTA-FEIRA":
                        life_cycle_manager.display_day = "SEXTA-FEIRA"
                        changes.append("sexta à noite restaurada")
                2:
                    if life_cycle_manager.display_day != "SÁBADO":
                        life_cycle_manager.display_day = "SÁBADO"
                        changes.append("sábado restaurado")
                3:
                    if life_cycle_manager.display_day != "DOMINGO":
                        life_cycle_manager.display_day = "DOMINGO"
                        changes.append("domingo restaurado")
        else:
            var previous_index := int(workday_manager.current_day) - 2
            if previous_index >= 0 and previous_index < workday_manager.WEEKDAYS.size():
                var previous_day := str(workday_manager.WEEKDAYS[previous_index])
                if life_cycle_manager.display_day != previous_day:
                    life_cycle_manager.display_day = previous_day
                    changes.append("noite restaurada para o dia concluído")
            life_cycle_manager.display_week = int(workday_manager.current_week)

    if not changes.is_empty():
        load_repairs += 1
        last_repair_note = ", ".join(changes)
    return {"changed":not changes.is_empty(),"changes":changes}

func check_first_cycle(workday_manager:Node, life_cycle_manager:Node) -> Dictionary:
    if first_cycle_rewarded or workday_manager == null or life_cycle_manager == null:
        return {}
    var ready := (
        int(workday_manager.current_week) >= 2
        and life_cycle_manager.phase in [life_cycle_manager.PHASE_MORNING, life_cycle_manager.PHASE_WORK]
        and int(life_cycle_manager.weekend_stage) == 0
        and int(workday_manager.total_completed_days) >= 5
    )
    if not ready:
        return {}
    first_week_completed = true
    first_cycle_completed = true
    first_cycle_rewarded = true
    milestones["primeira_semana"] = true
    milestones["primeiro_ciclo"] = true
    return {
        "id":"primeiro_ciclo",
        "title":"PRIMEIRO CICLO COMPLETO",
        "message":"Você trabalhou a primeira semana, viveu o fim de semana e voltou para a LR Global.",
        "clt_coins":50,
        "xp":10,
        "reputation":2
    }

func get_progress_text(workday_manager:Node, life_cycle_manager:Node, role:String, improvement_count:int, easter_count:int, easter_total:int) -> String:
    var week := 1
    var day := "SEGUNDA-FEIRA"
    var completed_days := 0
    if workday_manager != null:
        week = int(workday_manager.current_week)
        day = workday_manager.get_day_label()
        completed_days = int(workday_manager.total_completed_days)
    if life_cycle_manager != null and life_cycle_manager.phase != life_cycle_manager.PHASE_WORK:
        day = str(life_cycle_manager.display_day)
    var first_week := "✅ CONCLUÍDA" if first_week_completed else "⏳ EM ANDAMENTO"
    var first_cycle := "✅ CONCLUÍDO" if first_cycle_completed else "⏳ EM ANDAMENTO"
    return "SEMANA %d • %s\n💼 Cargo: %s\n📅 Expedientes concluídos: %d\n🎓 Primeira semana: %s\n🔁 Primeiro ciclo trabalho + fim de semana: %s\n💡 Melhorias implantadas: %d\n🥚 Easter Eggs: %d/%d" % [
        week, day.capitalize(), role, completed_days, first_week, first_cycle, improvement_count, easter_count, easter_total
    ]

func get_next_milestone(role:String, workday_manager:Node) -> String:
    if not first_week_completed:
        return "Concluir a primeira semana na LR Global."
    if not first_cycle_completed:
        return "Aproveitar o fim de semana e retornar para a Semana 2."
    if role == "Assistente":
        return "Construir desempenho para liberar a avaliação de Analista Jr."
    if workday_manager != null and int(workday_manager.current_week) <= 2:
        return "Concluir um Projeto de Melhoria e assumir demandas de autonomia."
    return "Continuar evoluindo carreira, vida pessoal e melhorias da LR Global."

func resume_label(workday_manager:Node, life_cycle_manager:Node, role:String) -> String:
    if workday_manager == null or life_cycle_manager == null:
        return role
    var phase_label := "EXPEDIENTE"
    match str(life_cycle_manager.phase):
        "home": phase_label = "CASA / TEMPO LIVRE"
        "morning": phase_label = "MANHÃ / PREPARAÇÃO"
    return "Semana %d • %s • %s • %s" % [
        int(workday_manager.current_week),
        str(life_cycle_manager.display_day).capitalize(),
        phase_label,
        role
    ]

func export_state() -> Dictionary:
    return {
        "save_schema":SAVE_SCHEMA,
        "first_week_completed":first_week_completed,
        "first_cycle_completed":first_cycle_completed,
        "first_cycle_rewarded":first_cycle_rewarded,
        "milestones":milestones,
        "load_repairs":load_repairs,
        "last_repair_note":last_repair_note
    }

func import_state(data:Dictionary) -> void:
    if data.is_empty():
        first_week_completed = false
        first_cycle_completed = false
        first_cycle_rewarded = false
        milestones = {}
        load_repairs = 0
        last_repair_note = ""
        return
    first_week_completed = bool(data.get("first_week_completed", false))
    first_cycle_completed = bool(data.get("first_cycle_completed", false))
    first_cycle_rewarded = bool(data.get("first_cycle_rewarded", false))
    milestones = data.get("milestones", {}).duplicate(true)
    load_repairs = maxi(0, int(data.get("load_repairs", 0)))
    last_repair_note = str(data.get("last_repair_note", ""))
    if first_cycle_rewarded:
        first_cycle_completed = true
        first_week_completed = true
        milestones["primeiro_ciclo"] = true
        milestones["primeira_semana"] = true
