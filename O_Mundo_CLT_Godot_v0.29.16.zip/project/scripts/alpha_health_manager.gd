extends Node
class_name AlphaHealthManager

const FleetCatalog := preload("res://scripts/fleet_catalog.gd")

func _check(name:String, ok:bool, detail:String, required:bool=true) -> Dictionary:
    return {"name":name,"ok":ok,"detail":detail,"required":required}

func _valid_json_file(path:String) -> bool:
    if not FileAccess.file_exists(path):
        return true
    var f:=FileAccess.open(path,FileAccess.READ)
    if not f:
        return false
    return typeof(JSON.parse_string(f.get_as_text()))==TYPE_DICTIONARY

func _fleet_catalog_ok() -> bool:
    if FleetCatalog.CODES.size()!=20:
        return false
    var unique:Dictionary={}
    for code in FleetCatalog.CODES:
        var value:=str(code)
        var parts:=value.split("-")
        if parts.size()!=2 or str(parts[0]).length()!=3 or str(parts[1]).length()!=3:
            return false
        if not str(parts[1]).is_valid_int() or unique.has(value):
            return false
        unique[value]=true
    return true

func evaluate(managers:Dictionary, settings_manager:Node, save_path:String, backup_path:String, campaign_state:Dictionary) -> Dictionary:
    var checks:Array=[]
    var required_managers=["audio","improvements","workday","career","tutorial","life_cycle","personal_life","campaign","mobile_ui","settings","session","self_test"]
    var manager_ok:=true
    for key in required_managers:
        if managers.get(key)==null:
            manager_ok=false
    checks.append(_check("Managers essenciais",manager_ok,"12/12 ativos" if manager_ok else "há manager ausente"))

    var engine_info:=Engine.get_version_info()
    var engine_major:=int(engine_info.get("major",0))
    var engine_minor:=int(engine_info.get("minor",0))
    var engine_patch:=int(engine_info.get("patch",0))
    var engine_ok:=engine_major==4
    checks.append(_check("Engine",engine_ok,"Godot %d.%d.%d" % [engine_major,engine_minor,engine_patch] if engine_ok else "versão incompatível"))


    var session_manager=managers.get("session")
    var session_ok=session_manager!=null
    checks.append(_check("Sessão Alpha",session_ok,"detecção de encerramento inesperado ativa" if session_ok else "session manager ausente"))
    if session_ok and bool(session_manager.previous_unclean_exit):
        checks.append(_check("Sessão anterior",false,"encerramento inesperado detectado; save/backup verificados",false))

    var fleet_ok:=_fleet_catalog_ok()
    checks.append(_check("Frota fictícia",fleet_ok,"20 códigos internos válidos" if fleet_ok else "catálogo inconsistente"))

    var save_exists:=FileAccess.file_exists(save_path)
    var save_ok:=_valid_json_file(save_path)
    checks.append(_check("Save principal",save_ok,"JSON legível" if save_exists and save_ok else ("sem campanha — normal" if not save_exists else "JSON inválido")))

    var backup_exists:=FileAccess.file_exists(backup_path)
    var backup_ok:=_valid_json_file(backup_path)
    checks.append(_check("Backup do save",backup_ok,"backup legível" if backup_exists and backup_ok else ("ainda não criado" if not backup_exists else "backup inválido"),false))

    var settings_ok:=settings_manager!=null
    if settings_ok:
        settings_ok = str(settings_manager.graphics_preset) in ["Baixo","Médio","Alto"] and int(settings_manager.fps_cap) in [30,60] and float(settings_manager.touch_scale)>=0.85 and float(settings_manager.touch_scale)<=1.30
    checks.append(_check("Configurações",settings_ok,"valores dentro dos limites" if settings_ok else "configuração fora dos limites"))

    var week:=int(campaign_state.get("week",0)); var day:=int(campaign_state.get("day",0)); var energy:=int(campaign_state.get("energy",-1))
    var campaign_ok:=week>=1 and day>=1 and day<=5 and energy>=0 and energy<=100
    checks.append(_check("Estado da campanha",campaign_ok,"Semana %d • Dia %d • Energia %d" % [week,day,energy] if campaign_ok else "dia/semana/energia fora do intervalo"))

    var required_failures:=0
    var warnings:=0
    for item in checks:
        if not bool(item.get("ok",false)):
            if bool(item.get("required",true)): required_failures+=1
            else: warnings+=1
    return {"ok":required_failures==0,"status":"OK" if required_failures==0 else "ATENÇÃO","required_failures":required_failures,"warnings":warnings,"checks":checks}
