extends Node
class_name TutorialManager

const FleetCatalog := preload("res://scripts/fleet_catalog.gd")

const STAGE_CLOCK_IN := "clock_in"
const STAGE_MEET_MENTOR := "meet_mentor"
const STAGE_USE_COMPUTER := "use_computer"
const STAGE_RETURN_MENTOR := "return_mentor"
const STAGE_CLOCK_OUT := "clock_out"
const STAGE_COMPLETE := "complete"

var stage := STAGE_CLOCK_IN
var first_day_completed := false
var hints_seen := {}

func reset_progress() -> void:
    stage = STAGE_CLOCK_IN
    first_day_completed = false
    hints_seen = {}

func begin_first_day() -> void:
    if not first_day_completed and stage == "":
        stage = STAGE_CLOCK_IN

func is_active() -> bool:
    return not first_day_completed

func migrate_legacy(completed: bool) -> void:
    if completed:
        first_day_completed = true
        stage = STAGE_COMPLETE

func advance(action: String) -> bool:
    if first_day_completed:
        return false
    var expected := {
        STAGE_CLOCK_IN: "clock_in",
        STAGE_MEET_MENTOR: "meet_mentor",
        STAGE_USE_COMPUTER: "use_computer",
        STAGE_RETURN_MENTOR: "return_mentor",
        STAGE_CLOCK_OUT: "clock_out"
    }
    if str(expected.get(stage, "")) != action:
        return false
    match stage:
        STAGE_CLOCK_IN:
            stage = STAGE_MEET_MENTOR
        STAGE_MEET_MENTOR:
            stage = STAGE_USE_COMPUTER
        STAGE_USE_COMPUTER:
            stage = STAGE_RETURN_MENTOR
        STAGE_RETURN_MENTOR:
            stage = STAGE_CLOCK_OUT
        STAGE_CLOCK_OUT:
            stage = STAGE_COMPLETE
            first_day_completed = true
    return true

func get_mentor_name(area: String) -> String:
    match area:
        "Programação":
            return "Analista de Programação"
        "Atendimento":
            return "Analista de Atendimento"
        "Operação de Contêineres Vazios":
            return "Analista de Pátio"
        _:
            return "Especialista da Frota"

func get_objective(area: String) -> String:
    if first_day_completed:
        return "🎯 EXPEDIENTE\nAcompanhe suas demandas pelo celular LR."
    var mentor := get_mentor_name(area)
    match stage:
        STAGE_CLOCK_IN:
            return "🎯 PRIMEIRO DIA\nRegistre seu ponto às 07:45."
        STAGE_MEET_MENTOR:
            return "🎯 PRIMEIRO DIA\nFale com %s." % mentor
        STAGE_USE_COMPUTER:
            return "🎯 PRIMEIRA DEMANDA\nUse o computador da sua estação."
        STAGE_RETURN_MENTOR:
            return "🎯 DEMANDA ENCAMINHADA\nRetorne para %s." % mentor
        STAGE_CLOCK_OUT:
            return "🎯 FIM DO EXPEDIENTE\nVá até a saída e registre o encerramento."
        _:
            return "🎯 EXPEDIENTE\nAcompanhe suas demandas pelo celular LR."

func get_hint() -> String:
    if first_day_completed:
        return ""
    match stage:
        STAGE_CLOCK_IN:
            return "DICA • Caminhe até o RELÓGIO DE PONTO e use INTERAGIR."
        STAGE_MEET_MENTOR:
            return "DICA • Procure o profissional indicado pelo marcador no escritório."
        STAGE_USE_COMPUTER:
            return "DICA • Investigue antes de concluir. Nem sempre a opção mais rápida é a melhor."
        STAGE_RETURN_MENTOR:
            return "DICA • Depois de encaminhar uma demanda, comunique o responsável."
        STAGE_CLOCK_OUT:
            return "DICA • Seu expediente só termina depois do fechamento na saída."
        _:
            return ""

func get_first_case(area: String) -> Dictionary:
    match area:
        "Programação":
            return {
                "system":"LR GLOBAL • PROGRAMAÇÃO",
                "title":"CARGA #0001 • DIVERGÊNCIA DE VÍNCULO",
                "details":"Carga com saída prevista para hoje.\nO motorista e o veículo foram informados, mas o vínculo não confere no sistema.\nStatus: AGUARDANDO VALIDAÇÃO",
                "check_label":"CONFERIR CADASTRO",
                "check_result":"📋 Cadastro: motorista ativo, porém o veículo vinculado pertence a outra operação.",
                "contact_label":"FALAR COM OPERAÇÃO",
                "contact_result":"📞 Operação confirma troca de cavalo antes da saída e pede atualização do vínculo.",
                "finish_label":"CORRIGIR E GERAR ROMANEIO",
                "success":"✅ Vínculo corrigido e romaneio liberado com dados conferidos."
            }
        "Atendimento":
            return {
                "system":"LR GLOBAL • ATENDIMENTO",
                "title":"CLIENTE #0001 • PREVISÃO DE ENTREGA",
                "details":"Cliente solicita posição urgente da entrega.\nA operação ainda não confirmou o horário de liberação.\nStatus: AGUARDANDO RETORNO",
                "check_label":"CONSULTAR OPERAÇÃO",
                "check_result":"📋 Operação: carga em processo, ainda sem horário confirmado de liberação.",
                "contact_label":"VALIDAR ÚLTIMA POSIÇÃO",
                "contact_result":"📞 Motorista confirma que permanece aguardando e não possui previsão segura.",
                "finish_label":"RETORNAR SEM INVENTAR PRAZO",
                "success":"✅ Cliente atualizado com a situação real e novo horário de acompanhamento combinado."
            }
        "Operação de Contêineres Vazios":
            return {
                "system":"LR GLOBAL • CONTÊINERES VAZIOS",
                "title":"PÁTIO #0001 • DIVERGÊNCIA DE POSIÇÃO",
                "details":"Um contêiner vazio consta disponível no sistema, mas não está na posição informada.\nStatus: AGUARDANDO CONFERÊNCIA",
                "check_label":"CONFERIR MOVIMENTAÇÃO",
                "check_result":"📋 Histórico: houve remanejamento de posição no turno anterior.",
                "contact_label":"VALIDAR COM PÁTIO",
                "contact_result":"📞 Pátio confirma nova quadra e solicita correção do registro.",
                "finish_label":"ATUALIZAR POSIÇÃO",
                "success":"✅ Posição corrigida e disponibilidade atualizada para a operação."
            }
        _:
            return {
                "system":"LR GLOBAL • CENTRAL DE FROTAS",
                "title":"OCORRÊNCIA #0001 • PRIORIDADE ALTA",
                "details":"Motorista: Carlos M.\nFrota: %s\nRelato: caminhão sem força durante subida.\nStatus: AGUARDANDO TRIAGEM" % FleetCatalog.CHECKLIST_RETURN,
                "check_label":"VER HISTÓRICO",
                "check_result":"📋 Histórico: veículo teve registro anterior de perda de potência. Revisão preventiva próxima.",
                "contact_label":"LIGAR MOTORISTA",
                "contact_result":"📞 Motorista: ‘Ele anda normal no plano, mas perde muita força quando pega subida.’",
                "finish_label":"ABRIR MANUTENÇÃO",
                "success":"✅ Ordem de manutenção aberta. Veículo encaminhado para diagnóstico."
            }

func export_state() -> Dictionary:
    return {
        "stage": stage,
        "first_day_completed": first_day_completed,
        "hints_seen": hints_seen.duplicate(true)
    }

func import_state(data: Dictionary) -> void:
    if data.is_empty():
        reset_progress()
        return
    stage = str(data.get("stage", STAGE_CLOCK_IN))
    first_day_completed = bool(data.get("first_day_completed", false))
    hints_seen = data.get("hints_seen", {}).duplicate(true)
    if first_day_completed:
        stage = STAGE_COMPLETE
