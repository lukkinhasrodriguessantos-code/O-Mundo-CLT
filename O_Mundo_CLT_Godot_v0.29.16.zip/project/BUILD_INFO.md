# Build Info — O MUNDO CLT v0.29.16

## v0.29.16 — Entrada direta + menu garantido

- Parte da v0.29.15, preservando a imagem cinematográfica e a música que já funcionavam.
- `Main.tscn` passa a ser a cena inicial do APK; `Boot.tscn` deixa de ficar no caminho entre a abertura e o menu.
- A raiz da `Main.tscn` é um `Control` em tela cheia para o layout funcionar corretamente em celulares.
- A abertura continua dentro da Main e avança automaticamente ao menu.
- Timer da abertura roda em `PROCESS_MODE_ALWAYS`, evitando travamento se a árvore for pausada.
- Guardião independente de 5,5 s também roda em `PROCESS_MODE_ALWAYS` e força `show_menu()` se a sequência não avançar.
- A splash interna do Godot foi desativada (`boot_splash/show_image=false`).
- Ícones Android personalizados continuam configurados no preset; a abertura do jogo usa a identidade visual do O Mundo CLT.
- Música, enquadramento ultrawide, save, diagnóstico e demais sistemas da v0.29.15 foram mantidos.

Observação Android: versões recentes do Android podem mostrar por alguns instantes a splash do próprio sistema operacional com o ícone do aplicativo. Isso é diferente da splash interna do Godot.
