# Build Info — O MUNDO CLT v0.29.16

## v0.29.16 — Entrada direta e splash própria

- Remove a Boot.tscn do caminho inicial do APK; Main.tscn passa a ser a cena inicial.
- Evita o bloqueio observado na v0.29.15, em que a arte do boot permanecia sobre a interface.
- Converte a raiz da Main em Control de tela cheia para garantir layout correto da intro e do menu.
- Adiciona proteção independente de 6 segundos: se a intro não avançar, abre o menu automaticamente.
- Substitui a splash padrão do motor por arte própria da LR Global/O Mundo CLT.
- Mantém música, ícone Android e enquadramento ultrawide.

Observação: a validação local verifica estrutura e referências; o teste final de jogabilidade depende da APK instalada no Android.
