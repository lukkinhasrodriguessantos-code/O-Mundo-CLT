extends Control

@onready var status_label: Label = $DiagnosticOverlay/Center/Box/Status
@onready var detail_label: Label = $DiagnosticOverlay/Center/Box/Detail
@onready var overlay: ColorRect = $DiagnosticOverlay

var main_instance: Node = null

func _ready() -> void:
    _install_boot_background()
    status_label.text = "INICIANDO O MUNDO CLT"
    detail_label.text = "Etapa 1/4 - cena de boot carregada"
    await get_tree().process_frame
    detail_label.text = "Etapa 2/4 - carregando nucleo do jogo"
    await get_tree().process_frame

    var packed := load("res://scenes/Main.tscn") as PackedScene
    if packed == null:
        status_label.text = "ERRO DE INICIALIZACAO"
        detail_label.text = "Nao foi possivel carregar Main.tscn"
        return

    detail_label.text = "Etapa 3/4 - iniciando sistemas"
    main_instance = packed.instantiate()
    if main_instance == null:
        status_label.text = "ERRO DE INICIALIZACAO"
        detail_label.text = "Main.tscn nao foi instanciada"
        return

    add_child(main_instance)
    # Se Main._ready falhar, este overlay continua visivel com a ultima etapa.
    await get_tree().process_frame
    if overlay.visible:
        detail_label.text = "Etapa 3/4 - aguardando interface principal"

func mark_game_ready() -> void:
    status_label.text = "PRONTO"
    detail_label.text = "Etapa 4/4 - interface carregada"
    await get_tree().create_timer(0.25).timeout
    overlay.visible = false


func _install_boot_background() -> void:
    var tex=load("res://assets/backgrounds/intro_lr_global.png") as Texture2D
    if tex==null:
        return
    var bg=TextureRect.new()
    bg.name="BootBackground"
    bg.texture=tex
    bg.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_COVERED
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.mouse_filter=Control.MOUSE_FILTER_IGNORE
    add_child(bg)
    move_child(bg,0)
    overlay.color=Color(0.015,0.025,0.045,0.64)
