# Build Info — O MUNDO CLT v0.29.12

## v0.29.12 — Abertura visual + música de menu

- Abertura cinematográfica com imagem da LR Global.
- Menu principal com fundo ilustrado da LR Global e painel escuro para legibilidade.
- Primeira trilha original do projeto: `assets/audio/menu_theme.wav`.
- Música inicia no contexto de abertura/menu e respeita Volume Geral + Música.
- Loop automático da trilha do menu.
- Tela de boot diagnóstico ganhou imagem de fundo e mantém mensagens de erro visíveis.
- Ícone Android oficial da v0.29.11 preservado.
- ETC2/ASTC para Android preservado.
- Compatível com saves anteriores da família v0.29.x.

## Estado da build

- Status: Alpha Android em desenvolvimento
- Engine alvo: Godot 4.x
- Renderer: GL Compatibility
- Orientação: paisagem
- Arquitetura Android: ARM64
- Package ID: `com.lvsrgames.omundoclt`
- Imagens desta build: conteúdo fictício da LR Global, sem marca real.
- Música: composição original gerada especificamente para o projeto, sem faixa comercial de terceiros.

## Privacidade / identidade

- Empresa do jogo: **LR Global Logística**, fictícia.
- Frota usa apenas códigos fictícios do universo do jogo.
- Não usar nome/logo real de empresas no build comercial.
